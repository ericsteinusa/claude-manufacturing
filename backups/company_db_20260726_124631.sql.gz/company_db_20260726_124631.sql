--
-- PostgreSQL database dump
--

\restrict MKtlbYJfUNliUju3rAJSunlwSM1LfwfjfdbkFc2acXB5y1Ugzq7ZMHF7FNGskpW

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: _audit_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public._audit_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO audit_log(
        table_name, record_id, action, changed_by, old_values, new_values
    ) VALUES (
        TG_TABLE_NAME,
        CASE WHEN TG_OP = 'DELETE' THEN OLD.id ELSE NEW.id END,
        TG_OP,
        COALESCE(current_setting('app.current_user', TRUE), ''),
        CASE WHEN TG_OP = 'INSERT' THEN NULL ELSE row_to_json(OLD)::jsonb END,
        CASE WHEN TG_OP = 'DELETE' THEN NULL ELSE row_to_json(NEW)::jsonb END
    );
    RETURN CASE WHEN TG_OP = 'DELETE' THEN OLD ELSE NEW END;
END;
$$;


ALTER FUNCTION public._audit_trigger() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ap_invoice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ap_invoice (
    id integer NOT NULL,
    vendor_id integer,
    invoice_number text NOT NULL,
    invoice_date text NOT NULL,
    due_date text NOT NULL,
    amount real NOT NULL,
    description text,
    status text DEFAULT 'open'::text NOT NULL,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.ap_invoice OWNER TO postgres;

--
-- Name: ap_invoice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ap_invoice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ap_invoice_id_seq OWNER TO postgres;

--
-- Name: ap_invoice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ap_invoice_id_seq OWNED BY public.ap_invoice.id;


--
-- Name: ap_payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ap_payment (
    id integer NOT NULL,
    invoice_id integer NOT NULL,
    payment_date text NOT NULL,
    amount real NOT NULL,
    payment_method text DEFAULT 'Check'::text NOT NULL,
    reference text,
    notes text
);


ALTER TABLE public.ap_payment OWNER TO postgres;

--
-- Name: ap_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ap_payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ap_payment_id_seq OWNER TO postgres;

--
-- Name: ap_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ap_payment_id_seq OWNED BY public.ap_payment.id;


--
-- Name: api_login_attempt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_login_attempt (
    id integer NOT NULL,
    identifier text NOT NULL,
    attempted_at timestamp with time zone DEFAULT now() NOT NULL,
    success boolean DEFAULT false NOT NULL
);


ALTER TABLE public.api_login_attempt OWNER TO postgres;

--
-- Name: api_login_attempt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.api_login_attempt_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_login_attempt_id_seq OWNER TO postgres;

--
-- Name: api_login_attempt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.api_login_attempt_id_seq OWNED BY public.api_login_attempt.id;


--
-- Name: api_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_token (
    token text NOT NULL,
    people_id integer NOT NULL,
    created_at text NOT NULL,
    expires_at text
);


ALTER TABLE public.api_token OWNER TO postgres;

--
-- Name: api_totp_secret; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_totp_secret (
    people_id integer NOT NULL,
    secret_b32 text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.api_totp_secret OWNER TO postgres;

--
-- Name: approval_rule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.approval_rule (
    id integer NOT NULL,
    entity_type text NOT NULL,
    dept_key text DEFAULT ''::text NOT NULL,
    threshold_amount real DEFAULT 0.0 NOT NULL,
    approver_role text NOT NULL,
    seq integer DEFAULT 10 NOT NULL,
    escalate_after_hours real DEFAULT 24.0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.approval_rule OWNER TO postgres;

--
-- Name: approval_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.approval_rule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.approval_rule_id_seq OWNER TO postgres;

--
-- Name: approval_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.approval_rule_id_seq OWNED BY public.approval_rule.id;


--
-- Name: approval_step; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.approval_step (
    id integer NOT NULL,
    rule_id integer,
    entity_type text NOT NULL,
    entity_id integer NOT NULL,
    seq integer DEFAULT 10 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    approver_role text NOT NULL,
    decided_by text DEFAULT ''::text NOT NULL,
    decided_at timestamp with time zone,
    notes text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.approval_step OWNER TO postgres;

--
-- Name: approval_step_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.approval_step_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.approval_step_id_seq OWNER TO postgres;

--
-- Name: approval_step_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.approval_step_id_seq OWNED BY public.approval_step.id;


--
-- Name: ar_invoice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar_invoice (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    invoice_number text NOT NULL,
    invoice_date text NOT NULL,
    due_date text NOT NULL,
    amount real NOT NULL,
    description text,
    status text DEFAULT 'open'::text NOT NULL,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.ar_invoice OWNER TO postgres;

--
-- Name: ar_invoice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ar_invoice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ar_invoice_id_seq OWNER TO postgres;

--
-- Name: ar_invoice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ar_invoice_id_seq OWNED BY public.ar_invoice.id;


--
-- Name: ar_payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ar_payment (
    id integer NOT NULL,
    invoice_id integer NOT NULL,
    payment_date text NOT NULL,
    amount real NOT NULL,
    payment_method text DEFAULT 'Check'::text NOT NULL,
    reference text,
    notes text
);


ALTER TABLE public.ar_payment OWNER TO postgres;

--
-- Name: ar_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ar_payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ar_payment_id_seq OWNER TO postgres;

--
-- Name: ar_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ar_payment_id_seq OWNED BY public.ar_payment.id;


--
-- Name: audit_finding; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_finding (
    id integer NOT NULL,
    audit_id integer,
    finding_ref text DEFAULT ''::text,
    description text NOT NULL,
    severity text DEFAULT 'Minor'::text,
    department text DEFAULT ''::text,
    found_date text DEFAULT ''::text,
    status text DEFAULT 'Open'::text,
    notes text DEFAULT ''::text,
    created_by text
);


ALTER TABLE public.audit_finding OWNER TO postgres;

--
-- Name: audit_finding_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_finding_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_finding_id_seq OWNER TO postgres;

--
-- Name: audit_finding_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_finding_id_seq OWNED BY public.audit_finding.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    table_name text NOT NULL,
    record_id integer,
    action text NOT NULL,
    changed_by text DEFAULT ''::text NOT NULL,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    old_values jsonb,
    new_values jsonb
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: audit_schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_schedule (
    id integer NOT NULL,
    audit_name text NOT NULL,
    audit_type text DEFAULT ''::text,
    department text DEFAULT ''::text,
    auditor text DEFAULT ''::text,
    scheduled text DEFAULT ''::text,
    completed text DEFAULT ''::text,
    status text DEFAULT 'Scheduled'::text,
    notes text DEFAULT ''::text,
    created_by text
);


ALTER TABLE public.audit_schedule OWNER TO postgres;

--
-- Name: audit_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_schedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_schedule_id_seq OWNER TO postgres;

--
-- Name: audit_schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_schedule_id_seq OWNED BY public.audit_schedule.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bank_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank_account (
    id integer NOT NULL,
    account_name text NOT NULL,
    bank_name text DEFAULT ''::text,
    account_number text DEFAULT ''::text,
    routing_number text DEFAULT ''::text,
    gl_account_id integer,
    is_active integer DEFAULT 1,
    notes text DEFAULT ''::text
);


ALTER TABLE public.bank_account OWNER TO postgres;

--
-- Name: bank_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bank_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bank_account_id_seq OWNER TO postgres;

--
-- Name: bank_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bank_account_id_seq OWNED BY public.bank_account.id;


--
-- Name: bank_reconciliation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank_reconciliation (
    id integer NOT NULL,
    statement_id integer NOT NULL,
    journal_line_id integer,
    statement_item_id integer,
    matched_at text DEFAULT CURRENT_TIMESTAMP,
    matched_by text DEFAULT ''::text
);


ALTER TABLE public.bank_reconciliation OWNER TO postgres;

--
-- Name: bank_reconciliation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bank_reconciliation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bank_reconciliation_id_seq OWNER TO postgres;

--
-- Name: bank_reconciliation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bank_reconciliation_id_seq OWNED BY public.bank_reconciliation.id;


--
-- Name: bank_statement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank_statement (
    id integer NOT NULL,
    bank_account_id integer NOT NULL,
    statement_date text NOT NULL,
    beginning_balance real DEFAULT 0.0,
    ending_balance real DEFAULT 0.0,
    status text DEFAULT 'Open'::text,
    reconciled_by text DEFAULT ''::text,
    reconciled_at text DEFAULT ''::text,
    notes text DEFAULT ''::text,
    created_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.bank_statement OWNER TO postgres;

--
-- Name: bank_statement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bank_statement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bank_statement_id_seq OWNER TO postgres;

--
-- Name: bank_statement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bank_statement_id_seq OWNED BY public.bank_statement.id;


--
-- Name: bank_statement_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank_statement_item (
    id integer NOT NULL,
    statement_id integer NOT NULL,
    item_date text NOT NULL,
    description text DEFAULT ''::text,
    amount real NOT NULL,
    item_type text DEFAULT 'Credit'::text,
    is_matched integer DEFAULT 0,
    matched_journal_line_id integer
);


ALTER TABLE public.bank_statement_item OWNER TO postgres;

--
-- Name: bank_statement_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bank_statement_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bank_statement_item_id_seq OWNER TO postgres;

--
-- Name: bank_statement_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bank_statement_item_id_seq OWNED BY public.bank_statement_item.id;


--
-- Name: bank_transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bank_transaction (
    id integer NOT NULL,
    bank_account_id integer NOT NULL,
    statement_id integer,
    trans_date text NOT NULL,
    amount real NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    ref_number text DEFAULT ''::text NOT NULL,
    cleared boolean DEFAULT false NOT NULL,
    matched_gl_line_id integer,
    created_by text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.bank_transaction OWNER TO postgres;

--
-- Name: bank_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bank_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bank_transaction_id_seq OWNER TO postgres;

--
-- Name: bank_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bank_transaction_id_seq OWNED BY public.bank_transaction.id;


--
-- Name: bom; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bom (
    id integer NOT NULL,
    product_id integer NOT NULL,
    component_id integer NOT NULL,
    qty_required real DEFAULT 1.0,
    unit text,
    notes text,
    scrap_pct real DEFAULT 0.0
);


ALTER TABLE public.bom OWNER TO postgres;

--
-- Name: bom_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bom_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bom_id_seq OWNER TO postgres;

--
-- Name: bom_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bom_id_seq OWNED BY public.bom.id;


--
-- Name: budget; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget (
    id integer NOT NULL,
    budget_name text NOT NULL,
    fiscal_year integer NOT NULL,
    dept_id integer,
    status text DEFAULT 'draft'::text,
    notes text DEFAULT ''::text,
    created_by text
);


ALTER TABLE public.budget OWNER TO postgres;

--
-- Name: budget_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_id_seq OWNER TO postgres;

--
-- Name: budget_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_id_seq OWNED BY public.budget.id;


--
-- Name: budget_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.budget_line (
    id integer NOT NULL,
    budget_id integer NOT NULL,
    account_id integer,
    category text DEFAULT ''::text,
    description text NOT NULL,
    budgeted_amount real DEFAULT 0,
    notes text DEFAULT ''::text,
    gl_account_id integer
);


ALTER TABLE public.budget_line OWNER TO postgres;

--
-- Name: budget_line_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.budget_line_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.budget_line_id_seq OWNER TO postgres;

--
-- Name: budget_line_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.budget_line_id_seq OWNED BY public.budget_line.id;


--
-- Name: calls2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.calls2 (
    id integer NOT NULL,
    customer_id integer,
    call text NOT NULL,
    call_date text NOT NULL,
    call_time text NOT NULL,
    completion_date text NOT NULL,
    completion_time text NOT NULL,
    comments_box text NOT NULL,
    completion_box integer NOT NULL,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.calls2 OWNER TO postgres;

--
-- Name: calls2_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.calls2_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.calls2_id_seq OWNER TO postgres;

--
-- Name: calls2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.calls2_id_seq OWNED BY public.calls2.id;


--
-- Name: closed_periods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.closed_periods (
    id integer NOT NULL,
    period_year integer NOT NULL,
    period_month integer NOT NULL,
    closed_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_by text DEFAULT ''::text NOT NULL,
    notes text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.closed_periods OWNER TO postgres;

--
-- Name: closed_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.closed_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.closed_periods_id_seq OWNER TO postgres;

--
-- Name: closed_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.closed_periods_id_seq OWNED BY public.closed_periods.id;


--
-- Name: collection_activity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.collection_activity (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    activity_date text DEFAULT (CURRENT_DATE)::text NOT NULL,
    activity_type text DEFAULT 'Call'::text NOT NULL,
    contact_name text DEFAULT ''::text,
    notes text DEFAULT ''::text,
    amount_promised real,
    promise_date text,
    follow_up_date text,
    status text DEFAULT 'Open'::text NOT NULL,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.collection_activity OWNER TO postgres;

--
-- Name: collection_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.collection_activity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.collection_activity_id_seq OWNER TO postgres;

--
-- Name: collection_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.collection_activity_id_seq OWNED BY public.collection_activity.id;


--
-- Name: compliance_checklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compliance_checklist (
    id integer NOT NULL,
    template_id integer NOT NULL,
    name text NOT NULL,
    owner text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    created_by text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.compliance_checklist OWNER TO postgres;

--
-- Name: compliance_checklist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.compliance_checklist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.compliance_checklist_id_seq OWNER TO postgres;

--
-- Name: compliance_checklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.compliance_checklist_id_seq OWNED BY public.compliance_checklist.id;


--
-- Name: compliance_checklist_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compliance_checklist_item (
    id integer NOT NULL,
    checklist_id integer NOT NULL,
    template_item_id integer,
    clause_ref text DEFAULT ''::text NOT NULL,
    requirement_text text NOT NULL,
    category text DEFAULT ''::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'not_started'::text NOT NULL,
    evidence_notes text DEFAULT ''::text NOT NULL,
    completed_by text DEFAULT ''::text NOT NULL,
    completed_at text
);


ALTER TABLE public.compliance_checklist_item OWNER TO postgres;

--
-- Name: compliance_checklist_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.compliance_checklist_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.compliance_checklist_item_id_seq OWNER TO postgres;

--
-- Name: compliance_checklist_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.compliance_checklist_item_id_seq OWNED BY public.compliance_checklist_item.id;


--
-- Name: compliance_template; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compliance_template (
    id integer NOT NULL,
    name text NOT NULL,
    standard text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    created_by text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.compliance_template OWNER TO postgres;

--
-- Name: compliance_template_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.compliance_template_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.compliance_template_id_seq OWNER TO postgres;

--
-- Name: compliance_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.compliance_template_id_seq OWNED BY public.compliance_template.id;


--
-- Name: compliance_template_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.compliance_template_item (
    id integer NOT NULL,
    template_id integer NOT NULL,
    clause_ref text DEFAULT ''::text NOT NULL,
    requirement_text text NOT NULL,
    category text DEFAULT ''::text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.compliance_template_item OWNER TO postgres;

--
-- Name: compliance_template_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.compliance_template_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.compliance_template_item_id_seq OWNER TO postgres;

--
-- Name: compliance_template_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.compliance_template_item_id_seq OWNED BY public.compliance_template_item.id;


--
-- Name: corrective_action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.corrective_action (
    id integer NOT NULL,
    finding_id integer,
    description text NOT NULL,
    assigned_to text DEFAULT ''::text,
    due_date text DEFAULT ''::text,
    completed text DEFAULT ''::text,
    status text DEFAULT 'Open'::text,
    notes text DEFAULT ''::text,
    created_by text
);


ALTER TABLE public.corrective_action OWNER TO postgres;

--
-- Name: corrective_action_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.corrective_action_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.corrective_action_id_seq OWNER TO postgres;

--
-- Name: corrective_action_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.corrective_action_id_seq OWNED BY public.corrective_action.id;


--
-- Name: cost_center; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cost_center (
    id integer NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    dept_key text DEFAULT ''::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.cost_center OWNER TO postgres;

--
-- Name: cost_center_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cost_center_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cost_center_id_seq OWNER TO postgres;

--
-- Name: cost_center_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cost_center_id_seq OWNED BY public.cost_center.id;


--
-- Name: cost_roll; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cost_roll (
    id integer NOT NULL,
    product_id integer NOT NULL,
    effective_date text NOT NULL,
    std_material_cost real DEFAULT 0.0 NOT NULL,
    std_labor_cost real DEFAULT 0.0 NOT NULL,
    std_overhead_cost real DEFAULT 0.0 NOT NULL,
    total_std_cost real DEFAULT 0.0 NOT NULL,
    roll_notes text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.cost_roll OWNER TO postgres;

--
-- Name: cost_roll_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cost_roll_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cost_roll_id_seq OWNER TO postgres;

--
-- Name: cost_roll_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cost_roll_id_seq OWNED BY public.cost_roll.id;


--
-- Name: credit_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credit_account (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    credit_limit real DEFAULT 0.0 NOT NULL,
    status text DEFAULT 'good'::text NOT NULL,
    terms text,
    opened_date text NOT NULL,
    notes text
);


ALTER TABLE public.credit_account OWNER TO postgres;

--
-- Name: credit_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.credit_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_account_id_seq OWNER TO postgres;

--
-- Name: credit_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.credit_account_id_seq OWNED BY public.credit_account.id;


--
-- Name: credit_application; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credit_application (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    applied_date text NOT NULL,
    requested_limit real DEFAULT 0.0 NOT NULL,
    approved_limit real,
    status text DEFAULT 'pending'::text NOT NULL,
    reviewed_by text,
    review_date text,
    notes text,
    created_by text
);


ALTER TABLE public.credit_application OWNER TO postgres;

--
-- Name: credit_application_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.credit_application_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_application_id_seq OWNER TO postgres;

--
-- Name: credit_application_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.credit_application_id_seq OWNED BY public.credit_application.id;


--
-- Name: credit_limit_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credit_limit_history (
    id integer NOT NULL,
    customer_id integer NOT NULL,
    changed_date text NOT NULL,
    old_limit real,
    new_limit real NOT NULL,
    old_status text,
    new_status text,
    changed_by text,
    reason text
);


ALTER TABLE public.credit_limit_history OWNER TO postgres;

--
-- Name: credit_limit_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.credit_limit_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.credit_limit_history_id_seq OWNER TO postgres;

--
-- Name: credit_limit_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.credit_limit_history_id_seq OWNED BY public.credit_limit_history.id;


--
-- Name: cs_improvement_plan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cs_improvement_plan (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    owner text,
    target_date text,
    status text DEFAULT 'Open'::text NOT NULL,
    created_date text NOT NULL,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.cs_improvement_plan OWNER TO postgres;

--
-- Name: cs_improvement_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cs_improvement_plan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cs_improvement_plan_id_seq OWNER TO postgres;

--
-- Name: cs_improvement_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cs_improvement_plan_id_seq OWNED BY public.cs_improvement_plan.id;


--
-- Name: cs_kb_article; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cs_kb_article (
    id integer NOT NULL,
    title text NOT NULL,
    category text DEFAULT ''::text,
    content text DEFAULT ''::text,
    author text DEFAULT ''::text,
    published_date text,
    status text DEFAULT 'Draft'::text,
    tags text DEFAULT ''::text,
    view_count integer DEFAULT 0,
    created_by text DEFAULT ''::text,
    created_date text DEFAULT ''::text
);


ALTER TABLE public.cs_kb_article OWNER TO postgres;

--
-- Name: cs_kb_article_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cs_kb_article_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cs_kb_article_id_seq OWNER TO postgres;

--
-- Name: cs_kb_article_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cs_kb_article_id_seq OWNED BY public.cs_kb_article.id;


--
-- Name: cs_return; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cs_return (
    id integer NOT NULL,
    customer_id integer,
    return_date text,
    reason text DEFAULT ''::text,
    items_returned text DEFAULT ''::text,
    refund_amount real DEFAULT 0,
    status text DEFAULT 'Pending'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text,
    created_date text DEFAULT ''::text
);


ALTER TABLE public.cs_return OWNER TO postgres;

--
-- Name: cs_return_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cs_return_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cs_return_id_seq OWNER TO postgres;

--
-- Name: cs_return_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cs_return_id_seq OWNED BY public.cs_return.id;


--
-- Name: cs_survey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cs_survey (
    id integer NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text,
    survey_type text DEFAULT 'CSAT'::text,
    status text DEFAULT 'Draft'::text,
    start_date text,
    end_date text,
    response_count integer DEFAULT 0,
    avg_score real,
    created_by text DEFAULT ''::text,
    created_date text DEFAULT ''::text
);


ALTER TABLE public.cs_survey OWNER TO postgres;

--
-- Name: cs_survey_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cs_survey_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cs_survey_id_seq OWNER TO postgres;

--
-- Name: cs_survey_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cs_survey_id_seq OWNED BY public.cs_survey.id;


--
-- Name: cs_survey_response; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cs_survey_response (
    id integer NOT NULL,
    survey_id integer NOT NULL,
    customer_id integer,
    score integer,
    comments text DEFAULT ''::text,
    response_date text
);


ALTER TABLE public.cs_survey_response OWNER TO postgres;

--
-- Name: cs_survey_response_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cs_survey_response_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cs_survey_response_id_seq OWNER TO postgres;

--
-- Name: cs_survey_response_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cs_survey_response_id_seq OWNED BY public.cs_survey_response.id;


--
-- Name: cs_training; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cs_training (
    id integer NOT NULL,
    people_id integer,
    topic text NOT NULL,
    trainer text,
    train_date text NOT NULL,
    notes text,
    completed integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.cs_training OWNER TO postgres;

--
-- Name: cs_training_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cs_training_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cs_training_id_seq OWNER TO postgres;

--
-- Name: cs_training_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cs_training_id_seq OWNED BY public.cs_training.id;


--
-- Name: customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customer (
    id integer NOT NULL,
    first_name text,
    last_name text,
    company_name text,
    phone_number text,
    address text,
    city text,
    state text,
    zip_code text,
    email text,
    created_by text
);


ALTER TABLE public.customer OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customer_id_seq OWNER TO postgres;

--
-- Name: customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customer_id_seq OWNED BY public.customer.id;


--
-- Name: dept; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dept (
    dept_id integer NOT NULL,
    dept_name text NOT NULL
);


ALTER TABLE public.dept OWNER TO postgres;

--
-- Name: dept_dept_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dept_dept_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dept_dept_id_seq OWNER TO postgres;

--
-- Name: dept_dept_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dept_dept_id_seq OWNED BY public.dept.dept_id;


--
-- Name: dept_sub; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dept_sub (
    dept_sub_id integer NOT NULL,
    dept_sub_name text NOT NULL,
    dept_id integer
);


ALTER TABLE public.dept_sub OWNER TO postgres;

--
-- Name: dept_sub_dept_sub_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dept_sub_dept_sub_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dept_sub_dept_sub_id_seq OWNER TO postgres;

--
-- Name: dept_sub_dept_sub_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dept_sub_dept_sub_id_seq OWNED BY public.dept_sub.dept_sub_id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: employee_deduction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_deduction (
    id integer NOT NULL,
    people_id integer NOT NULL,
    deduction_type_id integer NOT NULL,
    calc_method text DEFAULT 'flat'::text,
    amount real DEFAULT 0.0,
    is_active integer DEFAULT 1,
    effective_date text DEFAULT (CURRENT_DATE)::text,
    end_date text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.employee_deduction OWNER TO postgres;

--
-- Name: employee_deduction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_deduction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employee_deduction_id_seq OWNER TO postgres;

--
-- Name: employee_deduction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_deduction_id_seq OWNED BY public.employee_deduction.id;


--
-- Name: employee_pay; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_pay (
    id integer NOT NULL,
    people_id integer NOT NULL,
    pay_type text DEFAULT 'hourly'::text NOT NULL,
    pay_rate real DEFAULT 0.0 NOT NULL,
    effective_date text NOT NULL,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.employee_pay OWNER TO postgres;

--
-- Name: employee_pay_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_pay_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employee_pay_id_seq OWNER TO postgres;

--
-- Name: employee_pay_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_pay_id_seq OWNED BY public.employee_pay.id;


--
-- Name: eng_design_review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.eng_design_review (
    id integer NOT NULL,
    ecr_number text NOT NULL,
    title text NOT NULL,
    product_id integer,
    project_id integer,
    requested_by text,
    review_date text,
    status text DEFAULT 'draft'::text,
    notes text
);


ALTER TABLE public.eng_design_review OWNER TO postgres;

--
-- Name: eng_design_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.eng_design_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.eng_design_review_id_seq OWNER TO postgres;

--
-- Name: eng_design_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.eng_design_review_id_seq OWNED BY public.eng_design_review.id;


--
-- Name: eng_project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.eng_project (
    id integer NOT NULL,
    project_number text NOT NULL,
    title text NOT NULL,
    product_id integer,
    engineer text,
    start_date text,
    due_date text,
    status text DEFAULT 'planning'::text,
    notes text
);


ALTER TABLE public.eng_project OWNER TO postgres;

--
-- Name: eng_project_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.eng_project_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.eng_project_id_seq OWNER TO postgres;

--
-- Name: eng_project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.eng_project_id_seq OWNED BY public.eng_project.id;


--
-- Name: eng_standard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.eng_standard (
    id integer NOT NULL,
    standard_number text DEFAULT ''::text,
    title text NOT NULL,
    category text DEFAULT ''::text,
    version text DEFAULT ''::text,
    status text DEFAULT 'Active'::text,
    review_date text,
    description text DEFAULT ''::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text,
    created_date text DEFAULT ''::text
);


ALTER TABLE public.eng_standard OWNER TO postgres;

--
-- Name: eng_standard_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.eng_standard_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.eng_standard_id_seq OWNER TO postgres;

--
-- Name: eng_standard_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.eng_standard_id_seq OWNED BY public.eng_standard.id;


--
-- Name: eng_task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.eng_task (
    id integer NOT NULL,
    project_id integer,
    task_name text NOT NULL,
    assigned_to text,
    due_date text,
    priority text DEFAULT 'medium'::text,
    status text DEFAULT 'open'::text,
    notes text
);


ALTER TABLE public.eng_task OWNER TO postgres;

--
-- Name: eng_task_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.eng_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.eng_task_id_seq OWNER TO postgres;

--
-- Name: eng_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.eng_task_id_seq OWNED BY public.eng_task.id;


--
-- Name: gl_account; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gl_account (
    id integer NOT NULL,
    account_number text NOT NULL,
    account_name text NOT NULL,
    account_type text NOT NULL,
    account_sub text DEFAULT ''::text,
    is_active integer DEFAULT 1,
    notes text DEFAULT ''::text
);


ALTER TABLE public.gl_account OWNER TO postgres;

--
-- Name: gl_account_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gl_account_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gl_account_id_seq OWNER TO postgres;

--
-- Name: gl_account_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gl_account_id_seq OWNED BY public.gl_account.id;


--
-- Name: gl_account_map; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gl_account_map (
    id integer NOT NULL,
    category text NOT NULL,
    account_number text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.gl_account_map OWNER TO postgres;

--
-- Name: gl_account_map_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gl_account_map_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gl_account_map_id_seq OWNER TO postgres;

--
-- Name: gl_account_map_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gl_account_map_id_seq OWNED BY public.gl_account_map.id;


--
-- Name: gl_journal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gl_journal (
    id integer NOT NULL,
    journal_date text NOT NULL,
    reference text DEFAULT ''::text,
    description text DEFAULT ''::text,
    posted integer DEFAULT 0,
    created_by text DEFAULT ''::text,
    created_at text DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.gl_journal OWNER TO postgres;

--
-- Name: gl_journal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gl_journal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gl_journal_id_seq OWNER TO postgres;

--
-- Name: gl_journal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gl_journal_id_seq OWNED BY public.gl_journal.id;


--
-- Name: gl_journal_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gl_journal_line (
    id integer NOT NULL,
    journal_id integer NOT NULL,
    account_id integer NOT NULL,
    debit real DEFAULT 0.0,
    credit real DEFAULT 0.0,
    memo text DEFAULT ''::text,
    cost_center_id integer
);


ALTER TABLE public.gl_journal_line OWNER TO postgres;

--
-- Name: gl_journal_line_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gl_journal_line_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.gl_journal_line_id_seq OWNER TO postgres;

--
-- Name: gl_journal_line_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gl_journal_line_id_seq OWNED BY public.gl_journal_line.id;


--
-- Name: inventory_transaction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_transaction (
    id integer NOT NULL,
    product_id integer NOT NULL,
    trans_date text NOT NULL,
    trans_type text NOT NULL,
    quantity real NOT NULL,
    reference text DEFAULT ''::text,
    notes text DEFAULT ''::text,
    lot_id integer
);


ALTER TABLE public.inventory_transaction OWNER TO postgres;

--
-- Name: inventory_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_transaction_id_seq OWNER TO postgres;

--
-- Name: inventory_transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_transaction_id_seq OWNED BY public.inventory_transaction.id;


--
-- Name: it_asset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.it_asset (
    id integer NOT NULL,
    asset_tag text NOT NULL,
    asset_type text,
    make text,
    model text,
    serial_number text,
    assigned_to text,
    department text,
    purchase_date text,
    warranty_exp text,
    status text DEFAULT 'active'::text,
    notes text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.it_asset OWNER TO postgres;

--
-- Name: it_asset_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.it_asset_history (
    id integer NOT NULL,
    asset_tag text DEFAULT ''::text,
    asset_id integer,
    event_type text DEFAULT ''::text,
    description text DEFAULT ''::text,
    changed_by text DEFAULT ''::text,
    changed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.it_asset_history OWNER TO postgres;

--
-- Name: it_asset_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.it_asset_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.it_asset_history_id_seq OWNER TO postgres;

--
-- Name: it_asset_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.it_asset_history_id_seq OWNED BY public.it_asset_history.id;


--
-- Name: it_asset_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.it_asset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.it_asset_id_seq OWNER TO postgres;

--
-- Name: it_asset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.it_asset_id_seq OWNED BY public.it_asset.id;


--
-- Name: it_bandwidth_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.it_bandwidth_log (
    id integer NOT NULL,
    interface_name text DEFAULT ''::text,
    recorded_at timestamp without time zone DEFAULT now(),
    mbps_in real DEFAULT 0,
    mbps_out real DEFAULT 0,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.it_bandwidth_log OWNER TO postgres;

--
-- Name: it_bandwidth_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.it_bandwidth_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.it_bandwidth_log_id_seq OWNER TO postgres;

--
-- Name: it_bandwidth_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.it_bandwidth_log_id_seq OWNED BY public.it_bandwidth_log.id;


--
-- Name: it_license; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.it_license (
    id integer NOT NULL,
    software_name text DEFAULT ''::text,
    vendor text DEFAULT ''::text,
    license_key text DEFAULT ''::text,
    license_type text DEFAULT 'perpetual'::text,
    seats integer DEFAULT 1,
    seats_used integer DEFAULT 0,
    purchase_date date,
    expiry_date date,
    cost real DEFAULT 0,
    status text DEFAULT 'active'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.it_license OWNER TO postgres;

--
-- Name: it_license_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.it_license_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.it_license_id_seq OWNER TO postgres;

--
-- Name: it_license_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.it_license_id_seq OWNED BY public.it_license.id;


--
-- Name: it_network_device; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.it_network_device (
    id integer NOT NULL,
    hostname text DEFAULT ''::text,
    ip_address text DEFAULT ''::text,
    mac_address text DEFAULT ''::text,
    device_type text DEFAULT ''::text,
    manufacturer text DEFAULT ''::text,
    model text DEFAULT ''::text,
    location text DEFAULT ''::text,
    status text DEFAULT 'unknown'::text,
    last_seen date,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.it_network_device OWNER TO postgres;

--
-- Name: it_network_device_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.it_network_device_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.it_network_device_id_seq OWNER TO postgres;

--
-- Name: it_network_device_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.it_network_device_id_seq OWNED BY public.it_network_device.id;


--
-- Name: it_network_incident; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.it_network_incident (
    id integer NOT NULL,
    title text DEFAULT ''::text,
    severity text DEFAULT 'info'::text,
    status text DEFAULT 'open'::text,
    description text DEFAULT ''::text,
    affected_systems text DEFAULT ''::text,
    reported_date date,
    resolved_date date,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.it_network_incident OWNER TO postgres;

--
-- Name: it_network_incident_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.it_network_incident_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.it_network_incident_id_seq OWNER TO postgres;

--
-- Name: it_network_incident_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.it_network_incident_id_seq OWNED BY public.it_network_incident.id;


--
-- Name: it_repair; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.it_repair (
    id integer NOT NULL,
    asset_tag text DEFAULT ''::text,
    problem_description text DEFAULT ''::text,
    reported_by text DEFAULT ''::text,
    reported_date date,
    assigned_to text DEFAULT ''::text,
    priority text DEFAULT 'medium'::text,
    status text DEFAULT 'open'::text,
    resolution text DEFAULT ''::text,
    completed_date date,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.it_repair OWNER TO postgres;

--
-- Name: it_repair_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.it_repair_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.it_repair_id_seq OWNER TO postgres;

--
-- Name: it_repair_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.it_repair_id_seq OWNED BY public.it_repair.id;


--
-- Name: it_software_install; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.it_software_install (
    id integer NOT NULL,
    asset_tag text DEFAULT ''::text,
    software_name text DEFAULT ''::text,
    version text DEFAULT ''::text,
    vendor text DEFAULT ''::text,
    install_date date,
    status text DEFAULT 'installed'::text,
    installed_by text DEFAULT ''::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.it_software_install OWNER TO postgres;

--
-- Name: it_software_install_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.it_software_install_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.it_software_install_id_seq OWNER TO postgres;

--
-- Name: it_software_install_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.it_software_install_id_seq OWNED BY public.it_software_install.id;


--
-- Name: it_task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.it_task (
    id integer NOT NULL,
    task_number text NOT NULL,
    task_name text NOT NULL,
    task_type text,
    description text,
    assigned_to text,
    department text,
    priority text DEFAULT 'medium'::text,
    scheduled_date text,
    due_date text,
    completed_date text,
    status text DEFAULT 'pending'::text,
    notes text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.it_task OWNER TO postgres;

--
-- Name: it_task_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.it_task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.it_task_id_seq OWNER TO postgres;

--
-- Name: it_task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.it_task_id_seq OWNED BY public.it_task.id;


--
-- Name: it_ticket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.it_ticket (
    id integer NOT NULL,
    ticket_number text NOT NULL,
    requester text,
    department text,
    issue_type text,
    description text NOT NULL,
    priority text DEFAULT 'medium'::text,
    assigned_to text,
    submitted_date text,
    due_date text,
    resolved_date text,
    status text DEFAULT 'open'::text,
    notes text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.it_ticket OWNER TO postgres;

--
-- Name: it_ticket_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.it_ticket_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.it_ticket_id_seq OWNER TO postgres;

--
-- Name: it_ticket_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.it_ticket_id_seq OWNED BY public.it_ticket.id;


--
-- Name: legal_compliance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.legal_compliance (
    id integer NOT NULL,
    requirement text NOT NULL,
    regulation text DEFAULT ''::text,
    owner text DEFAULT ''::text,
    due_date text DEFAULT ''::text,
    completed_date text DEFAULT ''::text,
    status text DEFAULT 'Pending'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.legal_compliance OWNER TO postgres;

--
-- Name: legal_compliance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.legal_compliance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.legal_compliance_id_seq OWNER TO postgres;

--
-- Name: legal_compliance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.legal_compliance_id_seq OWNED BY public.legal_compliance.id;


--
-- Name: legal_contract; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.legal_contract (
    id integer NOT NULL,
    title text NOT NULL,
    counterparty text DEFAULT ''::text,
    contract_type text DEFAULT ''::text,
    value real DEFAULT 0,
    start_date text DEFAULT ''::text,
    end_date text DEFAULT ''::text,
    owner text DEFAULT ''::text,
    status text DEFAULT 'Draft'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.legal_contract OWNER TO postgres;

--
-- Name: legal_contract_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.legal_contract_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.legal_contract_id_seq OWNER TO postgres;

--
-- Name: legal_contract_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.legal_contract_id_seq OWNED BY public.legal_contract.id;


--
-- Name: legal_employment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.legal_employment (
    id integer NOT NULL,
    matter text NOT NULL,
    employee text DEFAULT ''::text,
    matter_type text DEFAULT ''::text,
    owner text DEFAULT ''::text,
    opened_date text DEFAULT ''::text,
    closed_date text DEFAULT ''::text,
    status text DEFAULT 'Open'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.legal_employment OWNER TO postgres;

--
-- Name: legal_employment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.legal_employment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.legal_employment_id_seq OWNER TO postgres;

--
-- Name: legal_employment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.legal_employment_id_seq OWNED BY public.legal_employment.id;


--
-- Name: legal_governance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.legal_governance (
    id integer NOT NULL,
    item text NOT NULL,
    category text DEFAULT ''::text,
    owner text DEFAULT ''::text,
    ref_date text DEFAULT ''::text,
    reference text DEFAULT ''::text,
    status text DEFAULT 'Active'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.legal_governance OWNER TO postgres;

--
-- Name: legal_governance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.legal_governance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.legal_governance_id_seq OWNER TO postgres;

--
-- Name: legal_governance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.legal_governance_id_seq OWNED BY public.legal_governance.id;


--
-- Name: legal_ip; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.legal_ip (
    id integer NOT NULL,
    title text NOT NULL,
    ip_type text DEFAULT ''::text,
    registration_no text DEFAULT ''::text,
    jurisdiction text DEFAULT ''::text,
    filed_date text DEFAULT ''::text,
    expiry_date text DEFAULT ''::text,
    status text DEFAULT 'Pending'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.legal_ip OWNER TO postgres;

--
-- Name: legal_ip_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.legal_ip_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.legal_ip_id_seq OWNER TO postgres;

--
-- Name: legal_ip_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.legal_ip_id_seq OWNED BY public.legal_ip.id;


--
-- Name: legal_litigation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.legal_litigation (
    id integer NOT NULL,
    case_name text NOT NULL,
    opposing_party text DEFAULT ''::text,
    court text DEFAULT ''::text,
    case_type text DEFAULT ''::text,
    filed_date text DEFAULT ''::text,
    status text DEFAULT 'Open'::text,
    outcome text DEFAULT ''::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.legal_litigation OWNER TO postgres;

--
-- Name: legal_litigation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.legal_litigation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.legal_litigation_id_seq OWNER TO postgres;

--
-- Name: legal_litigation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.legal_litigation_id_seq OWNED BY public.legal_litigation.id;


--
-- Name: location; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.location (
    id integer NOT NULL,
    name text NOT NULL,
    code text DEFAULT ''::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.location OWNER TO postgres;

--
-- Name: location_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.location_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.location_id_seq OWNER TO postgres;

--
-- Name: location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.location_id_seq OWNED BY public.location.id;


--
-- Name: lot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lot (
    id integer NOT NULL,
    lot_number text NOT NULL,
    product_id integer NOT NULL,
    qty real DEFAULT 0.0 NOT NULL,
    received_date text,
    expiry_date text,
    status text DEFAULT 'available'::text NOT NULL,
    notes text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lot OWNER TO postgres;

--
-- Name: lot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lot_id_seq OWNER TO postgres;

--
-- Name: lot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lot_id_seq OWNED BY public.lot.id;


--
-- Name: maint_downtime; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maint_downtime (
    id integer NOT NULL,
    equipment text NOT NULL,
    reason text DEFAULT ''::text,
    category text DEFAULT ''::text,
    down_date text DEFAULT ''::text,
    hours text DEFAULT ''::text,
    cost real DEFAULT 0,
    status text DEFAULT 'Ongoing'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.maint_downtime OWNER TO postgres;

--
-- Name: maint_downtime_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.maint_downtime_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.maint_downtime_id_seq OWNER TO postgres;

--
-- Name: maint_downtime_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.maint_downtime_id_seq OWNED BY public.maint_downtime.id;


--
-- Name: maint_equipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maint_equipment (
    id integer NOT NULL,
    name text NOT NULL,
    asset_tag text DEFAULT ''::text,
    location text DEFAULT ''::text,
    manufacturer text DEFAULT ''::text,
    install_date text DEFAULT ''::text,
    last_service text DEFAULT ''::text,
    status text DEFAULT 'Operational'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text,
    parent_id integer
);


ALTER TABLE public.maint_equipment OWNER TO postgres;

--
-- Name: maint_equipment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.maint_equipment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.maint_equipment_id_seq OWNER TO postgres;

--
-- Name: maint_equipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.maint_equipment_id_seq OWNED BY public.maint_equipment.id;


--
-- Name: maint_inspection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maint_inspection (
    id integer NOT NULL,
    area text NOT NULL,
    inspection_type text DEFAULT ''::text,
    inspector text DEFAULT ''::text,
    scheduled_date text DEFAULT ''::text,
    completed_date text DEFAULT ''::text,
    result text DEFAULT ''::text,
    status text DEFAULT 'Scheduled'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.maint_inspection OWNER TO postgres;

--
-- Name: maint_inspection_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.maint_inspection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.maint_inspection_id_seq OWNER TO postgres;

--
-- Name: maint_inspection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.maint_inspection_id_seq OWNED BY public.maint_inspection.id;


--
-- Name: maint_mechanic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maint_mechanic (
    id integer NOT NULL,
    name text NOT NULL,
    trade text DEFAULT ''::text,
    shift text DEFAULT ''::text,
    phone text DEFAULT ''::text,
    status text DEFAULT 'Active'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.maint_mechanic OWNER TO postgres;

--
-- Name: maint_mechanic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.maint_mechanic_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.maint_mechanic_id_seq OWNER TO postgres;

--
-- Name: maint_mechanic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.maint_mechanic_id_seq OWNED BY public.maint_mechanic.id;


--
-- Name: maint_part; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maint_part (
    id integer NOT NULL,
    name text NOT NULL,
    part_number text DEFAULT ''::text,
    category text DEFAULT ''::text,
    location text DEFAULT ''::text,
    quantity text DEFAULT ''::text,
    reorder_level text DEFAULT ''::text,
    unit_cost real DEFAULT 0,
    status text DEFAULT 'In Stock'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text,
    equipment_id integer
);


ALTER TABLE public.maint_part OWNER TO postgres;

--
-- Name: maint_part_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.maint_part_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.maint_part_id_seq OWNER TO postgres;

--
-- Name: maint_part_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.maint_part_id_seq OWNED BY public.maint_part.id;


--
-- Name: maint_schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maint_schedule (
    id integer NOT NULL,
    task text NOT NULL,
    equipment text DEFAULT ''::text,
    frequency text DEFAULT ''::text,
    assigned_to text DEFAULT ''::text,
    last_done text DEFAULT ''::text,
    next_due text DEFAULT ''::text,
    status text DEFAULT 'Scheduled'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.maint_schedule OWNER TO postgres;

--
-- Name: maint_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.maint_schedule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.maint_schedule_id_seq OWNER TO postgres;

--
-- Name: maint_schedule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.maint_schedule_id_seq OWNED BY public.maint_schedule.id;


--
-- Name: maint_work_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maint_work_order (
    id integer NOT NULL,
    title text NOT NULL,
    equipment text DEFAULT ''::text,
    work_type text DEFAULT ''::text,
    priority text DEFAULT 'Medium'::text,
    assigned_to text DEFAULT ''::text,
    requested_date text DEFAULT ''::text,
    due_date text DEFAULT ''::text,
    completed_date text DEFAULT ''::text,
    status text DEFAULT 'Open'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.maint_work_order OWNER TO postgres;

--
-- Name: maint_work_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.maint_work_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.maint_work_order_id_seq OWNER TO postgres;

--
-- Name: maint_work_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.maint_work_order_id_seq OWNED BY public.maint_work_order.id;


--
-- Name: marketing_ad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketing_ad (
    id integer NOT NULL,
    name text DEFAULT ''::text,
    channel text DEFAULT ''::text,
    campaign_name text DEFAULT ''::text,
    budget real DEFAULT 0,
    spend real DEFAULT 0,
    impressions integer DEFAULT 0,
    clicks integer DEFAULT 0,
    conversions integer DEFAULT 0,
    start_date date,
    end_date date,
    status text DEFAULT 'Draft'::text,
    owner text DEFAULT ''::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.marketing_ad OWNER TO postgres;

--
-- Name: marketing_ad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketing_ad_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketing_ad_id_seq OWNER TO postgres;

--
-- Name: marketing_ad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketing_ad_id_seq OWNED BY public.marketing_ad.id;


--
-- Name: marketing_analytics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketing_analytics (
    id integer NOT NULL,
    metric text NOT NULL,
    campaign text DEFAULT ''::text,
    channel text DEFAULT ''::text,
    target text DEFAULT ''::text,
    actual text DEFAULT ''::text,
    measured_date text DEFAULT ''::text,
    status text DEFAULT 'On Track'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.marketing_analytics OWNER TO postgres;

--
-- Name: marketing_analytics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketing_analytics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketing_analytics_id_seq OWNER TO postgres;

--
-- Name: marketing_analytics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketing_analytics_id_seq OWNED BY public.marketing_analytics.id;


--
-- Name: marketing_budget; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketing_budget (
    id integer NOT NULL,
    item text NOT NULL,
    campaign text DEFAULT ''::text,
    category text DEFAULT ''::text,
    amount real DEFAULT 0,
    requested_by text DEFAULT ''::text,
    request_date text DEFAULT ''::text,
    status text DEFAULT 'Pending'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.marketing_budget OWNER TO postgres;

--
-- Name: marketing_budget_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketing_budget_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketing_budget_id_seq OWNER TO postgres;

--
-- Name: marketing_budget_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketing_budget_id_seq OWNED BY public.marketing_budget.id;


--
-- Name: marketing_campaign; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketing_campaign (
    id integer NOT NULL,
    name text NOT NULL,
    channel text DEFAULT ''::text,
    objective text DEFAULT ''::text,
    owner text DEFAULT ''::text,
    start_date text DEFAULT ''::text,
    end_date text DEFAULT ''::text,
    budget real DEFAULT 0,
    status text DEFAULT 'Planned'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.marketing_campaign OWNER TO postgres;

--
-- Name: marketing_campaign_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketing_campaign_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketing_campaign_id_seq OWNER TO postgres;

--
-- Name: marketing_campaign_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketing_campaign_id_seq OWNED BY public.marketing_campaign.id;


--
-- Name: marketing_content; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketing_content (
    id integer NOT NULL,
    title text NOT NULL,
    content_type text DEFAULT ''::text,
    channel text DEFAULT ''::text,
    author text DEFAULT ''::text,
    due_date text DEFAULT ''::text,
    publish_date text DEFAULT ''::text,
    status text DEFAULT 'Draft'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.marketing_content OWNER TO postgres;

--
-- Name: marketing_content_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketing_content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketing_content_id_seq OWNER TO postgres;

--
-- Name: marketing_content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketing_content_id_seq OWNED BY public.marketing_content.id;


--
-- Name: marketing_lead; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketing_lead (
    id integer NOT NULL,
    name text NOT NULL,
    company text DEFAULT ''::text,
    email text DEFAULT ''::text,
    source text DEFAULT ''::text,
    owner text DEFAULT ''::text,
    captured_date text DEFAULT ''::text,
    status text DEFAULT 'New'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.marketing_lead OWNER TO postgres;

--
-- Name: marketing_lead_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketing_lead_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketing_lead_id_seq OWNER TO postgres;

--
-- Name: marketing_lead_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketing_lead_id_seq OWNED BY public.marketing_lead.id;


--
-- Name: marketing_research; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.marketing_research (
    id integer NOT NULL,
    title text NOT NULL,
    research_type text DEFAULT ''::text,
    owner text DEFAULT ''::text,
    methodology text DEFAULT ''::text,
    start_date text DEFAULT ''::text,
    completed_date text DEFAULT ''::text,
    status text DEFAULT 'Proposed'::text,
    findings text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.marketing_research OWNER TO postgres;

--
-- Name: marketing_research_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.marketing_research_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.marketing_research_id_seq OWNER TO postgres;

--
-- Name: marketing_research_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.marketing_research_id_seq OWNED BY public.marketing_research.id;


--
-- Name: mrp_planned_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrp_planned_order (
    id integer NOT NULL,
    run_id integer NOT NULL,
    product_id integer NOT NULL,
    order_type text,
    qty real,
    need_date text,
    lead_time_days integer DEFAULT 0,
    status text DEFAULT 'suggested'::text,
    released_ref text,
    start_date text
);


ALTER TABLE public.mrp_planned_order OWNER TO postgres;

--
-- Name: mrp_planned_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mrp_planned_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mrp_planned_order_id_seq OWNER TO postgres;

--
-- Name: mrp_planned_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mrp_planned_order_id_seq OWNED BY public.mrp_planned_order.id;


--
-- Name: mrp_run; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mrp_run (
    id integer NOT NULL,
    run_date text,
    horizon_days integer,
    notes text
);


ALTER TABLE public.mrp_run OWNER TO postgres;

--
-- Name: mrp_run_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mrp_run_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mrp_run_id_seq OWNER TO postgres;

--
-- Name: mrp_run_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mrp_run_id_seq OWNED BY public.mrp_run.id;


--
-- Name: notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notification (
    id integer NOT NULL,
    people_id integer NOT NULL,
    type text NOT NULL,
    entity_type text DEFAULT ''::text NOT NULL,
    entity_id integer,
    message text NOT NULL,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification OWNER TO postgres;

--
-- Name: notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notification_id_seq OWNER TO postgres;

--
-- Name: notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notification_id_seq OWNED BY public.notification.id;


--
-- Name: passwd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.passwd (
    id integer NOT NULL,
    people_id integer NOT NULL,
    password text NOT NULL
);


ALTER TABLE public.passwd OWNER TO postgres;

--
-- Name: passwd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.passwd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.passwd_id_seq OWNER TO postgres;

--
-- Name: passwd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.passwd_id_seq OWNED BY public.passwd.id;


--
-- Name: payroll_deduction_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_deduction_type (
    id integer NOT NULL,
    name text NOT NULL,
    category text DEFAULT 'Other'::text,
    is_pre_tax integer DEFAULT 1,
    is_active integer DEFAULT 1,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.payroll_deduction_type OWNER TO postgres;

--
-- Name: payroll_deduction_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payroll_deduction_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payroll_deduction_type_id_seq OWNER TO postgres;

--
-- Name: payroll_deduction_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payroll_deduction_type_id_seq OWNED BY public.payroll_deduction_type.id;


--
-- Name: payroll_entry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_entry (
    id integer NOT NULL,
    run_id integer NOT NULL,
    people_id integer NOT NULL,
    regular_hours real DEFAULT 0.0 NOT NULL,
    overtime_hours real DEFAULT 0.0 NOT NULL,
    gross_pay real DEFAULT 0.0 NOT NULL,
    federal_tax real DEFAULT 0.0 NOT NULL,
    state_tax real DEFAULT 0.0 NOT NULL,
    social_security real DEFAULT 0.0 NOT NULL,
    medicare real DEFAULT 0.0 NOT NULL,
    net_pay real DEFAULT 0.0 NOT NULL,
    pre_tax_deductions real DEFAULT 0.0 NOT NULL,
    post_tax_deductions real DEFAULT 0.0 NOT NULL
);


ALTER TABLE public.payroll_entry OWNER TO postgres;

--
-- Name: payroll_entry_deduction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_entry_deduction (
    id integer NOT NULL,
    entry_id integer NOT NULL,
    deduction_name text NOT NULL,
    is_pre_tax integer DEFAULT 1,
    amount real DEFAULT 0.0 NOT NULL
);


ALTER TABLE public.payroll_entry_deduction OWNER TO postgres;

--
-- Name: payroll_entry_deduction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payroll_entry_deduction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payroll_entry_deduction_id_seq OWNER TO postgres;

--
-- Name: payroll_entry_deduction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payroll_entry_deduction_id_seq OWNED BY public.payroll_entry_deduction.id;


--
-- Name: payroll_entry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payroll_entry_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payroll_entry_id_seq OWNER TO postgres;

--
-- Name: payroll_entry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payroll_entry_id_seq OWNED BY public.payroll_entry.id;


--
-- Name: payroll_run; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payroll_run (
    id integer NOT NULL,
    pay_period_start text NOT NULL,
    pay_period_end text NOT NULL,
    run_date text NOT NULL,
    pay_frequency text NOT NULL,
    federal_tax_rate real NOT NULL,
    state_tax_rate real NOT NULL,
    status text DEFAULT 'processed'::text NOT NULL,
    created_by text
);


ALTER TABLE public.payroll_run OWNER TO postgres;

--
-- Name: payroll_run_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payroll_run_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payroll_run_id_seq OWNER TO postgres;

--
-- Name: payroll_run_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payroll_run_id_seq OWNED BY public.payroll_run.id;


--
-- Name: people; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.people (
    id integer NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    employee_id integer DEFAULT 0 NOT NULL,
    address text NOT NULL,
    city text NOT NULL,
    state text NOT NULL,
    zip_code text NOT NULL,
    email text NOT NULL,
    emp_id integer,
    dept_id integer,
    dept_sub_id integer,
    created_by text
);


ALTER TABLE public.people OWNER TO postgres;

--
-- Name: people_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.people_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.people_id_seq OWNER TO postgres;

--
-- Name: people_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.people_id_seq OWNED BY public.people.id;


--
-- Name: pers_review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pers_review (
    id integer NOT NULL,
    people_id integer NOT NULL,
    review_type text DEFAULT 'Annual'::text,
    review_date text,
    reviewer text DEFAULT ''::text,
    rating text DEFAULT ''::text,
    status text DEFAULT 'Scheduled'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.pers_review OWNER TO postgres;

--
-- Name: pers_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pers_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pers_review_id_seq OWNER TO postgres;

--
-- Name: pers_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pers_review_id_seq OWNED BY public.pers_review.id;


--
-- Name: pers_training; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pers_training (
    id integer NOT NULL,
    people_id integer NOT NULL,
    course_name text NOT NULL,
    training_type text DEFAULT 'Other'::text,
    start_date text,
    end_date text,
    status text DEFAULT 'Scheduled'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.pers_training OWNER TO postgres;

--
-- Name: pers_training_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pers_training_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pers_training_id_seq OWNER TO postgres;

--
-- Name: pers_training_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pers_training_id_seq OWNED BY public.pers_training.id;


--
-- Name: po_approval; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.po_approval (
    id integer NOT NULL,
    po_id integer NOT NULL,
    requested_by text DEFAULT ''::text NOT NULL,
    requested_at timestamp with time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    decided_by text DEFAULT ''::text NOT NULL,
    decided_at timestamp with time zone,
    notes text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.po_approval OWNER TO postgres;

--
-- Name: po_approval_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.po_approval_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.po_approval_id_seq OWNER TO postgres;

--
-- Name: po_approval_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.po_approval_id_seq OWNED BY public.po_approval.id;


--
-- Name: po_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.po_item (
    id integer NOT NULL,
    po_id integer NOT NULL,
    description text NOT NULL,
    product_id integer,
    qty_ordered integer NOT NULL,
    unit_price real NOT NULL,
    qty_received integer DEFAULT 0 NOT NULL,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.po_item OWNER TO postgres;

--
-- Name: po_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.po_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.po_item_id_seq OWNER TO postgres;

--
-- Name: po_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.po_item_id_seq OWNED BY public.po_item.id;


--
-- Name: position; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."position" (
    id integer NOT NULL,
    people_id integer NOT NULL,
    job_title text DEFAULT ''::text NOT NULL,
    created_by text DEFAULT ''::text
);


ALTER TABLE public."position" OWNER TO postgres;

--
-- Name: position_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.position_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.position_id_seq OWNER TO postgres;

--
-- Name: position_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.position_id_seq OWNED BY public."position".id;


--
-- Name: product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product (
    id integer NOT NULL,
    supplier_id integer,
    name text NOT NULL,
    purchase_date text,
    purchase_price real DEFAULT 0.0,
    bin text DEFAULT ''::text,
    amount real DEFAULT 0.0,
    reorder_point real DEFAULT 0.0,
    item_type text DEFAULT 'buy'::text,
    lead_time_days integer DEFAULT 0,
    uom text DEFAULT 'ea'::text
);


ALTER TABLE public.product OWNER TO postgres;

--
-- Name: product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_id_seq OWNER TO postgres;

--
-- Name: product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_id_seq OWNED BY public.product.id;


--
-- Name: purchase_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_order (
    id integer NOT NULL,
    po_number text NOT NULL,
    supplier_id integer,
    order_date text NOT NULL,
    expected_date text,
    status text DEFAULT 'open'::text NOT NULL,
    notes text,
    created_by text,
    received_date text,
    supplier_acknowledged_at text,
    supplier_ack_notes text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.purchase_order OWNER TO postgres;

--
-- Name: purchase_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.purchase_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_order_id_seq OWNER TO postgres;

--
-- Name: purchase_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.purchase_order_id_seq OWNED BY public.purchase_order.id;


--
-- Name: purchase_requisition; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_requisition (
    id integer NOT NULL,
    req_number text NOT NULL,
    requester_id integer,
    dept_id integer,
    dept_sub_id integer,
    needed_date text,
    justification text,
    status text DEFAULT 'draft'::text,
    created_date text,
    po_id integer,
    created_by text,
    purpose text,
    notes text
);


ALTER TABLE public.purchase_requisition OWNER TO postgres;

--
-- Name: purchase_requisition_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.purchase_requisition_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_requisition_id_seq OWNER TO postgres;

--
-- Name: purchase_requisition_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.purchase_requisition_id_seq OWNED BY public.purchase_requisition.id;


--
-- Name: qa_audit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_audit (
    id integer NOT NULL,
    title text NOT NULL,
    audit_type text DEFAULT ''::text,
    auditor text DEFAULT ''::text,
    scheduled_date text DEFAULT ''::text,
    completed_date text DEFAULT ''::text,
    result text DEFAULT ''::text,
    status text DEFAULT 'Scheduled'::text,
    findings text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.qa_audit OWNER TO postgres;

--
-- Name: qa_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.qa_audit_id_seq OWNER TO postgres;

--
-- Name: qa_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_audit_id_seq OWNED BY public.qa_audit.id;


--
-- Name: qa_capa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_capa (
    id integer NOT NULL,
    title text NOT NULL,
    capa_type text DEFAULT ''::text,
    ncr_ref text DEFAULT ''::text,
    owner text DEFAULT ''::text,
    due_date text DEFAULT ''::text,
    completed_date text DEFAULT ''::text,
    status text DEFAULT 'Open'::text,
    action_plan text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.qa_capa OWNER TO postgres;

--
-- Name: qa_capa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_capa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.qa_capa_id_seq OWNER TO postgres;

--
-- Name: qa_capa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_capa_id_seq OWNED BY public.qa_capa.id;


--
-- Name: qa_defect; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_defect (
    id integer NOT NULL,
    insp_id integer NOT NULL,
    defect_type text,
    severity text DEFAULT 'minor'::text,
    description text,
    resolved integer DEFAULT 0,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.qa_defect OWNER TO postgres;

--
-- Name: qa_defect_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_defect_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.qa_defect_id_seq OWNER TO postgres;

--
-- Name: qa_defect_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_defect_id_seq OWNED BY public.qa_defect.id;


--
-- Name: qa_inspection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_inspection (
    id integer NOT NULL,
    insp_number text NOT NULL,
    product_id integer,
    wo_id integer,
    insp_date text,
    inspector text,
    result text DEFAULT 'pending'::text,
    notes text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.qa_inspection OWNER TO postgres;

--
-- Name: qa_inspection_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_inspection_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.qa_inspection_id_seq OWNER TO postgres;

--
-- Name: qa_inspection_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_inspection_id_seq OWNED BY public.qa_inspection.id;


--
-- Name: qa_ncr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_ncr (
    id integer NOT NULL,
    title text NOT NULL,
    source text DEFAULT ''::text,
    severity text DEFAULT ''::text,
    product text DEFAULT ''::text,
    detected_date text DEFAULT ''::text,
    disposition text DEFAULT 'Pending'::text,
    owner text DEFAULT ''::text,
    closed_date text DEFAULT ''::text,
    status text DEFAULT 'Open'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.qa_ncr OWNER TO postgres;

--
-- Name: qa_ncr_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_ncr_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.qa_ncr_id_seq OWNER TO postgres;

--
-- Name: qa_ncr_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_ncr_id_seq OWNED BY public.qa_ncr.id;


--
-- Name: qa_spec; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_spec (
    id integer NOT NULL,
    product_id integer NOT NULL,
    spec_name text NOT NULL,
    min_value real,
    max_value real,
    unit text,
    notes text
);


ALTER TABLE public.qa_spec OWNER TO postgres;

--
-- Name: qa_spec_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_spec_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.qa_spec_id_seq OWNER TO postgres;

--
-- Name: qa_spec_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_spec_id_seq OWNED BY public.qa_spec.id;


--
-- Name: qa_supplier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.qa_supplier (
    id integer NOT NULL,
    supplier text NOT NULL,
    material text DEFAULT ''::text,
    rating text DEFAULT ''::text,
    ppm text DEFAULT ''::text,
    last_audit text DEFAULT ''::text,
    status text DEFAULT 'Pending'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.qa_supplier OWNER TO postgres;

--
-- Name: qa_supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.qa_supplier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.qa_supplier_id_seq OWNER TO postgres;

--
-- Name: qa_supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.qa_supplier_id_seq OWNED BY public.qa_supplier.id;


--
-- Name: receiving; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.receiving (
    id integer NOT NULL,
    rcv_number text NOT NULL,
    po_id integer,
    rcv_date text,
    supplier text,
    carrier text,
    tracking_number text,
    status text DEFAULT 'pending'::text,
    notes text,
    created_by text
);


ALTER TABLE public.receiving OWNER TO postgres;

--
-- Name: receiving_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.receiving_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.receiving_id_seq OWNER TO postgres;

--
-- Name: receiving_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.receiving_id_seq OWNED BY public.receiving.id;


--
-- Name: receiving_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.receiving_item (
    id integer NOT NULL,
    receiving_id integer NOT NULL,
    description text NOT NULL,
    product_id integer,
    qty_ordered integer DEFAULT 1,
    qty_received integer DEFAULT 0,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.receiving_item OWNER TO postgres;

--
-- Name: receiving_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.receiving_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.receiving_item_id_seq OWNER TO postgres;

--
-- Name: receiving_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.receiving_item_id_seq OWNED BY public.receiving_item.id;


--
-- Name: requisition_approval; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.requisition_approval (
    id integer NOT NULL,
    req_id integer NOT NULL,
    level text,
    approver_id integer,
    decision text,
    comment text,
    decided_date text
);


ALTER TABLE public.requisition_approval OWNER TO postgres;

--
-- Name: requisition_approval_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.requisition_approval_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.requisition_approval_id_seq OWNER TO postgres;

--
-- Name: requisition_approval_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.requisition_approval_id_seq OWNED BY public.requisition_approval.id;


--
-- Name: requisition_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.requisition_item (
    id integer NOT NULL,
    req_id integer NOT NULL,
    description text NOT NULL,
    product_id integer,
    qty integer DEFAULT 1,
    est_unit_price real DEFAULT 0.0
);


ALTER TABLE public.requisition_item OWNER TO postgres;

--
-- Name: requisition_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.requisition_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.requisition_item_id_seq OWNER TO postgres;

--
-- Name: requisition_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.requisition_item_id_seq OWNED BY public.requisition_item.id;


--
-- Name: rfq; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rfq (
    id integer NOT NULL,
    rfq_number text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    created_by text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rfq OWNER TO postgres;

--
-- Name: rfq_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rfq_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rfq_id_seq OWNER TO postgres;

--
-- Name: rfq_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rfq_id_seq OWNED BY public.rfq.id;


--
-- Name: rfq_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rfq_item (
    id integer NOT NULL,
    rfq_id integer NOT NULL,
    description text NOT NULL,
    product_id integer,
    qty integer DEFAULT 1 NOT NULL,
    target_price real DEFAULT 0.0 NOT NULL,
    awarded_vendor_id integer,
    po_id integer
);


ALTER TABLE public.rfq_item OWNER TO postgres;

--
-- Name: rfq_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rfq_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rfq_item_id_seq OWNER TO postgres;

--
-- Name: rfq_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rfq_item_id_seq OWNED BY public.rfq_item.id;


--
-- Name: rfq_quote_line; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rfq_quote_line (
    id integer NOT NULL,
    rfq_item_id integer NOT NULL,
    vendor_id integer NOT NULL,
    quoted_price real,
    lead_time_days integer
);


ALTER TABLE public.rfq_quote_line OWNER TO postgres;

--
-- Name: rfq_quote_line_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rfq_quote_line_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rfq_quote_line_id_seq OWNER TO postgres;

--
-- Name: rfq_quote_line_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rfq_quote_line_id_seq OWNED BY public.rfq_quote_line.id;


--
-- Name: rfq_vendor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rfq_vendor (
    id integer NOT NULL,
    rfq_id integer NOT NULL,
    supplier_id integer NOT NULL
);


ALTER TABLE public.rfq_vendor OWNER TO postgres;

--
-- Name: rfq_vendor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rfq_vendor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rfq_vendor_id_seq OWNER TO postgres;

--
-- Name: rfq_vendor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rfq_vendor_id_seq OWNED BY public.rfq_vendor.id;


--
-- Name: risk_assessment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.risk_assessment (
    id integer NOT NULL,
    title text NOT NULL,
    category text DEFAULT ''::text,
    likelihood text DEFAULT ''::text,
    impact text DEFAULT ''::text,
    risk_level text DEFAULT ''::text,
    owner text DEFAULT ''::text,
    assessed_date text DEFAULT ''::text,
    status text DEFAULT 'Identified'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.risk_assessment OWNER TO postgres;

--
-- Name: risk_assessment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.risk_assessment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.risk_assessment_id_seq OWNER TO postgres;

--
-- Name: risk_assessment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.risk_assessment_id_seq OWNED BY public.risk_assessment.id;


--
-- Name: risk_audit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.risk_audit (
    id integer NOT NULL,
    audit text NOT NULL,
    framework text DEFAULT ''::text,
    auditor text DEFAULT ''::text,
    scheduled_date text DEFAULT ''::text,
    completed_date text DEFAULT ''::text,
    finding text DEFAULT ''::text,
    status text DEFAULT 'Scheduled'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.risk_audit OWNER TO postgres;

--
-- Name: risk_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.risk_audit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.risk_audit_id_seq OWNER TO postgres;

--
-- Name: risk_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.risk_audit_id_seq OWNED BY public.risk_audit.id;


--
-- Name: risk_continuity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.risk_continuity (
    id integer NOT NULL,
    plan text NOT NULL,
    scope text DEFAULT ''::text,
    criticality text DEFAULT ''::text,
    owner text DEFAULT ''::text,
    last_tested text DEFAULT ''::text,
    next_test text DEFAULT ''::text,
    status text DEFAULT 'Draft'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.risk_continuity OWNER TO postgres;

--
-- Name: risk_continuity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.risk_continuity_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.risk_continuity_id_seq OWNER TO postgres;

--
-- Name: risk_continuity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.risk_continuity_id_seq OWNED BY public.risk_continuity.id;


--
-- Name: risk_insurance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.risk_insurance (
    id integer NOT NULL,
    policy text NOT NULL,
    insurer text DEFAULT ''::text,
    policy_type text DEFAULT ''::text,
    coverage real DEFAULT 0,
    premium real DEFAULT 0,
    start_date text DEFAULT ''::text,
    end_date text DEFAULT ''::text,
    status text DEFAULT 'Active'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.risk_insurance OWNER TO postgres;

--
-- Name: risk_insurance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.risk_insurance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.risk_insurance_id_seq OWNER TO postgres;

--
-- Name: risk_insurance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.risk_insurance_id_seq OWNED BY public.risk_insurance.id;


--
-- Name: risk_kri; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.risk_kri (
    id integer NOT NULL,
    indicator text NOT NULL,
    category text DEFAULT ''::text,
    threshold text DEFAULT ''::text,
    current_value text DEFAULT ''::text,
    owner text DEFAULT ''::text,
    measured_date text DEFAULT ''::text,
    status text DEFAULT 'Normal'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.risk_kri OWNER TO postgres;

--
-- Name: risk_kri_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.risk_kri_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.risk_kri_id_seq OWNER TO postgres;

--
-- Name: risk_kri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.risk_kri_id_seq OWNED BY public.risk_kri.id;


--
-- Name: risk_register; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.risk_register (
    id integer NOT NULL,
    risk text NOT NULL,
    category text DEFAULT ''::text,
    severity text DEFAULT ''::text,
    response text DEFAULT ''::text,
    owner text DEFAULT ''::text,
    target_date text DEFAULT ''::text,
    status text DEFAULT 'Open'::text,
    mitigation text DEFAULT ''::text
);


ALTER TABLE public.risk_register OWNER TO postgres;

--
-- Name: risk_register_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.risk_register_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.risk_register_id_seq OWNER TO postgres;

--
-- Name: risk_register_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.risk_register_id_seq OWNED BY public.risk_register.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    role_name text NOT NULL,
    description text
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: routing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.routing (
    id integer NOT NULL,
    product_id integer NOT NULL,
    operation_seq integer DEFAULT 10 NOT NULL,
    operation_name text NOT NULL,
    workcenter_id integer,
    std_hours real DEFAULT 0.0 NOT NULL,
    notes text,
    created_by text
);


ALTER TABLE public.routing OWNER TO postgres;

--
-- Name: routing_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.routing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.routing_id_seq OWNER TO postgres;

--
-- Name: routing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.routing_id_seq OWNED BY public.routing.id;


--
-- Name: sales_coaching_note; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_coaching_note (
    id integer NOT NULL,
    rep text NOT NULL,
    subject text DEFAULT ''::text,
    note text DEFAULT ''::text,
    status text DEFAULT 'Open'::text,
    coach text DEFAULT ''::text,
    created_by text DEFAULT ''::text,
    created_date text DEFAULT ''::text
);


ALTER TABLE public.sales_coaching_note OWNER TO postgres;

--
-- Name: sales_coaching_note_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_coaching_note_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_coaching_note_id_seq OWNER TO postgres;

--
-- Name: sales_coaching_note_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_coaching_note_id_seq OWNED BY public.sales_coaching_note.id;


--
-- Name: sales_commission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_commission (
    id integer NOT NULL,
    rep text NOT NULL,
    period text DEFAULT ''::text,
    sales_amount real DEFAULT 0,
    rate text DEFAULT ''::text,
    commission real DEFAULT 0,
    status text DEFAULT 'Pending'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.sales_commission OWNER TO postgres;

--
-- Name: sales_commission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_commission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_commission_id_seq OWNER TO postgres;

--
-- Name: sales_commission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_commission_id_seq OWNED BY public.sales_commission.id;


--
-- Name: sales_commission_plan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_commission_plan (
    id integer NOT NULL,
    name text NOT NULL,
    plan_type text DEFAULT 'Flat Rate'::text,
    rate real DEFAULT 0,
    description text DEFAULT ''::text,
    active boolean DEFAULT true,
    created_by text DEFAULT ''::text,
    created_date text DEFAULT ''::text
);


ALTER TABLE public.sales_commission_plan OWNER TO postgres;

--
-- Name: sales_commission_plan_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_commission_plan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_commission_plan_id_seq OWNER TO postgres;

--
-- Name: sales_commission_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_commission_plan_id_seq OWNED BY public.sales_commission_plan.id;


--
-- Name: sales_contract; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_contract (
    id integer NOT NULL,
    customer text NOT NULL,
    title text DEFAULT ''::text,
    value real DEFAULT 0,
    start_date text,
    end_date text,
    renewal_date text,
    status text DEFAULT 'Draft'::text,
    owner text DEFAULT ''::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text,
    created_date text DEFAULT ''::text
);


ALTER TABLE public.sales_contract OWNER TO postgres;

--
-- Name: sales_contract_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_contract_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_contract_id_seq OWNER TO postgres;

--
-- Name: sales_contract_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_contract_id_seq OWNED BY public.sales_contract.id;


--
-- Name: sales_customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_customer (
    id integer NOT NULL,
    name text NOT NULL,
    contact text DEFAULT ''::text,
    email text DEFAULT ''::text,
    phone text DEFAULT ''::text,
    segment text DEFAULT ''::text,
    region text DEFAULT ''::text,
    owner text DEFAULT ''::text,
    status text DEFAULT 'Prospect'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.sales_customer OWNER TO postgres;

--
-- Name: sales_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_customer_id_seq OWNER TO postgres;

--
-- Name: sales_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_customer_id_seq OWNED BY public.sales_customer.id;


--
-- Name: sales_forecast; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_forecast (
    id integer NOT NULL,
    rep text DEFAULT ''::text,
    period text DEFAULT ''::text,
    fiscal_year integer,
    product_line text DEFAULT ''::text,
    expected_value real DEFAULT 0,
    probability integer DEFAULT 0,
    weighted_value real DEFAULT 0,
    status text DEFAULT 'Draft'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text,
    created_date text DEFAULT ''::text
);


ALTER TABLE public.sales_forecast OWNER TO postgres;

--
-- Name: sales_forecast_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_forecast_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_forecast_id_seq OWNER TO postgres;

--
-- Name: sales_forecast_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_forecast_id_seq OWNED BY public.sales_forecast.id;


--
-- Name: sales_lead; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_lead (
    id integer NOT NULL,
    company text NOT NULL,
    contact text DEFAULT ''::text,
    source text DEFAULT ''::text,
    status text DEFAULT 'New'::text,
    priority text DEFAULT 'Medium'::text,
    estimated_value real DEFAULT 0,
    owner text DEFAULT ''::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text,
    created_date text DEFAULT ''::text
);


ALTER TABLE public.sales_lead OWNER TO postgres;

--
-- Name: sales_lead_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_lead_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_lead_id_seq OWNER TO postgres;

--
-- Name: sales_lead_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_lead_id_seq OWNED BY public.sales_lead.id;


--
-- Name: sales_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_order (
    id integer NOT NULL,
    so_number text NOT NULL,
    customer_id integer,
    order_date text,
    ship_date text,
    status text DEFAULT 'quote'::text,
    notes text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.sales_order OWNER TO postgres;

--
-- Name: sales_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_order_id_seq OWNER TO postgres;

--
-- Name: sales_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_order_id_seq OWNED BY public.sales_order.id;


--
-- Name: sales_perf_review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_perf_review (
    id integer NOT NULL,
    rep text NOT NULL,
    review_date text DEFAULT ''::text,
    period text DEFAULT ''::text,
    rating text DEFAULT ''::text,
    strengths text DEFAULT ''::text,
    improvements text DEFAULT ''::text,
    goals text DEFAULT ''::text,
    status text DEFAULT 'Scheduled'::text,
    reviewer text DEFAULT ''::text,
    created_by text DEFAULT ''::text,
    created_date text DEFAULT ''::text
);


ALTER TABLE public.sales_perf_review OWNER TO postgres;

--
-- Name: sales_perf_review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_perf_review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_perf_review_id_seq OWNER TO postgres;

--
-- Name: sales_perf_review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_perf_review_id_seq OWNED BY public.sales_perf_review.id;


--
-- Name: sales_quote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_quote (
    id integer NOT NULL,
    customer text NOT NULL,
    description text DEFAULT ''::text,
    amount real DEFAULT 0,
    owner text DEFAULT ''::text,
    quote_date text DEFAULT ''::text,
    valid_until text DEFAULT ''::text,
    status text DEFAULT 'Draft'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.sales_quote OWNER TO postgres;

--
-- Name: sales_quote_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_quote_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_quote_id_seq OWNER TO postgres;

--
-- Name: sales_quote_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_quote_id_seq OWNED BY public.sales_quote.id;


--
-- Name: sales_target; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_target (
    id integer NOT NULL,
    rep text NOT NULL,
    period text DEFAULT ''::text,
    target real DEFAULT 0,
    actual real DEFAULT 0,
    region text DEFAULT ''::text,
    status text DEFAULT 'On Track'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.sales_target OWNER TO postgres;

--
-- Name: sales_target_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_target_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_target_id_seq OWNER TO postgres;

--
-- Name: sales_target_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_target_id_seq OWNED BY public.sales_target.id;


--
-- Name: sales_territory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_territory (
    id integer NOT NULL,
    name text NOT NULL,
    region text DEFAULT ''::text,
    assigned_rep text DEFAULT ''::text,
    status text DEFAULT 'Active'::text,
    notes text DEFAULT ''::text,
    created_by text DEFAULT ''::text,
    created_date text DEFAULT ''::text
);


ALTER TABLE public.sales_territory OWNER TO postgres;

--
-- Name: sales_territory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_territory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_territory_id_seq OWNER TO postgres;

--
-- Name: sales_territory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_territory_id_seq OWNED BY public.sales_territory.id;


--
-- Name: serial_number; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.serial_number (
    id integer NOT NULL,
    serial_number text NOT NULL,
    product_id integer NOT NULL,
    lot_id integer,
    status text DEFAULT 'available'::text NOT NULL,
    notes text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.serial_number OWNER TO postgres;

--
-- Name: serial_number_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.serial_number_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.serial_number_id_seq OWNER TO postgres;

--
-- Name: serial_number_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.serial_number_id_seq OWNED BY public.serial_number.id;


--
-- Name: shipment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipment (
    id integer NOT NULL,
    ship_number text NOT NULL,
    so_id integer,
    ship_date text,
    carrier text,
    tracking_number text,
    status text DEFAULT 'pending'::text,
    notes text,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.shipment OWNER TO postgres;

--
-- Name: shipment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shipment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shipment_id_seq OWNER TO postgres;

--
-- Name: shipment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shipment_id_seq OWNED BY public.shipment.id;


--
-- Name: shipment_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shipment_item (
    id integer NOT NULL,
    shipment_id integer NOT NULL,
    description text NOT NULL,
    product_id integer,
    qty integer DEFAULT 1,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.shipment_item OWNER TO postgres;

--
-- Name: shipment_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.shipment_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.shipment_item_id_seq OWNER TO postgres;

--
-- Name: shipment_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.shipment_item_id_seq OWNED BY public.shipment_item.id;


--
-- Name: so_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.so_item (
    id integer NOT NULL,
    so_id integer NOT NULL,
    description text NOT NULL,
    product_id integer,
    qty integer DEFAULT 1,
    unit_price real DEFAULT 0.0,
    created_by text DEFAULT ''::text
);


ALTER TABLE public.so_item OWNER TO postgres;

--
-- Name: so_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.so_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.so_item_id_seq OWNER TO postgres;

--
-- Name: so_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.so_item_id_seq OWNED BY public.so_item.id;


--
-- Name: spc_control_limit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.spc_control_limit (
    id integer NOT NULL,
    product_id integer,
    characteristic text NOT NULL,
    ucl real NOT NULL,
    lcl real NOT NULL,
    target real,
    sigma real,
    subgroup_size integer DEFAULT 5 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_by text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.spc_control_limit OWNER TO postgres;

--
-- Name: spc_control_limit_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.spc_control_limit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.spc_control_limit_id_seq OWNER TO postgres;

--
-- Name: spc_control_limit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.spc_control_limit_id_seq OWNED BY public.spc_control_limit.id;


--
-- Name: spc_measurement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.spc_measurement (
    id integer NOT NULL,
    product_id integer,
    characteristic text NOT NULL,
    measured_value real NOT NULL,
    measured_by text DEFAULT ''::text NOT NULL,
    measured_at timestamp with time zone DEFAULT now() NOT NULL,
    wo_id integer,
    lot_id integer,
    in_control boolean DEFAULT true NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    created_by text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.spc_measurement OWNER TO postgres;

--
-- Name: spc_measurement_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.spc_measurement_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.spc_measurement_id_seq OWNER TO postgres;

--
-- Name: spc_measurement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.spc_measurement_id_seq OWNED BY public.spc_measurement.id;


--
-- Name: supplier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier (
    id integer NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    company_name text NOT NULL,
    phone_number text NOT NULL,
    address text NOT NULL,
    city text NOT NULL,
    state text NOT NULL,
    zip_code text NOT NULL,
    email text NOT NULL,
    created_by text
);


ALTER TABLE public.supplier OWNER TO postgres;

--
-- Name: supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.supplier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_id_seq OWNER TO postgres;

--
-- Name: supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.supplier_id_seq OWNED BY public.supplier.id;


--
-- Name: supplier_login; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier_login (
    id integer NOT NULL,
    supplier_id integer NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    created_at text DEFAULT ''::text
);


ALTER TABLE public.supplier_login OWNER TO postgres;

--
-- Name: supplier_login_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.supplier_login_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_login_id_seq OWNER TO postgres;

--
-- Name: supplier_login_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.supplier_login_id_seq OWNED BY public.supplier_login.id;


--
-- Name: tax; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tax (
    id integer,
    state text,
    percent integer
);


ALTER TABLE public.tax OWNER TO postgres;

--
-- Name: tax_calendar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tax_calendar (
    id integer NOT NULL,
    tax_type text NOT NULL,
    description text DEFAULT ''::text,
    due_date text NOT NULL,
    period text DEFAULT ''::text,
    status text DEFAULT 'Pending'::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.tax_calendar OWNER TO postgres;

--
-- Name: tax_calendar_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tax_calendar_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tax_calendar_id_seq OWNER TO postgres;

--
-- Name: tax_calendar_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tax_calendar_id_seq OWNED BY public.tax_calendar.id;


--
-- Name: tax_filing; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tax_filing (
    id integer NOT NULL,
    tax_type text NOT NULL,
    jurisdiction text DEFAULT ''::text,
    period text DEFAULT ''::text,
    amount_due real DEFAULT 0.0,
    amount_paid real DEFAULT 0.0,
    filed_date text DEFAULT ''::text,
    due_date text DEFAULT ''::text,
    status text DEFAULT 'Pending'::text,
    reference text DEFAULT ''::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.tax_filing OWNER TO postgres;

--
-- Name: tax_filing_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tax_filing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tax_filing_id_seq OWNER TO postgres;

--
-- Name: tax_filing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tax_filing_id_seq OWNED BY public.tax_filing.id;


--
-- Name: tax_payment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tax_payment (
    id integer NOT NULL,
    filing_id integer,
    tax_type text NOT NULL,
    jurisdiction text DEFAULT ''::text,
    period text DEFAULT ''::text,
    amount real DEFAULT 0.0,
    payment_date text DEFAULT ''::text,
    method text DEFAULT ''::text,
    reference text DEFAULT ''::text,
    notes text DEFAULT ''::text
);


ALTER TABLE public.tax_payment OWNER TO postgres;

--
-- Name: tax_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tax_payment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tax_payment_id_seq OWNER TO postgres;

--
-- Name: tax_payment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tax_payment_id_seq OWNED BY public.tax_payment.id;


--
-- Name: time_clock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.time_clock (
    id integer NOT NULL,
    people_id integer NOT NULL,
    clock_in text NOT NULL,
    clock_out text,
    notes text,
    hours_worked real,
    created_by text
);


ALTER TABLE public.time_clock OWNER TO postgres;

--
-- Name: time_clock_devices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.time_clock_devices (
    id integer NOT NULL,
    name text NOT NULL,
    location text DEFAULT ''::text NOT NULL,
    device_type text DEFAULT 'manual'::text NOT NULL,
    ip_address text DEFAULT ''::text NOT NULL,
    port integer DEFAULT 0 NOT NULL,
    config_json text DEFAULT '{}'::text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_by text
);


ALTER TABLE public.time_clock_devices OWNER TO postgres;

--
-- Name: time_clock_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.time_clock_devices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.time_clock_devices_id_seq OWNER TO postgres;

--
-- Name: time_clock_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.time_clock_devices_id_seq OWNED BY public.time_clock_devices.id;


--
-- Name: time_clock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.time_clock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.time_clock_id_seq OWNER TO postgres;

--
-- Name: time_clock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.time_clock_id_seq OWNED BY public.time_clock.id;


--
-- Name: time_clock_sync_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.time_clock_sync_log (
    id integer NOT NULL,
    device_id integer NOT NULL,
    synced_at text NOT NULL,
    status text DEFAULT 'ok'::text NOT NULL,
    records_imported integer DEFAULT 0 NOT NULL,
    error_msg text DEFAULT ''::text NOT NULL
);


ALTER TABLE public.time_clock_sync_log OWNER TO postgres;

--
-- Name: time_clock_sync_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.time_clock_sync_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.time_clock_sync_log_id_seq OWNER TO postgres;

--
-- Name: time_clock_sync_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.time_clock_sync_log_id_seq OWNED BY public.time_clock_sync_log.id;


--
-- Name: time_off_balance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.time_off_balance (
    id integer NOT NULL,
    people_id integer NOT NULL,
    year integer NOT NULL,
    allotted_days real DEFAULT 15.0 NOT NULL
);


ALTER TABLE public.time_off_balance OWNER TO postgres;

--
-- Name: time_off_balance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.time_off_balance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.time_off_balance_id_seq OWNER TO postgres;

--
-- Name: time_off_balance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.time_off_balance_id_seq OWNED BY public.time_off_balance.id;


--
-- Name: time_off_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.time_off_request (
    id integer NOT NULL,
    people_id integer NOT NULL,
    request_date text NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    request_type text DEFAULT 'Vacation'::text,
    status text DEFAULT 'pending'::text,
    notes text DEFAULT ''::text,
    created_by text
);


ALTER TABLE public.time_off_request OWNER TO postgres;

--
-- Name: time_off_request_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.time_off_request_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.time_off_request_id_seq OWNER TO postgres;

--
-- Name: time_off_request_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.time_off_request_id_seq OWNED BY public.time_off_request.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    people_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_roles_id_seq OWNER TO postgres;

--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: wo_cost_actual; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wo_cost_actual (
    id integer NOT NULL,
    wo_id integer NOT NULL,
    actual_material_cost real DEFAULT 0.0 NOT NULL,
    actual_labor_cost real DEFAULT 0.0 NOT NULL,
    actual_overhead_cost real DEFAULT 0.0 NOT NULL,
    total_actual_cost real DEFAULT 0.0 NOT NULL,
    std_cost real DEFAULT 0.0 NOT NULL,
    material_variance real DEFAULT 0.0 NOT NULL,
    labor_variance real DEFAULT 0.0 NOT NULL,
    total_variance real DEFAULT 0.0 NOT NULL,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.wo_cost_actual OWNER TO postgres;

--
-- Name: wo_cost_actual_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wo_cost_actual_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wo_cost_actual_id_seq OWNER TO postgres;

--
-- Name: wo_cost_actual_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wo_cost_actual_id_seq OWNED BY public.wo_cost_actual.id;


--
-- Name: wo_material; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wo_material (
    id integer NOT NULL,
    wo_id integer NOT NULL,
    product_id integer NOT NULL,
    qty_required real DEFAULT 1.0,
    qty_issued real DEFAULT 0.0,
    notes text,
    lot_id integer
);


ALTER TABLE public.wo_material OWNER TO postgres;

--
-- Name: wo_material_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wo_material_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wo_material_id_seq OWNER TO postgres;

--
-- Name: wo_material_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wo_material_id_seq OWNED BY public.wo_material.id;


--
-- Name: wo_operation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wo_operation (
    id integer NOT NULL,
    wo_id integer NOT NULL,
    routing_id integer,
    operation_seq integer DEFAULT 10 NOT NULL,
    operation_name text NOT NULL,
    workcenter_id integer,
    std_hours real DEFAULT 0.0 NOT NULL,
    actual_hours real,
    scrap_qty real DEFAULT 0.0 NOT NULL,
    rework_qty real DEFAULT 0.0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    completed_by text,
    notes text,
    created_by text DEFAULT ''::text,
    scheduled_start timestamp with time zone,
    scheduled_end timestamp with time zone
);


ALTER TABLE public.wo_operation OWNER TO postgres;

--
-- Name: wo_operation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.wo_operation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wo_operation_id_seq OWNER TO postgres;

--
-- Name: wo_operation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.wo_operation_id_seq OWNED BY public.wo_operation.id;


--
-- Name: work_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.work_order (
    id integer NOT NULL,
    wo_number text NOT NULL,
    product_id integer,
    description text,
    quantity integer DEFAULT 1,
    start_date text,
    due_date text,
    status text DEFAULT 'planned'::text,
    notes text,
    created_by text
);


ALTER TABLE public.work_order OWNER TO postgres;

--
-- Name: work_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.work_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.work_order_id_seq OWNER TO postgres;

--
-- Name: work_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.work_order_id_seq OWNED BY public.work_order.id;


--
-- Name: workcenter; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workcenter (
    id integer NOT NULL,
    name text NOT NULL,
    dept text DEFAULT ''::text NOT NULL,
    capacity_hours_per_day real DEFAULT 8.0 NOT NULL,
    labor_rate real DEFAULT 0.0 NOT NULL,
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    overhead_rate real DEFAULT 0.0 NOT NULL,
    created_by text
);


ALTER TABLE public.workcenter OWNER TO postgres;

--
-- Name: workcenter_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.workcenter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workcenter_id_seq OWNER TO postgres;

--
-- Name: workcenter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.workcenter_id_seq OWNED BY public.workcenter.id;


--
-- Name: ap_invoice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ap_invoice ALTER COLUMN id SET DEFAULT nextval('public.ap_invoice_id_seq'::regclass);


--
-- Name: ap_payment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ap_payment ALTER COLUMN id SET DEFAULT nextval('public.ap_payment_id_seq'::regclass);


--
-- Name: api_login_attempt id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_login_attempt ALTER COLUMN id SET DEFAULT nextval('public.api_login_attempt_id_seq'::regclass);


--
-- Name: approval_rule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_rule ALTER COLUMN id SET DEFAULT nextval('public.approval_rule_id_seq'::regclass);


--
-- Name: approval_step id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_step ALTER COLUMN id SET DEFAULT nextval('public.approval_step_id_seq'::regclass);


--
-- Name: ar_invoice id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_invoice ALTER COLUMN id SET DEFAULT nextval('public.ar_invoice_id_seq'::regclass);


--
-- Name: ar_payment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_payment ALTER COLUMN id SET DEFAULT nextval('public.ar_payment_id_seq'::regclass);


--
-- Name: audit_finding id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_finding ALTER COLUMN id SET DEFAULT nextval('public.audit_finding_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: audit_schedule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_schedule ALTER COLUMN id SET DEFAULT nextval('public.audit_schedule_id_seq'::regclass);


--
-- Name: bank_account id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_account ALTER COLUMN id SET DEFAULT nextval('public.bank_account_id_seq'::regclass);


--
-- Name: bank_reconciliation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_reconciliation ALTER COLUMN id SET DEFAULT nextval('public.bank_reconciliation_id_seq'::regclass);


--
-- Name: bank_statement id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_statement ALTER COLUMN id SET DEFAULT nextval('public.bank_statement_id_seq'::regclass);


--
-- Name: bank_statement_item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_statement_item ALTER COLUMN id SET DEFAULT nextval('public.bank_statement_item_id_seq'::regclass);


--
-- Name: bank_transaction id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_transaction ALTER COLUMN id SET DEFAULT nextval('public.bank_transaction_id_seq'::regclass);


--
-- Name: bom id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bom ALTER COLUMN id SET DEFAULT nextval('public.bom_id_seq'::regclass);


--
-- Name: budget id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget ALTER COLUMN id SET DEFAULT nextval('public.budget_id_seq'::regclass);


--
-- Name: budget_line id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_line ALTER COLUMN id SET DEFAULT nextval('public.budget_line_id_seq'::regclass);


--
-- Name: calls2 id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calls2 ALTER COLUMN id SET DEFAULT nextval('public.calls2_id_seq'::regclass);


--
-- Name: closed_periods id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.closed_periods ALTER COLUMN id SET DEFAULT nextval('public.closed_periods_id_seq'::regclass);


--
-- Name: collection_activity id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collection_activity ALTER COLUMN id SET DEFAULT nextval('public.collection_activity_id_seq'::regclass);


--
-- Name: compliance_checklist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_checklist ALTER COLUMN id SET DEFAULT nextval('public.compliance_checklist_id_seq'::regclass);


--
-- Name: compliance_checklist_item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_checklist_item ALTER COLUMN id SET DEFAULT nextval('public.compliance_checklist_item_id_seq'::regclass);


--
-- Name: compliance_template id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_template ALTER COLUMN id SET DEFAULT nextval('public.compliance_template_id_seq'::regclass);


--
-- Name: compliance_template_item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_template_item ALTER COLUMN id SET DEFAULT nextval('public.compliance_template_item_id_seq'::regclass);


--
-- Name: corrective_action id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.corrective_action ALTER COLUMN id SET DEFAULT nextval('public.corrective_action_id_seq'::regclass);


--
-- Name: cost_center id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cost_center ALTER COLUMN id SET DEFAULT nextval('public.cost_center_id_seq'::regclass);


--
-- Name: cost_roll id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cost_roll ALTER COLUMN id SET DEFAULT nextval('public.cost_roll_id_seq'::regclass);


--
-- Name: credit_account id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_account ALTER COLUMN id SET DEFAULT nextval('public.credit_account_id_seq'::regclass);


--
-- Name: credit_application id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_application ALTER COLUMN id SET DEFAULT nextval('public.credit_application_id_seq'::regclass);


--
-- Name: credit_limit_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_limit_history ALTER COLUMN id SET DEFAULT nextval('public.credit_limit_history_id_seq'::regclass);


--
-- Name: cs_improvement_plan id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cs_improvement_plan ALTER COLUMN id SET DEFAULT nextval('public.cs_improvement_plan_id_seq'::regclass);


--
-- Name: cs_kb_article id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cs_kb_article ALTER COLUMN id SET DEFAULT nextval('public.cs_kb_article_id_seq'::regclass);


--
-- Name: cs_return id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cs_return ALTER COLUMN id SET DEFAULT nextval('public.cs_return_id_seq'::regclass);


--
-- Name: cs_survey id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cs_survey ALTER COLUMN id SET DEFAULT nextval('public.cs_survey_id_seq'::regclass);


--
-- Name: cs_survey_response id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cs_survey_response ALTER COLUMN id SET DEFAULT nextval('public.cs_survey_response_id_seq'::regclass);


--
-- Name: cs_training id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cs_training ALTER COLUMN id SET DEFAULT nextval('public.cs_training_id_seq'::regclass);


--
-- Name: customer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer ALTER COLUMN id SET DEFAULT nextval('public.customer_id_seq'::regclass);


--
-- Name: dept dept_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dept ALTER COLUMN dept_id SET DEFAULT nextval('public.dept_dept_id_seq'::regclass);


--
-- Name: dept_sub dept_sub_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dept_sub ALTER COLUMN dept_sub_id SET DEFAULT nextval('public.dept_sub_dept_sub_id_seq'::regclass);


--
-- Name: employee_deduction id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_deduction ALTER COLUMN id SET DEFAULT nextval('public.employee_deduction_id_seq'::regclass);


--
-- Name: employee_pay id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_pay ALTER COLUMN id SET DEFAULT nextval('public.employee_pay_id_seq'::regclass);


--
-- Name: eng_design_review id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eng_design_review ALTER COLUMN id SET DEFAULT nextval('public.eng_design_review_id_seq'::regclass);


--
-- Name: eng_project id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eng_project ALTER COLUMN id SET DEFAULT nextval('public.eng_project_id_seq'::regclass);


--
-- Name: eng_standard id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eng_standard ALTER COLUMN id SET DEFAULT nextval('public.eng_standard_id_seq'::regclass);


--
-- Name: eng_task id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eng_task ALTER COLUMN id SET DEFAULT nextval('public.eng_task_id_seq'::regclass);


--
-- Name: gl_account id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_account ALTER COLUMN id SET DEFAULT nextval('public.gl_account_id_seq'::regclass);


--
-- Name: gl_account_map id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_account_map ALTER COLUMN id SET DEFAULT nextval('public.gl_account_map_id_seq'::regclass);


--
-- Name: gl_journal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_journal ALTER COLUMN id SET DEFAULT nextval('public.gl_journal_id_seq'::regclass);


--
-- Name: gl_journal_line id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_journal_line ALTER COLUMN id SET DEFAULT nextval('public.gl_journal_line_id_seq'::regclass);


--
-- Name: inventory_transaction id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transaction ALTER COLUMN id SET DEFAULT nextval('public.inventory_transaction_id_seq'::regclass);


--
-- Name: it_asset id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_asset ALTER COLUMN id SET DEFAULT nextval('public.it_asset_id_seq'::regclass);


--
-- Name: it_asset_history id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_asset_history ALTER COLUMN id SET DEFAULT nextval('public.it_asset_history_id_seq'::regclass);


--
-- Name: it_bandwidth_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_bandwidth_log ALTER COLUMN id SET DEFAULT nextval('public.it_bandwidth_log_id_seq'::regclass);


--
-- Name: it_license id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_license ALTER COLUMN id SET DEFAULT nextval('public.it_license_id_seq'::regclass);


--
-- Name: it_network_device id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_network_device ALTER COLUMN id SET DEFAULT nextval('public.it_network_device_id_seq'::regclass);


--
-- Name: it_network_incident id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_network_incident ALTER COLUMN id SET DEFAULT nextval('public.it_network_incident_id_seq'::regclass);


--
-- Name: it_repair id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_repair ALTER COLUMN id SET DEFAULT nextval('public.it_repair_id_seq'::regclass);


--
-- Name: it_software_install id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_software_install ALTER COLUMN id SET DEFAULT nextval('public.it_software_install_id_seq'::regclass);


--
-- Name: it_task id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_task ALTER COLUMN id SET DEFAULT nextval('public.it_task_id_seq'::regclass);


--
-- Name: it_ticket id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_ticket ALTER COLUMN id SET DEFAULT nextval('public.it_ticket_id_seq'::regclass);


--
-- Name: legal_compliance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_compliance ALTER COLUMN id SET DEFAULT nextval('public.legal_compliance_id_seq'::regclass);


--
-- Name: legal_contract id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_contract ALTER COLUMN id SET DEFAULT nextval('public.legal_contract_id_seq'::regclass);


--
-- Name: legal_employment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_employment ALTER COLUMN id SET DEFAULT nextval('public.legal_employment_id_seq'::regclass);


--
-- Name: legal_governance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_governance ALTER COLUMN id SET DEFAULT nextval('public.legal_governance_id_seq'::regclass);


--
-- Name: legal_ip id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_ip ALTER COLUMN id SET DEFAULT nextval('public.legal_ip_id_seq'::regclass);


--
-- Name: legal_litigation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_litigation ALTER COLUMN id SET DEFAULT nextval('public.legal_litigation_id_seq'::regclass);


--
-- Name: location id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location ALTER COLUMN id SET DEFAULT nextval('public.location_id_seq'::regclass);


--
-- Name: lot id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lot ALTER COLUMN id SET DEFAULT nextval('public.lot_id_seq'::regclass);


--
-- Name: maint_downtime id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_downtime ALTER COLUMN id SET DEFAULT nextval('public.maint_downtime_id_seq'::regclass);


--
-- Name: maint_equipment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_equipment ALTER COLUMN id SET DEFAULT nextval('public.maint_equipment_id_seq'::regclass);


--
-- Name: maint_inspection id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_inspection ALTER COLUMN id SET DEFAULT nextval('public.maint_inspection_id_seq'::regclass);


--
-- Name: maint_mechanic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_mechanic ALTER COLUMN id SET DEFAULT nextval('public.maint_mechanic_id_seq'::regclass);


--
-- Name: maint_part id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_part ALTER COLUMN id SET DEFAULT nextval('public.maint_part_id_seq'::regclass);


--
-- Name: maint_schedule id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_schedule ALTER COLUMN id SET DEFAULT nextval('public.maint_schedule_id_seq'::regclass);


--
-- Name: maint_work_order id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_work_order ALTER COLUMN id SET DEFAULT nextval('public.maint_work_order_id_seq'::regclass);


--
-- Name: marketing_ad id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_ad ALTER COLUMN id SET DEFAULT nextval('public.marketing_ad_id_seq'::regclass);


--
-- Name: marketing_analytics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_analytics ALTER COLUMN id SET DEFAULT nextval('public.marketing_analytics_id_seq'::regclass);


--
-- Name: marketing_budget id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_budget ALTER COLUMN id SET DEFAULT nextval('public.marketing_budget_id_seq'::regclass);


--
-- Name: marketing_campaign id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_campaign ALTER COLUMN id SET DEFAULT nextval('public.marketing_campaign_id_seq'::regclass);


--
-- Name: marketing_content id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_content ALTER COLUMN id SET DEFAULT nextval('public.marketing_content_id_seq'::regclass);


--
-- Name: marketing_lead id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_lead ALTER COLUMN id SET DEFAULT nextval('public.marketing_lead_id_seq'::regclass);


--
-- Name: marketing_research id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_research ALTER COLUMN id SET DEFAULT nextval('public.marketing_research_id_seq'::regclass);


--
-- Name: mrp_planned_order id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrp_planned_order ALTER COLUMN id SET DEFAULT nextval('public.mrp_planned_order_id_seq'::regclass);


--
-- Name: mrp_run id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrp_run ALTER COLUMN id SET DEFAULT nextval('public.mrp_run_id_seq'::regclass);


--
-- Name: notification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification ALTER COLUMN id SET DEFAULT nextval('public.notification_id_seq'::regclass);


--
-- Name: passwd id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passwd ALTER COLUMN id SET DEFAULT nextval('public.passwd_id_seq'::regclass);


--
-- Name: payroll_deduction_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_deduction_type ALTER COLUMN id SET DEFAULT nextval('public.payroll_deduction_type_id_seq'::regclass);


--
-- Name: payroll_entry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_entry ALTER COLUMN id SET DEFAULT nextval('public.payroll_entry_id_seq'::regclass);


--
-- Name: payroll_entry_deduction id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_entry_deduction ALTER COLUMN id SET DEFAULT nextval('public.payroll_entry_deduction_id_seq'::regclass);


--
-- Name: payroll_run id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_run ALTER COLUMN id SET DEFAULT nextval('public.payroll_run_id_seq'::regclass);


--
-- Name: people id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.people ALTER COLUMN id SET DEFAULT nextval('public.people_id_seq'::regclass);


--
-- Name: pers_review id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pers_review ALTER COLUMN id SET DEFAULT nextval('public.pers_review_id_seq'::regclass);


--
-- Name: pers_training id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pers_training ALTER COLUMN id SET DEFAULT nextval('public.pers_training_id_seq'::regclass);


--
-- Name: po_approval id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.po_approval ALTER COLUMN id SET DEFAULT nextval('public.po_approval_id_seq'::regclass);


--
-- Name: po_item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.po_item ALTER COLUMN id SET DEFAULT nextval('public.po_item_id_seq'::regclass);


--
-- Name: position id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."position" ALTER COLUMN id SET DEFAULT nextval('public.position_id_seq'::regclass);


--
-- Name: product id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product ALTER COLUMN id SET DEFAULT nextval('public.product_id_seq'::regclass);


--
-- Name: purchase_order id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order ALTER COLUMN id SET DEFAULT nextval('public.purchase_order_id_seq'::regclass);


--
-- Name: purchase_requisition id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_requisition ALTER COLUMN id SET DEFAULT nextval('public.purchase_requisition_id_seq'::regclass);


--
-- Name: qa_audit id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_audit ALTER COLUMN id SET DEFAULT nextval('public.qa_audit_id_seq'::regclass);


--
-- Name: qa_capa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_capa ALTER COLUMN id SET DEFAULT nextval('public.qa_capa_id_seq'::regclass);


--
-- Name: qa_defect id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_defect ALTER COLUMN id SET DEFAULT nextval('public.qa_defect_id_seq'::regclass);


--
-- Name: qa_inspection id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_inspection ALTER COLUMN id SET DEFAULT nextval('public.qa_inspection_id_seq'::regclass);


--
-- Name: qa_ncr id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_ncr ALTER COLUMN id SET DEFAULT nextval('public.qa_ncr_id_seq'::regclass);


--
-- Name: qa_spec id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_spec ALTER COLUMN id SET DEFAULT nextval('public.qa_spec_id_seq'::regclass);


--
-- Name: qa_supplier id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_supplier ALTER COLUMN id SET DEFAULT nextval('public.qa_supplier_id_seq'::regclass);


--
-- Name: receiving id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receiving ALTER COLUMN id SET DEFAULT nextval('public.receiving_id_seq'::regclass);


--
-- Name: receiving_item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receiving_item ALTER COLUMN id SET DEFAULT nextval('public.receiving_item_id_seq'::regclass);


--
-- Name: requisition_approval id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requisition_approval ALTER COLUMN id SET DEFAULT nextval('public.requisition_approval_id_seq'::regclass);


--
-- Name: requisition_item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requisition_item ALTER COLUMN id SET DEFAULT nextval('public.requisition_item_id_seq'::regclass);


--
-- Name: rfq id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq ALTER COLUMN id SET DEFAULT nextval('public.rfq_id_seq'::regclass);


--
-- Name: rfq_item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_item ALTER COLUMN id SET DEFAULT nextval('public.rfq_item_id_seq'::regclass);


--
-- Name: rfq_quote_line id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_quote_line ALTER COLUMN id SET DEFAULT nextval('public.rfq_quote_line_id_seq'::regclass);


--
-- Name: rfq_vendor id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_vendor ALTER COLUMN id SET DEFAULT nextval('public.rfq_vendor_id_seq'::regclass);


--
-- Name: risk_assessment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.risk_assessment ALTER COLUMN id SET DEFAULT nextval('public.risk_assessment_id_seq'::regclass);


--
-- Name: risk_audit id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.risk_audit ALTER COLUMN id SET DEFAULT nextval('public.risk_audit_id_seq'::regclass);


--
-- Name: risk_continuity id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.risk_continuity ALTER COLUMN id SET DEFAULT nextval('public.risk_continuity_id_seq'::regclass);


--
-- Name: risk_insurance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.risk_insurance ALTER COLUMN id SET DEFAULT nextval('public.risk_insurance_id_seq'::regclass);


--
-- Name: risk_kri id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.risk_kri ALTER COLUMN id SET DEFAULT nextval('public.risk_kri_id_seq'::regclass);


--
-- Name: risk_register id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.risk_register ALTER COLUMN id SET DEFAULT nextval('public.risk_register_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: routing id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routing ALTER COLUMN id SET DEFAULT nextval('public.routing_id_seq'::regclass);


--
-- Name: sales_coaching_note id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_coaching_note ALTER COLUMN id SET DEFAULT nextval('public.sales_coaching_note_id_seq'::regclass);


--
-- Name: sales_commission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_commission ALTER COLUMN id SET DEFAULT nextval('public.sales_commission_id_seq'::regclass);


--
-- Name: sales_commission_plan id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_commission_plan ALTER COLUMN id SET DEFAULT nextval('public.sales_commission_plan_id_seq'::regclass);


--
-- Name: sales_contract id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_contract ALTER COLUMN id SET DEFAULT nextval('public.sales_contract_id_seq'::regclass);


--
-- Name: sales_customer id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_customer ALTER COLUMN id SET DEFAULT nextval('public.sales_customer_id_seq'::regclass);


--
-- Name: sales_forecast id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_forecast ALTER COLUMN id SET DEFAULT nextval('public.sales_forecast_id_seq'::regclass);


--
-- Name: sales_lead id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_lead ALTER COLUMN id SET DEFAULT nextval('public.sales_lead_id_seq'::regclass);


--
-- Name: sales_order id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order ALTER COLUMN id SET DEFAULT nextval('public.sales_order_id_seq'::regclass);


--
-- Name: sales_perf_review id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_perf_review ALTER COLUMN id SET DEFAULT nextval('public.sales_perf_review_id_seq'::regclass);


--
-- Name: sales_quote id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_quote ALTER COLUMN id SET DEFAULT nextval('public.sales_quote_id_seq'::regclass);


--
-- Name: sales_target id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_target ALTER COLUMN id SET DEFAULT nextval('public.sales_target_id_seq'::regclass);


--
-- Name: sales_territory id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_territory ALTER COLUMN id SET DEFAULT nextval('public.sales_territory_id_seq'::regclass);


--
-- Name: serial_number id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serial_number ALTER COLUMN id SET DEFAULT nextval('public.serial_number_id_seq'::regclass);


--
-- Name: shipment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipment ALTER COLUMN id SET DEFAULT nextval('public.shipment_id_seq'::regclass);


--
-- Name: shipment_item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipment_item ALTER COLUMN id SET DEFAULT nextval('public.shipment_item_id_seq'::regclass);


--
-- Name: so_item id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.so_item ALTER COLUMN id SET DEFAULT nextval('public.so_item_id_seq'::regclass);


--
-- Name: spc_control_limit id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spc_control_limit ALTER COLUMN id SET DEFAULT nextval('public.spc_control_limit_id_seq'::regclass);


--
-- Name: spc_measurement id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spc_measurement ALTER COLUMN id SET DEFAULT nextval('public.spc_measurement_id_seq'::regclass);


--
-- Name: supplier id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier ALTER COLUMN id SET DEFAULT nextval('public.supplier_id_seq'::regclass);


--
-- Name: supplier_login id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_login ALTER COLUMN id SET DEFAULT nextval('public.supplier_login_id_seq'::regclass);


--
-- Name: tax_calendar id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_calendar ALTER COLUMN id SET DEFAULT nextval('public.tax_calendar_id_seq'::regclass);


--
-- Name: tax_filing id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_filing ALTER COLUMN id SET DEFAULT nextval('public.tax_filing_id_seq'::regclass);


--
-- Name: tax_payment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_payment ALTER COLUMN id SET DEFAULT nextval('public.tax_payment_id_seq'::regclass);


--
-- Name: time_clock id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_clock ALTER COLUMN id SET DEFAULT nextval('public.time_clock_id_seq'::regclass);


--
-- Name: time_clock_devices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_clock_devices ALTER COLUMN id SET DEFAULT nextval('public.time_clock_devices_id_seq'::regclass);


--
-- Name: time_clock_sync_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_clock_sync_log ALTER COLUMN id SET DEFAULT nextval('public.time_clock_sync_log_id_seq'::regclass);


--
-- Name: time_off_balance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_off_balance ALTER COLUMN id SET DEFAULT nextval('public.time_off_balance_id_seq'::regclass);


--
-- Name: time_off_request id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_off_request ALTER COLUMN id SET DEFAULT nextval('public.time_off_request_id_seq'::regclass);


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Name: wo_cost_actual id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wo_cost_actual ALTER COLUMN id SET DEFAULT nextval('public.wo_cost_actual_id_seq'::regclass);


--
-- Name: wo_material id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wo_material ALTER COLUMN id SET DEFAULT nextval('public.wo_material_id_seq'::regclass);


--
-- Name: wo_operation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wo_operation ALTER COLUMN id SET DEFAULT nextval('public.wo_operation_id_seq'::regclass);


--
-- Name: work_order id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.work_order ALTER COLUMN id SET DEFAULT nextval('public.work_order_id_seq'::regclass);


--
-- Name: workcenter id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workcenter ALTER COLUMN id SET DEFAULT nextval('public.workcenter_id_seq'::regclass);


--
-- Data for Name: ap_invoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ap_invoice (id, vendor_id, invoice_number, invoice_date, due_date, amount, description, status, created_by) FROM stdin;
1	\N	SMPL-ACCT-AP-2026-001	2026-06-01	2026-06-06	12400	Steel sheet order — Invoice MFC-4412	open	seed
2	\N	SMPL-ACCT-AP-2026-002	2026-06-08	2026-06-20	5850	ABS resin resupply — Invoice AP-8821	open	seed
3	\N	SMPL-ACCT-AP-2026-003	2026-05-27	2026-05-27	3200	Fastener batch — Invoice FPS-1199	overdue	seed
4	\N	SMPL-ACCT-AP-2026-004	2026-05-17	2026-05-07	8900	Hydraulic hose order — Invoice VH-5532	paid	seed
5	\N	SMPL-ACCT-AP-2026-005	2026-06-11	2026-06-26	2750	Epoxy primer supply — Invoice PT-0034	open	seed
6	\N	SMPL-ACCT-AP-2026-006	2026-05-07	2026-04-17	16500	PCB assemblies Q1 — Invoice AE-2290	paid	seed
7	\N	SMPL-ACCT-AP-2026-007	2026-06-18	2026-07-10	4100	Bearing restock — Invoice NEB-0778	open	seed
8	\N	SMPL-ACCT-AP-2026-008	2026-04-27	2026-03-28	9500	Engineering consulting Q1 — Invoice AC-1100	paid	seed
\.


--
-- Data for Name: ap_payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ap_payment (id, invoice_id, payment_date, amount, payment_method, reference, notes) FROM stdin;
1	4	2026-06-18	8900	ACH	ACH-20260618-VH	Sample data
2	6	2026-06-08	16500	Wire	WIRE-20260608-AE	Sample data
3	8	2026-05-29	9500	Check	CHK-10042	Sample data
\.


--
-- Data for Name: api_login_attempt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_login_attempt (id, identifier, attempted_at, success) FROM stdin;
1	james.carter@example.com	2026-07-07 13:03:59.066629-04	t
2	james.carter@example.com	2026-07-07 13:04:38.524453-04	t
3	james.carter@example.com	2026-07-07 13:07:32.599024-04	t
\.


--
-- Data for Name: api_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_token (token, people_id, created_at, expires_at) FROM stdin;
26c77224e9ac4c2e986bf4d604ea3827	101	2026-06-28T01:54:23.220618	\N
16604cbaebfe4dd5a38ffe594d9dfacf	101	2026-07-07T17:03:59.291705+00:00	2026-07-08T01:03:59.291689+00:00
2d625c84a85a4078bdd8d6848329e727	101	2026-07-07T17:04:38.749705+00:00	2026-07-08T01:04:38.749691+00:00
d06dec1293784b0eb27578ca6205126a	101	2026-07-07T17:07:32.821367+00:00	2026-07-08T01:07:32.821354+00:00
\.


--
-- Data for Name: api_totp_secret; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_totp_secret (people_id, secret_b32, enabled, created_at) FROM stdin;
\.


--
-- Data for Name: approval_rule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.approval_rule (id, entity_type, dept_key, threshold_amount, approver_role, seq, escalate_after_hours, is_active, notes) FROM stdin;
1	purchase_requisition		100	Department Manager	10	24	t	SMPL-OPS-
2	purchase_requisition		1000	Purchasing Manager	20	48	t	SMPL-OPS-
3	purchase_order		1000	Purchasing Manager	10	24	t	SMPL-OPS-
4	purchase_order		10000	Vice President	20	48	t	SMPL-OPS-
5	gl_journal		10000	Controller	10	24	t	SMPL-OPS-
\.


--
-- Data for Name: approval_step; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.approval_step (id, rule_id, entity_type, entity_id, seq, status, approver_role, decided_by, decided_at, notes, created_at) FROM stdin;
\.


--
-- Data for Name: ar_invoice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_invoice (id, customer_id, invoice_number, invoice_date, due_date, amount, description, status, created_by) FROM stdin;
1	1	SMPL-ACCT-AR-2026-001	2026-06-06	2026-06-16	48500	Valve assembly order — SO-2026-0142	open	seed
2	1	SMPL-ACCT-AR-2026-002	2026-05-22	2026-05-17	31200	Bearing products Q2 — SO-2026-0128	overdue	seed
3	1	SMPL-ACCT-AR-2026-003	2026-05-07	2026-04-17	22300	Parts kit blanket order — SO-2026-0115	paid	seed
4	1	SMPL-ACCT-AR-2026-004	2026-06-16	2026-07-06	118000	Partnership supply contract — SO-2026-0155	partial	seed
5	1	SMPL-ACCT-AR-2026-005	2026-06-21	2026-07-16	4100	Trial order — SO-2026-0160	open	seed
6	1	SMPL-ACCT-AR-2026-006	2026-05-12	2026-04-27	8400	Shaft collar batch — SO-2026-0108	paid	seed
7	1	SMPL-ACCT-AR-2026-007	2026-06-23	2026-07-20	67000	Retrofit kit supply — SO-2026-0162	open	seed
\.


--
-- Data for Name: ar_payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ar_payment (id, invoice_id, payment_date, amount, payment_method, reference, notes) FROM stdin;
1	3	2026-06-08	22300	ACH	ACH-20260608-GF	Sample data
2	6	2026-06-14	8400	Check	CHK-20260614-DC	Sample data
3	4	2026-06-23	50000	Wire	WIRE-20260623-BE	Sample data
\.


--
-- Data for Name: audit_finding; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_finding (id, audit_id, finding_ref, description, severity, department, found_date, status, notes, created_by) FROM stdin;
1	2	SMPL-FIN-F-001	Invoice approval threshold not consistently followed	Minor	Finance	2026-04-05	Open	Sample data	\N
2	2	SMPL-FIN-F-002	Two GL entries posted without dual approval	Moderate	Finance	2026-04-06	Open	Sample data	\N
3	3	SMPL-FIN-F-003	User access review overdue by 45 days	Minor	IT	2026-05-15	Open	Sample data	\N
4	3	SMPL-FIN-F-004	Backup restoration test not completed Q1	Major	IT	2026-05-16	Open	Sample data	\N
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, table_name, record_id, action, changed_by, changed_at, old_values, new_values) FROM stdin;
1	maint_work_order	1	INSERT		2026-06-26 23:36:07.159746-04	\N	{"id": 1, "notes": "Sample data", "title": "Replace worn bearings on CNC Mill #1", "status": "In Progress", "due_date": "2026-06-27", "priority": "High", "equipment": "CNC Mill #1", "work_type": "Replacement", "created_by": "seed", "assigned_to": "SMPL-MAINT-Bob Harmon", "completed_date": "", "requested_date": "2026-06-23"}
2	maint_work_order	2	INSERT		2026-06-26 23:36:07.159746-04	\N	{"id": 2, "notes": "Sample data", "title": "Quarterly PM — Hydraulic Press", "status": "Assigned", "due_date": "2026-06-19", "priority": "Medium", "equipment": "Hydraulic Press", "work_type": "Preventive", "created_by": "seed", "assigned_to": "SMPL-MAINT-Carlos Vega", "completed_date": "", "requested_date": "2026-06-19"}
3	maint_work_order	3	INSERT		2026-06-26 23:36:07.159746-04	\N	{"id": 3, "notes": "Sample data", "title": "Air compressor pressure relief check", "status": "Open", "due_date": "2026-06-27", "priority": "High", "equipment": "Air Compressor", "work_type": "Inspection", "created_by": "seed", "assigned_to": "SMPL-MAINT-Denise Fowler", "completed_date": "", "requested_date": "2026-06-25"}
4	maint_work_order	4	INSERT		2026-06-26 23:36:07.159746-04	\N	{"id": 4, "notes": "Sample data", "title": "Laser cutter alignment & calibration", "status": "In Progress", "due_date": "2026-06-25", "priority": "Critical", "equipment": "Laser Cutter", "work_type": "Calibration", "created_by": "seed", "assigned_to": "SMPL-MAINT-Bob Harmon", "completed_date": "", "requested_date": "2026-06-24"}
5	maint_work_order	5	INSERT		2026-06-26 23:36:07.159746-04	\N	{"id": 5, "notes": "Sample data", "title": "Industrial chiller coil cleaning", "status": "Assigned", "due_date": "2026-06-26", "priority": "Critical", "equipment": "Industrial Chiller", "work_type": "Cleaning", "created_by": "seed", "assigned_to": "SMPL-MAINT-Tim Okafor", "completed_date": "", "requested_date": "2026-06-25"}
6	maint_work_order	6	INSERT		2026-06-26 23:36:07.159746-04	\N	{"id": 6, "notes": "Sample data", "title": "Conveyor belt tension adjustment", "status": "Completed", "due_date": "2026-06-02", "priority": "Medium", "equipment": "Conveyor Belt #1", "work_type": "Repair", "created_by": "seed", "assigned_to": "SMPL-MAINT-Bob Harmon", "completed_date": "2026-06-03", "requested_date": "2026-06-12"}
7	maint_work_order	7	INSERT		2026-06-26 23:36:07.159746-04	\N	{"id": 7, "notes": "Sample data", "title": "Paint booth filter replacement", "status": "On Hold", "due_date": "2026-06-24", "priority": "Medium", "equipment": "Paint Booth", "work_type": "Replacement", "created_by": "seed", "assigned_to": "SMPL-MAINT-Ed Paulson", "completed_date": "", "requested_date": "2026-06-21"}
8	maint_work_order	8	INSERT		2026-06-26 23:36:07.159746-04	\N	{"id": 8, "notes": "Sample data", "title": "Annual overhead crane inspection", "status": "Completed", "due_date": "2026-04-30", "priority": "High", "equipment": "Overhead Crane", "work_type": "Inspection", "created_by": "seed", "assigned_to": "SMPL-MAINT-Lynn Marsh", "completed_date": "2026-05-01", "requested_date": "2026-05-27"}
9	maint_work_order	9	INSERT		2026-06-26 23:36:07.159746-04	\N	{"id": 9, "notes": "Sample data", "title": "MIG welder electrode tip replacement", "status": "Open", "due_date": "2026-06-29", "priority": "Low", "equipment": "MIG Welder", "work_type": "Replacement", "created_by": "seed", "assigned_to": "SMPL-MAINT-Carlos Vega", "completed_date": "", "requested_date": "2026-06-24"}
10	maint_work_order	10	INSERT		2026-06-26 23:36:07.159746-04	\N	{"id": 10, "notes": "Sample data", "title": "Injection molder hydraulic fluid flush", "status": "Completed", "due_date": "2026-06-11", "priority": "Medium", "equipment": "Injection Molder", "work_type": "Preventive", "created_by": "seed", "assigned_to": "SMPL-MAINT-Carlos Vega", "completed_date": "2026-06-12", "requested_date": "2026-06-16"}
11	payroll_run	1	INSERT		2026-06-27 00:05:56.189511-04	\N	{"id": 1, "status": "processed", "run_date": "2026-05-15", "created_by": "seed", "pay_frequency": "Bi-Weekly", "pay_period_end": "2026-05-15", "state_tax_rate": 0.05, "federal_tax_rate": 0.22, "pay_period_start": "2026-05-02"}
12	payroll_entry	1	INSERT		2026-06-27 00:05:56.189511-04	\N	{"id": 1, "run_id": 1, "net_pay": 2609.56, "medicare": 58.46, "gross_pay": 4615.38, "people_id": 101, "state_tax": 201.57, "federal_tax": 886.92, "regular_hours": 0, "overtime_hours": 0, "social_security": 249.95, "pre_tax_deductions": 583.92, "post_tax_deductions": 25}
13	payroll_entry	2	INSERT		2026-06-27 00:05:56.189511-04	\N	{"id": 2, "run_id": 1, "net_pay": 1821.83, "medicare": 40.76, "gross_pay": 3269.23, "people_id": 102, "state_tax": 140.54, "federal_tax": 618.37, "regular_hours": 0, "overtime_hours": 0, "social_security": 174.27, "pre_tax_deductions": 458.46, "post_tax_deductions": 15}
14	payroll_entry	3	INSERT		2026-06-27 00:05:56.189511-04	\N	{"id": 3, "run_id": 1, "net_pay": 882.23, "medicare": 19.57, "gross_pay": 1600, "people_id": 109, "state_tax": 67.5, "federal_tax": 297, "regular_hours": 80, "overtime_hours": 0, "social_security": 83.7, "pre_tax_deductions": 250, "post_tax_deductions": 0}
15	payroll_entry	4	INSERT		2026-06-27 00:05:56.189511-04	\N	{"id": 4, "run_id": 1, "net_pay": 1091.35, "medicare": 24.21, "gross_pay": 1920, "people_id": 110, "state_tax": 83.5, "federal_tax": 367.4, "regular_hours": 80, "overtime_hours": 0, "social_security": 103.54, "pre_tax_deductions": 250, "post_tax_deductions": 0}
16	payroll_entry	5	INSERT		2026-06-27 00:05:56.189511-04	\N	{"id": 5, "run_id": 1, "net_pay": 856.08, "medicare": 19, "gross_pay": 1560, "people_id": 111, "state_tax": 65.5, "federal_tax": 288.2, "regular_hours": 80, "overtime_hours": 0, "social_security": 81.22, "pre_tax_deductions": 250, "post_tax_deductions": 0}
17	payroll_entry	6	INSERT		2026-06-27 00:05:56.189511-04	\N	{"id": 6, "run_id": 1, "net_pay": 1155.13, "medicare": 25.63, "gross_pay": 2080, "people_id": 115, "state_tax": 88.38, "federal_tax": 388.87, "regular_hours": 80, "overtime_hours": 0, "social_security": 109.59, "pre_tax_deductions": 312.4, "post_tax_deductions": 0}
18	payroll_entry	7	INSERT		2026-06-27 00:05:56.189511-04	\N	{"id": 7, "run_id": 1, "net_pay": 1442.67, "medicare": 32.01, "gross_pay": 2560, "people_id": 116, "state_tax": 110.38, "federal_tax": 485.67, "regular_hours": 80, "overtime_hours": 0, "social_security": 136.87, "pre_tax_deductions": 352.4, "post_tax_deductions": 0}
37	payroll_run	3	INSERT		2026-06-27 00:05:56.212065-04	\N	{"id": 3, "status": "processed", "run_date": "2026-06-12", "created_by": "seed", "pay_frequency": "Bi-Weekly", "pay_period_end": "2026-06-12", "state_tax_rate": 0.05, "federal_tax_rate": 0.22, "pay_period_start": "2026-05-30"}
19	payroll_entry	8	INSERT		2026-06-27 00:05:56.189511-04	\N	{"id": 8, "run_id": 1, "net_pay": 1375.62, "medicare": 30.52, "gross_pay": 2500, "people_id": 117, "state_tax": 105.25, "federal_tax": 463.1, "regular_hours": 0, "overtime_hours": 0, "social_security": 130.51, "pre_tax_deductions": 395, "post_tax_deductions": 0}
20	payroll_entry	9	INSERT		2026-06-27 00:05:56.189511-04	\N	{"id": 9, "run_id": 1, "net_pay": 1933.39, "medicare": 43.23, "gross_pay": 3461.54, "people_id": 121, "state_tax": 149.07, "federal_tax": 655.92, "regular_hours": 0, "overtime_hours": 0, "social_security": 184.85, "pre_tax_deductions": 480.08, "post_tax_deductions": 15}
21	payroll_entry	10	INSERT		2026-06-27 00:05:56.189511-04	\N	{"id": 10, "run_id": 1, "net_pay": 1091.35, "medicare": 24.21, "gross_pay": 1920, "people_id": 123, "state_tax": 83.5, "federal_tax": 367.4, "regular_hours": 80, "overtime_hours": 0, "social_security": 103.54, "pre_tax_deductions": 250, "post_tax_deductions": 0}
22	payroll_entry	11	INSERT		2026-06-27 00:05:56.189511-04	\N	{"id": 11, "run_id": 1, "net_pay": 1543.26, "medicare": 34.24, "gross_pay": 2692.31, "people_id": 125, "state_tax": 118.08, "federal_tax": 519.54, "regular_hours": 0, "overtime_hours": 0, "social_security": 146.42, "pre_tax_deductions": 330.77, "post_tax_deductions": 0}
23	payroll_entry	12	INSERT		2026-06-27 00:05:56.189511-04	\N	{"id": 12, "run_id": 1, "net_pay": 1195.9, "medicare": 26.54, "gross_pay": 2080, "people_id": 129, "state_tax": 91.5, "federal_tax": 402.6, "regular_hours": 80, "overtime_hours": 0, "social_security": 113.46, "pre_tax_deductions": 250, "post_tax_deductions": 0}
24	payroll_run	2	INSERT		2026-06-27 00:05:56.206546-04	\N	{"id": 2, "status": "processed", "run_date": "2026-05-29", "created_by": "seed", "pay_frequency": "Bi-Weekly", "pay_period_end": "2026-05-29", "state_tax_rate": 0.05, "federal_tax_rate": 0.22, "pay_period_start": "2026-05-16"}
25	payroll_entry	13	INSERT		2026-06-27 00:05:56.206546-04	\N	{"id": 13, "run_id": 2, "net_pay": 2609.56, "medicare": 58.46, "gross_pay": 4615.38, "people_id": 101, "state_tax": 201.57, "federal_tax": 886.92, "regular_hours": 0, "overtime_hours": 0, "social_security": 249.95, "pre_tax_deductions": 583.92, "post_tax_deductions": 25}
26	payroll_entry	14	INSERT		2026-06-27 00:05:56.206546-04	\N	{"id": 14, "run_id": 2, "net_pay": 1821.83, "medicare": 40.76, "gross_pay": 3269.23, "people_id": 102, "state_tax": 140.54, "federal_tax": 618.37, "regular_hours": 0, "overtime_hours": 0, "social_security": 174.27, "pre_tax_deductions": 458.46, "post_tax_deductions": 15}
27	payroll_entry	15	INSERT		2026-06-27 00:05:56.206546-04	\N	{"id": 15, "run_id": 2, "net_pay": 882.23, "medicare": 19.57, "gross_pay": 1600, "people_id": 109, "state_tax": 67.5, "federal_tax": 297, "regular_hours": 80, "overtime_hours": 0, "social_security": 83.7, "pre_tax_deductions": 250, "post_tax_deductions": 0}
28	payroll_entry	16	INSERT		2026-06-27 00:05:56.206546-04	\N	{"id": 16, "run_id": 2, "net_pay": 1208.97, "medicare": 26.83, "gross_pay": 2100, "people_id": 110, "state_tax": 92.5, "federal_tax": 407, "regular_hours": 80, "overtime_hours": 5, "social_security": 114.7, "pre_tax_deductions": 250, "post_tax_deductions": 0}
29	payroll_entry	17	INSERT		2026-06-27 00:05:56.206546-04	\N	{"id": 17, "run_id": 2, "net_pay": 856.08, "medicare": 19, "gross_pay": 1560, "people_id": 111, "state_tax": 65.5, "federal_tax": 288.2, "regular_hours": 80, "overtime_hours": 0, "social_security": 81.22, "pre_tax_deductions": 250, "post_tax_deductions": 0}
30	payroll_entry	18	INSERT		2026-06-27 00:05:56.206546-04	\N	{"id": 18, "run_id": 2, "net_pay": 1229.29, "medicare": 27.28, "gross_pay": 2197, "people_id": 115, "state_tax": 94.05, "federal_tax": 413.84, "regular_hours": 80, "overtime_hours": 3, "social_security": 116.63, "pre_tax_deductions": 315.91, "post_tax_deductions": 0}
31	payroll_entry	19	INSERT		2026-06-27 00:05:56.206546-04	\N	{"id": 19, "run_id": 2, "net_pay": 1442.67, "medicare": 32.01, "gross_pay": 2560, "people_id": 116, "state_tax": 110.38, "federal_tax": 485.67, "regular_hours": 80, "overtime_hours": 0, "social_security": 136.87, "pre_tax_deductions": 352.4, "post_tax_deductions": 0}
32	payroll_entry	20	INSERT		2026-06-27 00:05:56.206546-04	\N	{"id": 20, "run_id": 2, "net_pay": 1375.62, "medicare": 30.52, "gross_pay": 2500, "people_id": 117, "state_tax": 105.25, "federal_tax": 463.1, "regular_hours": 0, "overtime_hours": 0, "social_security": 130.51, "pre_tax_deductions": 395, "post_tax_deductions": 0}
33	payroll_entry	21	INSERT		2026-06-27 00:05:56.206546-04	\N	{"id": 21, "run_id": 2, "net_pay": 1933.39, "medicare": 43.23, "gross_pay": 3461.54, "people_id": 121, "state_tax": 149.07, "federal_tax": 655.92, "regular_hours": 0, "overtime_hours": 0, "social_security": 184.85, "pre_tax_deductions": 480.08, "post_tax_deductions": 15}
34	payroll_entry	22	INSERT		2026-06-27 00:05:56.206546-04	\N	{"id": 22, "run_id": 2, "net_pay": 1091.35, "medicare": 24.21, "gross_pay": 1920, "people_id": 123, "state_tax": 83.5, "federal_tax": 367.4, "regular_hours": 80, "overtime_hours": 0, "social_security": 103.54, "pre_tax_deductions": 250, "post_tax_deductions": 0}
35	payroll_entry	23	INSERT		2026-06-27 00:05:56.206546-04	\N	{"id": 23, "run_id": 2, "net_pay": 1543.26, "medicare": 34.24, "gross_pay": 2692.31, "people_id": 125, "state_tax": 118.08, "federal_tax": 519.54, "regular_hours": 0, "overtime_hours": 0, "social_security": 146.42, "pre_tax_deductions": 330.77, "post_tax_deductions": 0}
36	payroll_entry	24	INSERT		2026-06-27 00:05:56.206546-04	\N	{"id": 24, "run_id": 2, "net_pay": 1195.9, "medicare": 26.54, "gross_pay": 2080, "people_id": 129, "state_tax": 91.5, "federal_tax": 402.6, "regular_hours": 80, "overtime_hours": 0, "social_security": 113.46, "pre_tax_deductions": 250, "post_tax_deductions": 0}
38	payroll_entry	25	INSERT		2026-06-27 00:05:56.212065-04	\N	{"id": 25, "run_id": 3, "net_pay": 2609.56, "medicare": 58.46, "gross_pay": 4615.38, "people_id": 101, "state_tax": 201.57, "federal_tax": 886.92, "regular_hours": 0, "overtime_hours": 0, "social_security": 249.95, "pre_tax_deductions": 583.92, "post_tax_deductions": 25}
39	payroll_entry	26	INSERT		2026-06-27 00:05:56.212065-04	\N	{"id": 26, "run_id": 3, "net_pay": 1821.83, "medicare": 40.76, "gross_pay": 3269.23, "people_id": 102, "state_tax": 140.54, "federal_tax": 618.37, "regular_hours": 0, "overtime_hours": 0, "social_security": 174.27, "pre_tax_deductions": 458.46, "post_tax_deductions": 15}
40	payroll_entry	27	INSERT		2026-06-27 00:05:56.212065-04	\N	{"id": 27, "run_id": 3, "net_pay": 882.23, "medicare": 19.57, "gross_pay": 1600, "people_id": 109, "state_tax": 67.5, "federal_tax": 297, "regular_hours": 80, "overtime_hours": 0, "social_security": 83.7, "pre_tax_deductions": 250, "post_tax_deductions": 0}
41	payroll_entry	28	INSERT		2026-06-27 00:05:56.212065-04	\N	{"id": 28, "run_id": 3, "net_pay": 1091.35, "medicare": 24.21, "gross_pay": 1920, "people_id": 110, "state_tax": 83.5, "federal_tax": 367.4, "regular_hours": 80, "overtime_hours": 0, "social_security": 103.54, "pre_tax_deductions": 250, "post_tax_deductions": 0}
42	payroll_entry	29	INSERT		2026-06-27 00:05:56.212065-04	\N	{"id": 29, "run_id": 3, "net_pay": 856.08, "medicare": 19, "gross_pay": 1560, "people_id": 111, "state_tax": 65.5, "federal_tax": 288.2, "regular_hours": 80, "overtime_hours": 0, "social_security": 81.22, "pre_tax_deductions": 250, "post_tax_deductions": 0}
43	payroll_entry	30	INSERT		2026-06-27 00:05:56.212065-04	\N	{"id": 30, "run_id": 3, "net_pay": 1155.13, "medicare": 25.63, "gross_pay": 2080, "people_id": 115, "state_tax": 88.38, "federal_tax": 388.87, "regular_hours": 80, "overtime_hours": 0, "social_security": 109.59, "pre_tax_deductions": 312.4, "post_tax_deductions": 0}
44	payroll_entry	31	INSERT		2026-06-27 00:05:56.212065-04	\N	{"id": 31, "run_id": 3, "net_pay": 1442.67, "medicare": 32.01, "gross_pay": 2560, "people_id": 116, "state_tax": 110.38, "federal_tax": 485.67, "regular_hours": 80, "overtime_hours": 0, "social_security": 136.87, "pre_tax_deductions": 352.4, "post_tax_deductions": 0}
45	payroll_entry	32	INSERT		2026-06-27 00:05:56.212065-04	\N	{"id": 32, "run_id": 3, "net_pay": 1375.62, "medicare": 30.52, "gross_pay": 2500, "people_id": 117, "state_tax": 105.25, "federal_tax": 463.1, "regular_hours": 0, "overtime_hours": 0, "social_security": 130.51, "pre_tax_deductions": 395, "post_tax_deductions": 0}
46	payroll_entry	33	INSERT		2026-06-27 00:05:56.212065-04	\N	{"id": 33, "run_id": 3, "net_pay": 1933.39, "medicare": 43.23, "gross_pay": 3461.54, "people_id": 121, "state_tax": 149.07, "federal_tax": 655.92, "regular_hours": 0, "overtime_hours": 0, "social_security": 184.85, "pre_tax_deductions": 480.08, "post_tax_deductions": 15}
47	payroll_entry	34	INSERT		2026-06-27 00:05:56.212065-04	\N	{"id": 34, "run_id": 3, "net_pay": 1185.45, "medicare": 26.3, "gross_pay": 2064, "people_id": 123, "state_tax": 90.7, "federal_tax": 399.08, "regular_hours": 80, "overtime_hours": 4, "social_security": 112.47, "pre_tax_deductions": 250, "post_tax_deductions": 0}
48	payroll_entry	35	INSERT		2026-06-27 00:05:56.212065-04	\N	{"id": 35, "run_id": 3, "net_pay": 1543.26, "medicare": 34.24, "gross_pay": 2692.31, "people_id": 125, "state_tax": 118.08, "federal_tax": 519.54, "regular_hours": 0, "overtime_hours": 0, "social_security": 146.42, "pre_tax_deductions": 330.77, "post_tax_deductions": 0}
49	payroll_entry	36	INSERT		2026-06-27 00:05:56.212065-04	\N	{"id": 36, "run_id": 3, "net_pay": 1195.9, "medicare": 26.54, "gross_pay": 2080, "people_id": 129, "state_tax": 91.5, "federal_tax": 402.6, "regular_hours": 80, "overtime_hours": 0, "social_security": 113.46, "pre_tax_deductions": 250, "post_tax_deductions": 0}
50	maint_work_order	11	INSERT		2026-07-05 00:26:08.3539-04	\N	{"id": 11, "notes": "Sample data", "title": "Replace worn bearings on CNC Mill #1", "status": "In Progress", "due_date": "2026-07-06", "priority": "High", "equipment": "CNC Mill #1", "work_type": "Replacement", "created_by": "SMPL-MAINT-", "assigned_to": "SMPL-MAINT-Bob Harmon", "completed_date": "", "requested_date": "2026-07-02"}
51	maint_work_order	12	INSERT		2026-07-05 00:26:08.3539-04	\N	{"id": 12, "notes": "Sample data", "title": "Quarterly PM — Hydraulic Press", "status": "Assigned", "due_date": "2026-06-28", "priority": "Medium", "equipment": "Hydraulic Press", "work_type": "Preventive", "created_by": "SMPL-MAINT-", "assigned_to": "SMPL-MAINT-Carlos Vega", "completed_date": "", "requested_date": "2026-06-28"}
52	maint_work_order	13	INSERT		2026-07-05 00:26:08.3539-04	\N	{"id": 13, "notes": "Sample data", "title": "Air compressor pressure relief check", "status": "Open", "due_date": "2026-07-06", "priority": "High", "equipment": "Air Compressor", "work_type": "Inspection", "created_by": "SMPL-MAINT-", "assigned_to": "SMPL-MAINT-Denise Fowler", "completed_date": "", "requested_date": "2026-07-04"}
53	maint_work_order	14	INSERT		2026-07-05 00:26:08.3539-04	\N	{"id": 14, "notes": "Sample data", "title": "Laser cutter alignment & calibration", "status": "In Progress", "due_date": "2026-07-04", "priority": "Critical", "equipment": "Laser Cutter", "work_type": "Calibration", "created_by": "SMPL-MAINT-", "assigned_to": "SMPL-MAINT-Bob Harmon", "completed_date": "", "requested_date": "2026-07-03"}
54	maint_work_order	15	INSERT		2026-07-05 00:26:08.3539-04	\N	{"id": 15, "notes": "Sample data", "title": "Industrial chiller coil cleaning", "status": "Assigned", "due_date": "2026-07-05", "priority": "Critical", "equipment": "Industrial Chiller", "work_type": "Cleaning", "created_by": "SMPL-MAINT-", "assigned_to": "SMPL-MAINT-Tim Okafor", "completed_date": "", "requested_date": "2026-07-04"}
55	maint_work_order	16	INSERT		2026-07-05 00:26:08.3539-04	\N	{"id": 16, "notes": "Sample data", "title": "Conveyor belt tension adjustment", "status": "Completed", "due_date": "2026-06-11", "priority": "Medium", "equipment": "Conveyor Belt #1", "work_type": "Repair", "created_by": "SMPL-MAINT-", "assigned_to": "SMPL-MAINT-Bob Harmon", "completed_date": "2026-06-12", "requested_date": "2026-06-21"}
56	maint_work_order	17	INSERT		2026-07-05 00:26:08.3539-04	\N	{"id": 17, "notes": "Sample data", "title": "Paint booth filter replacement", "status": "On Hold", "due_date": "2026-07-03", "priority": "Medium", "equipment": "Paint Booth", "work_type": "Replacement", "created_by": "SMPL-MAINT-", "assigned_to": "SMPL-MAINT-Ed Paulson", "completed_date": "", "requested_date": "2026-06-30"}
57	maint_work_order	18	INSERT		2026-07-05 00:26:08.3539-04	\N	{"id": 18, "notes": "Sample data", "title": "Annual overhead crane inspection", "status": "Completed", "due_date": "2026-05-09", "priority": "High", "equipment": "Overhead Crane", "work_type": "Inspection", "created_by": "SMPL-MAINT-", "assigned_to": "SMPL-MAINT-Lynn Marsh", "completed_date": "2026-05-10", "requested_date": "2026-06-05"}
58	maint_work_order	19	INSERT		2026-07-05 00:26:08.3539-04	\N	{"id": 19, "notes": "Sample data", "title": "MIG welder electrode tip replacement", "status": "Open", "due_date": "2026-07-08", "priority": "Low", "equipment": "MIG Welder", "work_type": "Replacement", "created_by": "SMPL-MAINT-", "assigned_to": "SMPL-MAINT-Carlos Vega", "completed_date": "", "requested_date": "2026-07-03"}
59	maint_work_order	20	INSERT		2026-07-05 00:26:08.3539-04	\N	{"id": 20, "notes": "Sample data", "title": "Injection molder hydraulic fluid flush", "status": "Completed", "due_date": "2026-06-20", "priority": "Medium", "equipment": "Injection Molder", "work_type": "Preventive", "created_by": "SMPL-MAINT-", "assigned_to": "SMPL-MAINT-Carlos Vega", "completed_date": "2026-06-21", "requested_date": "2026-06-25"}
60	workcenter	1	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 1, "dept": "Production", "name": "Cutting Station", "notes": null, "is_active": true, "created_by": null, "labor_rate": 22.5, "overhead_rate": 0, "capacity_hours_per_day": 8}
61	workcenter	1	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 1, "dept": "Production", "name": "Cutting Station", "notes": null, "is_active": true, "created_by": null, "labor_rate": 22.5, "overhead_rate": 0, "capacity_hours_per_day": 8}	{"id": 1, "dept": "Production", "name": "Cutting Station", "notes": null, "is_active": true, "created_by": "SMPL-OPS-", "labor_rate": 22.5, "overhead_rate": 8, "capacity_hours_per_day": 8}
62	workcenter	2	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 2, "dept": "Production", "name": "Paint Booth", "notes": null, "is_active": true, "created_by": null, "labor_rate": 19, "overhead_rate": 0, "capacity_hours_per_day": 6}
63	workcenter	2	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 2, "dept": "Production", "name": "Paint Booth", "notes": null, "is_active": true, "created_by": null, "labor_rate": 19, "overhead_rate": 0, "capacity_hours_per_day": 6}	{"id": 2, "dept": "Production", "name": "Paint Booth", "notes": null, "is_active": true, "created_by": "SMPL-OPS-", "labor_rate": 19, "overhead_rate": 12, "capacity_hours_per_day": 6}
64	workcenter	3	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 3, "dept": "Production", "name": "Wheel Building", "notes": null, "is_active": true, "created_by": null, "labor_rate": 24, "overhead_rate": 0, "capacity_hours_per_day": 8}
65	workcenter	3	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 3, "dept": "Production", "name": "Wheel Building", "notes": null, "is_active": true, "created_by": null, "labor_rate": 24, "overhead_rate": 0, "capacity_hours_per_day": 8}	{"id": 3, "dept": "Production", "name": "Wheel Building", "notes": null, "is_active": true, "created_by": "SMPL-OPS-", "labor_rate": 24, "overhead_rate": 6, "capacity_hours_per_day": 8}
66	workcenter	4	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 4, "dept": "Production", "name": "Final Assembly", "notes": null, "is_active": true, "created_by": null, "labor_rate": 21, "overhead_rate": 0, "capacity_hours_per_day": 8}
67	workcenter	4	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 4, "dept": "Production", "name": "Final Assembly", "notes": null, "is_active": true, "created_by": null, "labor_rate": 21, "overhead_rate": 0, "capacity_hours_per_day": 8}	{"id": 4, "dept": "Production", "name": "Final Assembly", "notes": null, "is_active": true, "created_by": "SMPL-OPS-", "labor_rate": 21, "overhead_rate": 9, "capacity_hours_per_day": 8}
68	workcenter	5	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 5, "dept": "Quality", "name": "Quality Inspection", "notes": null, "is_active": true, "created_by": null, "labor_rate": 26, "overhead_rate": 0, "capacity_hours_per_day": 8}
69	workcenter	5	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 5, "dept": "Quality", "name": "Quality Inspection", "notes": null, "is_active": true, "created_by": null, "labor_rate": 26, "overhead_rate": 0, "capacity_hours_per_day": 8}	{"id": 5, "dept": "Quality", "name": "Quality Inspection", "notes": null, "is_active": true, "created_by": "SMPL-OPS-", "labor_rate": 26, "overhead_rate": 5, "capacity_hours_per_day": 8}
70	routing	1	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 1, "notes": null, "std_hours": 0.5, "created_by": null, "product_id": 4, "operation_seq": 10, "workcenter_id": 1, "operation_name": "Cut Tube"}
71	routing	1	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 1, "notes": null, "std_hours": 0.5, "created_by": null, "product_id": 4, "operation_seq": 10, "workcenter_id": 1, "operation_name": "Cut Tube"}	{"id": 1, "notes": null, "std_hours": 0.5, "created_by": "SMPL-OPS-", "product_id": 4, "operation_seq": 10, "workcenter_id": 1, "operation_name": "Cut Tube"}
72	routing	2	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 2, "notes": null, "std_hours": 1, "created_by": null, "product_id": 4, "operation_seq": 20, "workcenter_id": 1, "operation_name": "Weld Frame"}
73	routing	2	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 2, "notes": null, "std_hours": 1, "created_by": null, "product_id": 4, "operation_seq": 20, "workcenter_id": 1, "operation_name": "Weld Frame"}	{"id": 2, "notes": null, "std_hours": 1, "created_by": "SMPL-OPS-", "product_id": 4, "operation_seq": 20, "workcenter_id": 1, "operation_name": "Weld Frame"}
74	routing	3	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 3, "notes": null, "std_hours": 0.75, "created_by": null, "product_id": 4, "operation_seq": 30, "workcenter_id": 2, "operation_name": "Paint Frame"}
75	routing	3	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 3, "notes": null, "std_hours": 0.75, "created_by": null, "product_id": 4, "operation_seq": 30, "workcenter_id": 2, "operation_name": "Paint Frame"}	{"id": 3, "notes": null, "std_hours": 0.75, "created_by": "SMPL-OPS-", "product_id": 4, "operation_seq": 30, "workcenter_id": 2, "operation_name": "Paint Frame"}
76	routing	4	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 4, "notes": null, "std_hours": 0.4, "created_by": null, "product_id": 5, "operation_seq": 10, "workcenter_id": 3, "operation_name": "Build Wheel"}
77	routing	4	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 4, "notes": null, "std_hours": 0.4, "created_by": null, "product_id": 5, "operation_seq": 10, "workcenter_id": 3, "operation_name": "Build Wheel"}	{"id": 4, "notes": null, "std_hours": 0.4, "created_by": "SMPL-OPS-", "product_id": 5, "operation_seq": 10, "workcenter_id": 3, "operation_name": "Build Wheel"}
78	routing	5	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 5, "notes": null, "std_hours": 0.2, "created_by": null, "product_id": 5, "operation_seq": 20, "workcenter_id": 5, "operation_name": "True & Inspect"}
79	routing	5	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 5, "notes": null, "std_hours": 0.2, "created_by": null, "product_id": 5, "operation_seq": 20, "workcenter_id": 5, "operation_name": "True & Inspect"}	{"id": 5, "notes": null, "std_hours": 0.2, "created_by": "SMPL-OPS-", "product_id": 5, "operation_seq": 20, "workcenter_id": 5, "operation_name": "True & Inspect"}
80	routing	6	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 6, "notes": null, "std_hours": 1.5, "created_by": null, "product_id": 2, "operation_seq": 10, "workcenter_id": 4, "operation_name": "Final Assembly"}
81	routing	6	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 6, "notes": null, "std_hours": 1.5, "created_by": null, "product_id": 2, "operation_seq": 10, "workcenter_id": 4, "operation_name": "Final Assembly"}	{"id": 6, "notes": null, "std_hours": 1.5, "created_by": "SMPL-OPS-", "product_id": 2, "operation_seq": 10, "workcenter_id": 4, "operation_name": "Final Assembly"}
82	routing	7	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 7, "notes": null, "std_hours": 0.3, "created_by": null, "product_id": 2, "operation_seq": 20, "workcenter_id": 5, "operation_name": "QA Inspection"}
83	routing	7	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 7, "notes": null, "std_hours": 0.3, "created_by": null, "product_id": 2, "operation_seq": 20, "workcenter_id": 5, "operation_name": "QA Inspection"}	{"id": 7, "notes": null, "std_hours": 0.3, "created_by": "SMPL-OPS-", "product_id": 2, "operation_seq": 20, "workcenter_id": 5, "operation_name": "QA Inspection"}
84	routing	8	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 8, "notes": null, "std_hours": 1.4, "created_by": null, "product_id": 3, "operation_seq": 10, "workcenter_id": 4, "operation_name": "Final Assembly"}
85	routing	8	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 8, "notes": null, "std_hours": 1.4, "created_by": null, "product_id": 3, "operation_seq": 10, "workcenter_id": 4, "operation_name": "Final Assembly"}	{"id": 8, "notes": null, "std_hours": 1.4, "created_by": "SMPL-OPS-", "product_id": 3, "operation_seq": 10, "workcenter_id": 4, "operation_name": "Final Assembly"}
86	routing	9	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 9, "notes": null, "std_hours": 0.3, "created_by": null, "product_id": 3, "operation_seq": 20, "workcenter_id": 5, "operation_name": "QA Inspection"}
87	routing	9	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 9, "notes": null, "std_hours": 0.3, "created_by": null, "product_id": 3, "operation_seq": 20, "workcenter_id": 5, "operation_name": "QA Inspection"}	{"id": 9, "notes": null, "std_hours": 0.3, "created_by": "SMPL-OPS-", "product_id": 3, "operation_seq": 20, "workcenter_id": 5, "operation_name": "QA Inspection"}
88	wo_operation	1	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 1, "notes": null, "wo_id": 1, "status": "pending", "scrap_qty": 0, "std_hours": 1.5, "rework_qty": 0, "routing_id": 6, "started_at": null, "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 10, "workcenter_id": 4, "operation_name": "Final Assembly"}
89	wo_operation	2	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 2, "notes": null, "wo_id": 1, "status": "pending", "scrap_qty": 0, "std_hours": 0.3, "rework_qty": 0, "routing_id": 7, "started_at": null, "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 20, "workcenter_id": 5, "operation_name": "QA Inspection"}
90	wo_operation	3	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 3, "notes": null, "wo_id": 2, "status": "pending", "scrap_qty": 0, "std_hours": 1.4, "rework_qty": 0, "routing_id": 8, "started_at": null, "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 10, "workcenter_id": 4, "operation_name": "Final Assembly"}
91	wo_operation	4	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 4, "notes": null, "wo_id": 2, "status": "pending", "scrap_qty": 0, "std_hours": 0.3, "rework_qty": 0, "routing_id": 9, "started_at": null, "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 20, "workcenter_id": 5, "operation_name": "QA Inspection"}
92	wo_operation	5	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 5, "notes": null, "wo_id": 3, "status": "pending", "scrap_qty": 0, "std_hours": 0.5, "rework_qty": 0, "routing_id": 1, "started_at": null, "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 10, "workcenter_id": 1, "operation_name": "Cut Tube"}
93	wo_operation	6	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 6, "notes": null, "wo_id": 3, "status": "pending", "scrap_qty": 0, "std_hours": 1, "rework_qty": 0, "routing_id": 2, "started_at": null, "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 20, "workcenter_id": 1, "operation_name": "Weld Frame"}
94	wo_operation	7	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 7, "notes": null, "wo_id": 3, "status": "pending", "scrap_qty": 0, "std_hours": 0.75, "rework_qty": 0, "routing_id": 3, "started_at": null, "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 30, "workcenter_id": 2, "operation_name": "Paint Frame"}
95	wo_operation	8	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 8, "notes": null, "wo_id": 4, "status": "pending", "scrap_qty": 0, "std_hours": 0.4, "rework_qty": 0, "routing_id": 4, "started_at": null, "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 10, "workcenter_id": 3, "operation_name": "Build Wheel"}
96	wo_operation	9	INSERT		2026-07-05 00:26:08.516029-04	\N	{"id": 9, "notes": null, "wo_id": 4, "status": "pending", "scrap_qty": 0, "std_hours": 0.2, "rework_qty": 0, "routing_id": 5, "started_at": null, "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 20, "workcenter_id": 5, "operation_name": "True & Inspect"}
97	wo_operation	5	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 5, "notes": null, "wo_id": 3, "status": "pending", "scrap_qty": 0, "std_hours": 0.5, "rework_qty": 0, "routing_id": 1, "started_at": null, "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 10, "workcenter_id": 1, "operation_name": "Cut Tube"}	{"id": 5, "notes": null, "wo_id": 3, "status": "completed", "scrap_qty": 0, "std_hours": 0.5, "rework_qty": 0, "routing_id": 1, "started_at": null, "actual_hours": 0.6, "completed_at": "2026-07-05T00:26:08.516029-04:00", "completed_by": "Sample Seed", "operation_seq": 10, "workcenter_id": 1, "operation_name": "Cut Tube"}
98	wo_operation	6	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 6, "notes": null, "wo_id": 3, "status": "pending", "scrap_qty": 0, "std_hours": 1, "rework_qty": 0, "routing_id": 2, "started_at": null, "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 20, "workcenter_id": 1, "operation_name": "Weld Frame"}	{"id": 6, "notes": null, "wo_id": 3, "status": "in_progress", "scrap_qty": 0, "std_hours": 1, "rework_qty": 0, "routing_id": 2, "started_at": "2026-07-05T00:26:08.516029-04:00", "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 20, "workcenter_id": 1, "operation_name": "Weld Frame"}
99	wo_operation	8	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 8, "notes": null, "wo_id": 4, "status": "pending", "scrap_qty": 0, "std_hours": 0.4, "rework_qty": 0, "routing_id": 4, "started_at": null, "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 10, "workcenter_id": 3, "operation_name": "Build Wheel"}	{"id": 8, "notes": null, "wo_id": 4, "status": "completed", "scrap_qty": 0, "std_hours": 0.4, "rework_qty": 0, "routing_id": 4, "started_at": null, "actual_hours": 4, "completed_at": "2026-07-05T00:26:08.516029-04:00", "completed_by": "Sample Seed", "operation_seq": 10, "workcenter_id": 3, "operation_name": "Build Wheel"}
100	wo_operation	9	UPDATE		2026-07-05 00:26:08.516029-04	{"id": 9, "notes": null, "wo_id": 4, "status": "pending", "scrap_qty": 0, "std_hours": 0.2, "rework_qty": 0, "routing_id": 5, "started_at": null, "actual_hours": null, "completed_at": null, "completed_by": null, "operation_seq": 20, "workcenter_id": 5, "operation_name": "True & Inspect"}	{"id": 9, "notes": null, "wo_id": 4, "status": "completed", "scrap_qty": 0, "std_hours": 0.2, "rework_qty": 0, "routing_id": 5, "started_at": null, "actual_hours": 2, "completed_at": "2026-07-05T00:26:08.516029-04:00", "completed_by": "Sample Seed", "operation_seq": 20, "workcenter_id": 5, "operation_name": "True & Inspect"}
101	lot	1	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 1, "qty": 400, "notes": "Incoming coil stock", "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-STEEL-01", "product_id": 8, "expiry_date": null, "received_date": "2026-06-05"}
102	lot	2	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 2, "qty": 30, "notes": "Awaiting incoming inspection", "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-RIM-01", "product_id": 10, "expiry_date": null, "received_date": "2026-06-30"}
103	lot	2	UPDATE		2026-07-05 00:26:08.53046-04	{"id": 2, "qty": 30, "notes": "Awaiting incoming inspection", "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-RIM-01", "product_id": 10, "expiry_date": null, "received_date": "2026-06-30"}	{"id": 2, "qty": 30, "notes": "Awaiting incoming inspection", "status": "quarantine", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-RIM-01", "product_id": 10, "expiry_date": null, "received_date": "2026-06-30"}
104	lot	3	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 3, "qty": 15, "notes": "Batch recalled by supplier pending QA review", "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-PAINT-01", "product_id": 9, "expiry_date": null, "received_date": "2026-06-25"}
105	lot	3	UPDATE		2026-07-05 00:26:08.53046-04	{"id": 3, "qty": 15, "notes": "Batch recalled by supplier pending QA review", "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-PAINT-01", "product_id": 9, "expiry_date": null, "received_date": "2026-06-25"}	{"id": 3, "qty": 15, "notes": "Batch recalled by supplier pending QA review", "status": "hold", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-PAINT-01", "product_id": 9, "expiry_date": null, "received_date": "2026-06-25"}
106	lot	4	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 4, "qty": 25, "notes": "Rubber compound approaching shelf-life limit", "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-TUBE-01", "product_id": 13, "expiry_date": "2026-07-30", "received_date": "2026-03-27"}
107	lot	5	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 5, "qty": 5, "notes": "Failed dimensional check, returned to supplier", "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-HBAR-01", "product_id": 6, "expiry_date": null, "received_date": "2026-06-20"}
108	lot	5	UPDATE		2026-07-05 00:26:08.53046-04	{"id": 5, "qty": 5, "notes": "Failed dimensional check, returned to supplier", "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-HBAR-01", "product_id": 6, "expiry_date": null, "received_date": "2026-06-20"}	{"id": 5, "qty": 5, "notes": "Failed dimensional check, returned to supplier", "status": "rejected", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-HBAR-01", "product_id": 6, "expiry_date": null, "received_date": "2026-06-20"}
109	lot	6	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 6, "qty": 20, "notes": "Fully consumed in production", "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-TIRE-01", "product_id": 12, "expiry_date": null, "received_date": "2026-05-06"}
110	lot	6	UPDATE		2026-07-05 00:26:08.53046-04	{"id": 6, "qty": 20, "notes": "Fully consumed in production", "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-TIRE-01", "product_id": 12, "expiry_date": null, "received_date": "2026-05-06"}	{"id": 6, "qty": 0, "notes": "Fully consumed in production", "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-TIRE-01", "product_id": 12, "expiry_date": null, "received_date": "2026-05-06"}
111	lot	6	UPDATE		2026-07-05 00:26:08.53046-04	{"id": 6, "qty": 0, "notes": "Fully consumed in production", "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-TIRE-01", "product_id": 12, "expiry_date": null, "received_date": "2026-05-06"}	{"id": 6, "qty": 0, "notes": "Fully consumed in production", "status": "consumed", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-TIRE-01", "product_id": 12, "expiry_date": null, "received_date": "2026-05-06"}
112	lot	7	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 7, "qty": 8, "notes": "Produced on SMPL-WO-4", "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "lot_number": "SMPL-OPS-WHEEL-01", "product_id": 5, "expiry_date": null, "received_date": "2026-07-02"}
113	serial_number	1	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 1, "notes": null, "lot_id": 7, "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "serial_number": "SMPL-OPS-SN-WA-0001"}
114	serial_number	1	UPDATE		2026-07-05 00:26:08.53046-04	{"id": 1, "notes": null, "lot_id": 7, "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "serial_number": "SMPL-OPS-SN-WA-0001"}	{"id": 1, "notes": null, "lot_id": 7, "status": "issued", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "serial_number": "SMPL-OPS-SN-WA-0001"}
115	serial_number	2	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 2, "notes": null, "lot_id": 7, "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "serial_number": "SMPL-OPS-SN-WA-0002"}
116	serial_number	2	UPDATE		2026-07-05 00:26:08.53046-04	{"id": 2, "notes": null, "lot_id": 7, "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "serial_number": "SMPL-OPS-SN-WA-0002"}	{"id": 2, "notes": null, "lot_id": 7, "status": "issued", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "serial_number": "SMPL-OPS-SN-WA-0002"}
117	serial_number	3	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 3, "notes": null, "lot_id": 7, "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "serial_number": "SMPL-OPS-SN-WA-0003"}
118	serial_number	4	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 4, "notes": null, "lot_id": 7, "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "serial_number": "SMPL-OPS-SN-WA-0004"}
119	serial_number	5	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 5, "notes": null, "lot_id": 7, "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "serial_number": "SMPL-OPS-SN-WA-0005"}
120	serial_number	6	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 6, "notes": null, "lot_id": 7, "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "serial_number": "SMPL-OPS-SN-WA-0006"}
121	serial_number	7	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 7, "notes": null, "lot_id": 7, "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "serial_number": "SMPL-OPS-SN-WA-0007"}
122	serial_number	8	INSERT		2026-07-05 00:26:08.53046-04	\N	{"id": 8, "notes": null, "lot_id": 7, "status": "available", "created_at": "2026-07-05T00:26:08.53046-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "serial_number": "SMPL-OPS-SN-WA-0008"}
123	gl_account_map	1	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 1, "category": "raw_material", "is_active": true, "description": "Inventory — raw material", "account_number": "1200"}
124	gl_account_map	2	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 2, "category": "wip", "is_active": true, "description": "Inventory — work in process", "account_number": "1200"}
125	gl_account_map	3	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 3, "category": "finished_goods", "is_active": true, "description": "Inventory — finished goods", "account_number": "1200"}
126	gl_account_map	4	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 4, "category": "cogs", "is_active": true, "description": "Direct Materials (COGS)", "account_number": "5000"}
127	gl_account_map	5	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 5, "category": "material_variance", "is_active": true, "description": "Material variance posts to Direct Materials", "account_number": "5000"}
128	gl_account_map	6	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 6, "category": "labor_variance", "is_active": true, "description": "Labor variance posts to Direct Labor", "account_number": "5100"}
129	gl_account_map	7	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 7, "category": "ap_payable", "is_active": true, "description": "Accounts Payable", "account_number": "2000"}
130	cost_roll	1	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 1, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 8, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 3.5, "std_material_cost": 3.5, "std_overhead_cost": 0}
131	cost_roll	2	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 2, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 9, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 12, "std_material_cost": 12, "std_overhead_cost": 0}
132	cost_roll	3	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 3, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 4, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 48, "total_std_cost": 96.2, "std_material_cost": 27.2, "std_overhead_cost": 21}
133	cost_roll	4	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 4, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 11, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 0.4, "std_material_cost": 0.4, "std_overhead_cost": 0}
134	cost_roll	5	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 5, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 10, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 18, "std_material_cost": 18, "std_overhead_cost": 0}
135	cost_roll	6	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 6, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 12, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 22, "std_material_cost": 22, "std_overhead_cost": 0}
136	cost_roll	7	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 7, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 13, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 6.5, "std_material_cost": 6.5, "std_overhead_cost": 0}
137	cost_roll	8	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 8, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 14.800001, "total_std_cost": 77.5, "std_material_cost": 59.3, "std_overhead_cost": 3.4}
138	cost_roll	9	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 9, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 6, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 14, "std_material_cost": 14, "std_overhead_cost": 0}
139	cost_roll	10	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 10, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 7, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 9.5, "std_material_cost": 9.5, "std_overhead_cost": 0}
140	cost_roll	11	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 11, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 2, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 39.3, "total_std_cost": 329, "std_material_cost": 274.7, "std_overhead_cost": 15}
141	cost_roll	12	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 12, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 8, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 3.5, "std_material_cost": 3.5, "std_overhead_cost": 0}
142	cost_roll	13	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 13, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 9, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 12, "std_material_cost": 12, "std_overhead_cost": 0}
143	cost_roll	14	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 14, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 4, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 48, "total_std_cost": 96.2, "std_material_cost": 27.2, "std_overhead_cost": 21}
144	cost_roll	15	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 15, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 11, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 0.4, "std_material_cost": 0.4, "std_overhead_cost": 0}
145	cost_roll	16	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 16, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 10, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 18, "std_material_cost": 18, "std_overhead_cost": 0}
146	cost_roll	17	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 17, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 12, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 22, "std_material_cost": 22, "std_overhead_cost": 0}
147	cost_roll	18	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 18, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 13, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 6.5, "std_material_cost": 6.5, "std_overhead_cost": 0}
148	cost_roll	19	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 19, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 5, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 14.800001, "total_std_cost": 77.5, "std_material_cost": 59.3, "std_overhead_cost": 3.4}
149	cost_roll	20	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 20, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 6, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 14, "std_material_cost": 14, "std_overhead_cost": 0}
150	cost_roll	21	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 21, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 7, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 0, "total_std_cost": 9.5, "std_material_cost": 9.5, "std_overhead_cost": 0}
151	cost_roll	22	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 22, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "product_id": 3, "roll_notes": null, "effective_date": "2026-07-05", "std_labor_cost": 37.2, "total_std_cost": 326, "std_material_cost": 274.7, "std_overhead_cost": 14.099999}
152	wo_cost_actual	1	INSERT		2026-07-05 00:26:08.537894-04	\N	{"id": 1, "wo_id": 4, "std_cost": 620, "created_at": "2026-07-05T00:26:08.537894-04:00", "created_by": "SMPL-OPS-", "labor_variance": 36.399994, "total_variance": 36.4, "actual_labor_cost": 148, "material_variance": 0, "total_actual_cost": 656.4, "actual_material_cost": 474.4, "actual_overhead_cost": 34}
153	approval_rule	1	INSERT		2026-07-05 00:26:08.550958-04	\N	{"id": 1, "seq": 10, "notes": "SMPL-OPS-", "dept_key": "", "is_active": true, "entity_type": "purchase_requisition", "approver_role": "Department Manager", "threshold_amount": 100, "escalate_after_hours": 24}
154	approval_rule	2	INSERT		2026-07-05 00:26:08.550958-04	\N	{"id": 2, "seq": 20, "notes": "SMPL-OPS-", "dept_key": "", "is_active": true, "entity_type": "purchase_requisition", "approver_role": "Purchasing Manager", "threshold_amount": 1000, "escalate_after_hours": 48}
155	approval_rule	3	INSERT		2026-07-05 00:26:08.550958-04	\N	{"id": 3, "seq": 10, "notes": "SMPL-OPS-", "dept_key": "", "is_active": true, "entity_type": "purchase_order", "approver_role": "Purchasing Manager", "threshold_amount": 1000, "escalate_after_hours": 24}
156	approval_rule	4	INSERT		2026-07-05 00:26:08.550958-04	\N	{"id": 4, "seq": 20, "notes": "SMPL-OPS-", "dept_key": "", "is_active": true, "entity_type": "purchase_order", "approver_role": "Vice President", "threshold_amount": 10000, "escalate_after_hours": 48}
157	approval_rule	5	INSERT		2026-07-05 00:26:08.550958-04	\N	{"id": 5, "seq": 10, "notes": "SMPL-OPS-", "dept_key": "", "is_active": true, "entity_type": "gl_journal", "approver_role": "Controller", "threshold_amount": 10000, "escalate_after_hours": 24}
158	payroll_run	4	INSERT		2026-07-05 00:26:08.641364-04	\N	{"id": 4, "status": "processed", "run_date": "2026-05-23", "created_by": "SMPL-PAY-", "pay_frequency": "Bi-Weekly", "pay_period_end": "2026-05-23", "state_tax_rate": 0.05, "federal_tax_rate": 0.22, "pay_period_start": "2026-05-10"}
159	payroll_entry	37	INSERT		2026-07-05 00:26:08.641364-04	\N	{"id": 37, "run_id": 4, "net_pay": 2609.56, "medicare": 58.46, "gross_pay": 4615.38, "people_id": 101, "state_tax": 201.57, "federal_tax": 886.92, "regular_hours": 0, "overtime_hours": 0, "social_security": 249.95, "pre_tax_deductions": 583.92, "post_tax_deductions": 25}
160	payroll_entry	38	INSERT		2026-07-05 00:26:08.641364-04	\N	{"id": 38, "run_id": 4, "net_pay": 1821.83, "medicare": 40.76, "gross_pay": 3269.23, "people_id": 102, "state_tax": 140.54, "federal_tax": 618.37, "regular_hours": 0, "overtime_hours": 0, "social_security": 174.27, "pre_tax_deductions": 458.46, "post_tax_deductions": 15}
161	payroll_entry	39	INSERT		2026-07-05 00:26:08.641364-04	\N	{"id": 39, "run_id": 4, "net_pay": 882.23, "medicare": 19.57, "gross_pay": 1600, "people_id": 109, "state_tax": 67.5, "federal_tax": 297, "regular_hours": 80, "overtime_hours": 0, "social_security": 83.7, "pre_tax_deductions": 250, "post_tax_deductions": 0}
162	payroll_entry	40	INSERT		2026-07-05 00:26:08.641364-04	\N	{"id": 40, "run_id": 4, "net_pay": 1091.35, "medicare": 24.21, "gross_pay": 1920, "people_id": 110, "state_tax": 83.5, "federal_tax": 367.4, "regular_hours": 80, "overtime_hours": 0, "social_security": 103.54, "pre_tax_deductions": 250, "post_tax_deductions": 0}
163	payroll_entry	41	INSERT		2026-07-05 00:26:08.641364-04	\N	{"id": 41, "run_id": 4, "net_pay": 856.08, "medicare": 19, "gross_pay": 1560, "people_id": 111, "state_tax": 65.5, "federal_tax": 288.2, "regular_hours": 80, "overtime_hours": 0, "social_security": 81.22, "pre_tax_deductions": 250, "post_tax_deductions": 0}
164	payroll_entry	42	INSERT		2026-07-05 00:26:08.641364-04	\N	{"id": 42, "run_id": 4, "net_pay": 1155.13, "medicare": 25.63, "gross_pay": 2080, "people_id": 115, "state_tax": 88.38, "federal_tax": 388.87, "regular_hours": 80, "overtime_hours": 0, "social_security": 109.59, "pre_tax_deductions": 312.4, "post_tax_deductions": 0}
165	payroll_entry	43	INSERT		2026-07-05 00:26:08.641364-04	\N	{"id": 43, "run_id": 4, "net_pay": 1442.67, "medicare": 32.01, "gross_pay": 2560, "people_id": 116, "state_tax": 110.38, "federal_tax": 485.67, "regular_hours": 80, "overtime_hours": 0, "social_security": 136.87, "pre_tax_deductions": 352.4, "post_tax_deductions": 0}
166	payroll_entry	44	INSERT		2026-07-05 00:26:08.641364-04	\N	{"id": 44, "run_id": 4, "net_pay": 1375.62, "medicare": 30.52, "gross_pay": 2500, "people_id": 117, "state_tax": 105.25, "federal_tax": 463.1, "regular_hours": 0, "overtime_hours": 0, "social_security": 130.51, "pre_tax_deductions": 395, "post_tax_deductions": 0}
167	payroll_entry	45	INSERT		2026-07-05 00:26:08.641364-04	\N	{"id": 45, "run_id": 4, "net_pay": 1933.39, "medicare": 43.23, "gross_pay": 3461.54, "people_id": 121, "state_tax": 149.07, "federal_tax": 655.92, "regular_hours": 0, "overtime_hours": 0, "social_security": 184.85, "pre_tax_deductions": 480.08, "post_tax_deductions": 15}
168	payroll_entry	46	INSERT		2026-07-05 00:26:08.641364-04	\N	{"id": 46, "run_id": 4, "net_pay": 1091.35, "medicare": 24.21, "gross_pay": 1920, "people_id": 123, "state_tax": 83.5, "federal_tax": 367.4, "regular_hours": 80, "overtime_hours": 0, "social_security": 103.54, "pre_tax_deductions": 250, "post_tax_deductions": 0}
169	payroll_entry	47	INSERT		2026-07-05 00:26:08.641364-04	\N	{"id": 47, "run_id": 4, "net_pay": 1543.26, "medicare": 34.24, "gross_pay": 2692.31, "people_id": 125, "state_tax": 118.08, "federal_tax": 519.54, "regular_hours": 0, "overtime_hours": 0, "social_security": 146.42, "pre_tax_deductions": 330.77, "post_tax_deductions": 0}
170	payroll_entry	48	INSERT		2026-07-05 00:26:08.641364-04	\N	{"id": 48, "run_id": 4, "net_pay": 1195.9, "medicare": 26.54, "gross_pay": 2080, "people_id": 129, "state_tax": 91.5, "federal_tax": 402.6, "regular_hours": 80, "overtime_hours": 0, "social_security": 113.46, "pre_tax_deductions": 250, "post_tax_deductions": 0}
171	payroll_run	5	INSERT		2026-07-05 00:26:08.656498-04	\N	{"id": 5, "status": "processed", "run_date": "2026-06-06", "created_by": "SMPL-PAY-", "pay_frequency": "Bi-Weekly", "pay_period_end": "2026-06-06", "state_tax_rate": 0.05, "federal_tax_rate": 0.22, "pay_period_start": "2026-05-24"}
172	payroll_entry	49	INSERT		2026-07-05 00:26:08.656498-04	\N	{"id": 49, "run_id": 5, "net_pay": 2609.56, "medicare": 58.46, "gross_pay": 4615.38, "people_id": 101, "state_tax": 201.57, "federal_tax": 886.92, "regular_hours": 0, "overtime_hours": 0, "social_security": 249.95, "pre_tax_deductions": 583.92, "post_tax_deductions": 25}
173	payroll_entry	50	INSERT		2026-07-05 00:26:08.656498-04	\N	{"id": 50, "run_id": 5, "net_pay": 1821.83, "medicare": 40.76, "gross_pay": 3269.23, "people_id": 102, "state_tax": 140.54, "federal_tax": 618.37, "regular_hours": 0, "overtime_hours": 0, "social_security": 174.27, "pre_tax_deductions": 458.46, "post_tax_deductions": 15}
174	payroll_entry	51	INSERT		2026-07-05 00:26:08.656498-04	\N	{"id": 51, "run_id": 5, "net_pay": 882.23, "medicare": 19.57, "gross_pay": 1600, "people_id": 109, "state_tax": 67.5, "federal_tax": 297, "regular_hours": 80, "overtime_hours": 0, "social_security": 83.7, "pre_tax_deductions": 250, "post_tax_deductions": 0}
175	payroll_entry	52	INSERT		2026-07-05 00:26:08.656498-04	\N	{"id": 52, "run_id": 5, "net_pay": 1208.97, "medicare": 26.83, "gross_pay": 2100, "people_id": 110, "state_tax": 92.5, "federal_tax": 407, "regular_hours": 80, "overtime_hours": 5, "social_security": 114.7, "pre_tax_deductions": 250, "post_tax_deductions": 0}
176	payroll_entry	53	INSERT		2026-07-05 00:26:08.656498-04	\N	{"id": 53, "run_id": 5, "net_pay": 856.08, "medicare": 19, "gross_pay": 1560, "people_id": 111, "state_tax": 65.5, "federal_tax": 288.2, "regular_hours": 80, "overtime_hours": 0, "social_security": 81.22, "pre_tax_deductions": 250, "post_tax_deductions": 0}
177	payroll_entry	54	INSERT		2026-07-05 00:26:08.656498-04	\N	{"id": 54, "run_id": 5, "net_pay": 1229.29, "medicare": 27.28, "gross_pay": 2197, "people_id": 115, "state_tax": 94.05, "federal_tax": 413.84, "regular_hours": 80, "overtime_hours": 3, "social_security": 116.63, "pre_tax_deductions": 315.91, "post_tax_deductions": 0}
178	payroll_entry	55	INSERT		2026-07-05 00:26:08.656498-04	\N	{"id": 55, "run_id": 5, "net_pay": 1442.67, "medicare": 32.01, "gross_pay": 2560, "people_id": 116, "state_tax": 110.38, "federal_tax": 485.67, "regular_hours": 80, "overtime_hours": 0, "social_security": 136.87, "pre_tax_deductions": 352.4, "post_tax_deductions": 0}
179	payroll_entry	56	INSERT		2026-07-05 00:26:08.656498-04	\N	{"id": 56, "run_id": 5, "net_pay": 1375.62, "medicare": 30.52, "gross_pay": 2500, "people_id": 117, "state_tax": 105.25, "federal_tax": 463.1, "regular_hours": 0, "overtime_hours": 0, "social_security": 130.51, "pre_tax_deductions": 395, "post_tax_deductions": 0}
180	payroll_entry	57	INSERT		2026-07-05 00:26:08.656498-04	\N	{"id": 57, "run_id": 5, "net_pay": 1933.39, "medicare": 43.23, "gross_pay": 3461.54, "people_id": 121, "state_tax": 149.07, "federal_tax": 655.92, "regular_hours": 0, "overtime_hours": 0, "social_security": 184.85, "pre_tax_deductions": 480.08, "post_tax_deductions": 15}
181	payroll_entry	58	INSERT		2026-07-05 00:26:08.656498-04	\N	{"id": 58, "run_id": 5, "net_pay": 1091.35, "medicare": 24.21, "gross_pay": 1920, "people_id": 123, "state_tax": 83.5, "federal_tax": 367.4, "regular_hours": 80, "overtime_hours": 0, "social_security": 103.54, "pre_tax_deductions": 250, "post_tax_deductions": 0}
182	payroll_entry	59	INSERT		2026-07-05 00:26:08.656498-04	\N	{"id": 59, "run_id": 5, "net_pay": 1543.26, "medicare": 34.24, "gross_pay": 2692.31, "people_id": 125, "state_tax": 118.08, "federal_tax": 519.54, "regular_hours": 0, "overtime_hours": 0, "social_security": 146.42, "pre_tax_deductions": 330.77, "post_tax_deductions": 0}
183	payroll_entry	60	INSERT		2026-07-05 00:26:08.656498-04	\N	{"id": 60, "run_id": 5, "net_pay": 1195.9, "medicare": 26.54, "gross_pay": 2080, "people_id": 129, "state_tax": 91.5, "federal_tax": 402.6, "regular_hours": 80, "overtime_hours": 0, "social_security": 113.46, "pre_tax_deductions": 250, "post_tax_deductions": 0}
184	payroll_run	6	INSERT		2026-07-05 00:26:08.66234-04	\N	{"id": 6, "status": "processed", "run_date": "2026-06-20", "created_by": "SMPL-PAY-", "pay_frequency": "Bi-Weekly", "pay_period_end": "2026-06-20", "state_tax_rate": 0.05, "federal_tax_rate": 0.22, "pay_period_start": "2026-06-07"}
185	payroll_entry	61	INSERT		2026-07-05 00:26:08.66234-04	\N	{"id": 61, "run_id": 6, "net_pay": 2609.56, "medicare": 58.46, "gross_pay": 4615.38, "people_id": 101, "state_tax": 201.57, "federal_tax": 886.92, "regular_hours": 0, "overtime_hours": 0, "social_security": 249.95, "pre_tax_deductions": 583.92, "post_tax_deductions": 25}
186	payroll_entry	62	INSERT		2026-07-05 00:26:08.66234-04	\N	{"id": 62, "run_id": 6, "net_pay": 1821.83, "medicare": 40.76, "gross_pay": 3269.23, "people_id": 102, "state_tax": 140.54, "federal_tax": 618.37, "regular_hours": 0, "overtime_hours": 0, "social_security": 174.27, "pre_tax_deductions": 458.46, "post_tax_deductions": 15}
187	payroll_entry	63	INSERT		2026-07-05 00:26:08.66234-04	\N	{"id": 63, "run_id": 6, "net_pay": 882.23, "medicare": 19.57, "gross_pay": 1600, "people_id": 109, "state_tax": 67.5, "federal_tax": 297, "regular_hours": 80, "overtime_hours": 0, "social_security": 83.7, "pre_tax_deductions": 250, "post_tax_deductions": 0}
188	payroll_entry	64	INSERT		2026-07-05 00:26:08.66234-04	\N	{"id": 64, "run_id": 6, "net_pay": 1091.35, "medicare": 24.21, "gross_pay": 1920, "people_id": 110, "state_tax": 83.5, "federal_tax": 367.4, "regular_hours": 80, "overtime_hours": 0, "social_security": 103.54, "pre_tax_deductions": 250, "post_tax_deductions": 0}
189	payroll_entry	65	INSERT		2026-07-05 00:26:08.66234-04	\N	{"id": 65, "run_id": 6, "net_pay": 856.08, "medicare": 19, "gross_pay": 1560, "people_id": 111, "state_tax": 65.5, "federal_tax": 288.2, "regular_hours": 80, "overtime_hours": 0, "social_security": 81.22, "pre_tax_deductions": 250, "post_tax_deductions": 0}
190	payroll_entry	66	INSERT		2026-07-05 00:26:08.66234-04	\N	{"id": 66, "run_id": 6, "net_pay": 1155.13, "medicare": 25.63, "gross_pay": 2080, "people_id": 115, "state_tax": 88.38, "federal_tax": 388.87, "regular_hours": 80, "overtime_hours": 0, "social_security": 109.59, "pre_tax_deductions": 312.4, "post_tax_deductions": 0}
191	payroll_entry	67	INSERT		2026-07-05 00:26:08.66234-04	\N	{"id": 67, "run_id": 6, "net_pay": 1442.67, "medicare": 32.01, "gross_pay": 2560, "people_id": 116, "state_tax": 110.38, "federal_tax": 485.67, "regular_hours": 80, "overtime_hours": 0, "social_security": 136.87, "pre_tax_deductions": 352.4, "post_tax_deductions": 0}
192	payroll_entry	68	INSERT		2026-07-05 00:26:08.66234-04	\N	{"id": 68, "run_id": 6, "net_pay": 1375.62, "medicare": 30.52, "gross_pay": 2500, "people_id": 117, "state_tax": 105.25, "federal_tax": 463.1, "regular_hours": 0, "overtime_hours": 0, "social_security": 130.51, "pre_tax_deductions": 395, "post_tax_deductions": 0}
193	payroll_entry	69	INSERT		2026-07-05 00:26:08.66234-04	\N	{"id": 69, "run_id": 6, "net_pay": 1933.39, "medicare": 43.23, "gross_pay": 3461.54, "people_id": 121, "state_tax": 149.07, "federal_tax": 655.92, "regular_hours": 0, "overtime_hours": 0, "social_security": 184.85, "pre_tax_deductions": 480.08, "post_tax_deductions": 15}
194	payroll_entry	70	INSERT		2026-07-05 00:26:08.66234-04	\N	{"id": 70, "run_id": 6, "net_pay": 1185.45, "medicare": 26.3, "gross_pay": 2064, "people_id": 123, "state_tax": 90.7, "federal_tax": 399.08, "regular_hours": 80, "overtime_hours": 4, "social_security": 112.47, "pre_tax_deductions": 250, "post_tax_deductions": 0}
195	payroll_entry	71	INSERT		2026-07-05 00:26:08.66234-04	\N	{"id": 71, "run_id": 6, "net_pay": 1543.26, "medicare": 34.24, "gross_pay": 2692.31, "people_id": 125, "state_tax": 118.08, "federal_tax": 519.54, "regular_hours": 0, "overtime_hours": 0, "social_security": 146.42, "pre_tax_deductions": 330.77, "post_tax_deductions": 0}
196	payroll_entry	72	INSERT		2026-07-05 00:26:08.66234-04	\N	{"id": 72, "run_id": 6, "net_pay": 1195.9, "medicare": 26.54, "gross_pay": 2080, "people_id": 129, "state_tax": 91.5, "federal_tax": 402.6, "regular_hours": 80, "overtime_hours": 0, "social_security": 113.46, "pre_tax_deductions": 250, "post_tax_deductions": 0}
197	purchase_requisition	1	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 1, "notes": null, "po_id": null, "status": "draft", "dept_id": null, "purpose": null, "created_by": "SMPL-PURCH-", "req_number": "SMPL-REQ-001", "dept_sub_id": null, "needed_date": "2026-07-19", "created_date": "2026-07-05", "requester_id": null, "justification": "New workstation components for expanding helpdesk team"}
198	requisition_item	1	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 1, "qty": 2, "req_id": 1, "product_id": null, "description": "16-port managed network switch", "est_unit_price": 450}
199	requisition_item	2	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 2, "qty": 5, "req_id": 1, "product_id": null, "description": "USB-C docking stations", "est_unit_price": 89.99}
200	purchase_requisition	2	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 2, "notes": null, "po_id": null, "status": "submitted", "dept_id": 6, "purpose": null, "created_by": "SMPL-PURCH-", "req_number": "SMPL-REQ-002", "dept_sub_id": 16, "needed_date": "2026-07-12", "created_date": "2026-07-02", "requester_id": 123, "justification": "Replacement bearings for main conveyor line"}
201	requisition_item	3	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 3, "qty": 20, "req_id": 2, "product_id": null, "description": "6205 deep-groove ball bearings (box of 10)", "est_unit_price": 4.75}
202	requisition_item	4	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 4, "qty": 4, "req_id": 2, "product_id": null, "description": "SAE 30 machine oil, 5-gallon drum", "est_unit_price": 28.5}
203	purchase_requisition	3	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 3, "notes": null, "po_id": null, "status": "dept_approved", "dept_id": 9, "purpose": null, "created_by": "SMPL-PURCH-", "req_number": "SMPL-REQ-003", "dept_sub_id": 29, "needed_date": "2026-07-15", "created_date": "2026-06-28", "requester_id": 109, "justification": "Raw material restock for Q3 production schedule"}
204	requisition_item	5	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 5, "qty": 200, "req_id": 3, "product_id": null, "description": "Steel tube 1-inch OD, 12-ft lengths", "est_unit_price": 3.5}
205	requisition_item	6	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 6, "qty": 50, "req_id": 3, "product_id": null, "description": "Paint cans — gloss blue, 1-quart", "est_unit_price": 12}
206	requisition_approval	1	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 1, "level": "dept", "req_id": 3, "comment": "Budget confirmed; forward to Purchasing for supplier selection.", "decision": "approved", "approver_id": 108, "decided_date": "2026-07-04"}
207	purchase_requisition	4	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 4, "notes": null, "po_id": null, "status": "dept_denied", "dept_id": 4, "purpose": null, "created_by": "SMPL-PURCH-", "req_number": "SMPL-REQ-004", "dept_sub_id": 14, "needed_date": "2026-07-26", "created_date": "2026-06-30", "requester_id": 121, "justification": "Prototype tooling for new lightweight frame design"}
208	requisition_item	7	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 7, "qty": 3, "req_id": 4, "product_id": null, "description": "CNC carbide cutting insert set (10-pack)", "est_unit_price": 185}
209	requisition_item	8	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 8, "qty": 1, "req_id": 4, "product_id": null, "description": "Precision calibration fixture", "est_unit_price": 620}
210	requisition_approval	2	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 2, "level": "dept", "req_id": 4, "comment": "Prototype budget exhausted for Q2; resubmit in Q4.", "decision": "denied", "approver_id": 134, "decided_date": "2026-07-04"}
211	purchase_requisition	5	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 5, "notes": null, "po_id": null, "status": "approved", "dept_id": 3, "purpose": null, "created_by": "SMPL-PURCH-", "req_number": "SMPL-REQ-005", "dept_sub_id": 8, "needed_date": "2026-07-10", "created_date": "2026-06-25", "requester_id": 119, "justification": "Ergonomic furniture for CS team expansion — 6 new hires"}
212	requisition_item	9	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 9, "qty": 6, "req_id": 5, "product_id": null, "description": "Ergonomic office chair, mesh back", "est_unit_price": 219.99}
213	requisition_item	10	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 10, "qty": 6, "req_id": 5, "product_id": null, "description": "Adjustable dual-monitor arm", "est_unit_price": 49.99}
214	requisition_approval	3	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 3, "level": "dept", "req_id": 5, "comment": "Headcount confirmed; furniture needed before new hires start.", "decision": "approved", "approver_id": 133, "decided_date": "2026-07-04"}
215	requisition_approval	4	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 4, "level": "purchasing", "req_id": 5, "comment": "Sourced from Global Office Solutions; PO to follow.", "decision": "approved", "approver_id": null, "decided_date": "2026-07-04"}
216	purchase_requisition	6	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 6, "notes": null, "po_id": null, "status": "denied", "dept_id": null, "purpose": null, "created_by": "SMPL-PURCH-", "req_number": "SMPL-REQ-006", "dept_sub_id": null, "needed_date": "2026-07-08", "created_date": "2026-06-27", "requester_id": null, "justification": "Printer toner emergency restock — all floors below minimum"}
217	requisition_item	11	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 11, "qty": 12, "req_id": 6, "product_id": null, "description": "HP LaserJet toner cartridge — black", "est_unit_price": 38.5}
218	requisition_item	12	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 12, "qty": 6, "req_id": 6, "product_id": null, "description": "HP LaserJet toner cartridge — color", "est_unit_price": 54}
219	requisition_approval	5	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 5, "level": "dept", "req_id": 6, "comment": "Routine consumable; approved to proceed.", "decision": "approved", "approver_id": 116, "decided_date": "2026-07-04"}
220	requisition_approval	6	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 6, "level": "purchasing", "req_id": 6, "comment": "Consolidate with Q2 office supply blanket order; resubmit next cycle.", "decision": "denied", "approver_id": null, "decided_date": "2026-07-04"}
221	purchase_requisition	7	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 7, "notes": null, "po_id": null, "status": "cancelled", "dept_id": 6, "purpose": null, "created_by": "SMPL-PURCH-", "req_number": "SMPL-REQ-007", "dept_sub_id": 16, "needed_date": "2026-08-04", "created_date": "2026-07-03", "requester_id": 123, "justification": "Annual safety equipment refresh per OSHA inspection findings"}
222	requisition_item	13	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 13, "qty": 10, "req_id": 7, "product_id": null, "description": "Safety harness, ANSI-rated full-body", "est_unit_price": 89}
223	requisition_item	14	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 14, "qty": 20, "req_id": 7, "product_id": null, "description": "Winter hard-hat liner, universal fit", "est_unit_price": 12.5}
224	requisition_item	15	INSERT		2026-07-05 00:26:09.003241-04	\N	{"id": 15, "qty": 15, "req_id": 7, "product_id": null, "description": "High-vis safety vest, XL", "est_unit_price": 8.75}
225	people	147	INSERT		2026-07-08 23:55:19.368038-04	\N	{"id": 147, "city": "", "email": "e2e-linux-check@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "LinuxCheck", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}
226	user_roles	48	INSERT		2026-07-08 23:55:19.604575-04	\N	{"id": 48, "role_id": 49, "people_id": 147}
227	user_roles	48	DELETE		2026-07-08 23:55:20.155722-04	{"id": 48, "role_id": 49, "people_id": 147}	\N
228	people	147	DELETE		2026-07-08 23:55:20.155722-04	{"id": 147, "city": "", "email": "e2e-linux-check@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "LinuxCheck", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}	\N
229	people	148	INSERT		2026-07-10 11:21:50.768617-04	\N	{"id": 148, "city": "", "email": "e2e-gap5-test@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "Gap5", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}
230	user_roles	49	INSERT		2026-07-10 11:21:51.005233-04	\N	{"id": 49, "role_id": 49, "people_id": 148}
231	user_roles	49	DELETE		2026-07-10 11:22:13.083657-04	{"id": 49, "role_id": 49, "people_id": 148}	\N
232	people	148	DELETE		2026-07-10 11:22:13.083657-04	{"id": 148, "city": "", "email": "e2e-gap5-test@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "Gap5", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}	\N
233	people	149	INSERT		2026-07-10 11:28:32.189594-04	\N	{"id": 149, "city": "", "email": "e2e-gap6-test@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "Gap6", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}
234	user_roles	50	INSERT		2026-07-10 11:28:32.424018-04	\N	{"id": 50, "role_id": 49, "people_id": 149}
235	user_roles	50	DELETE		2026-07-10 11:28:50.637587-04	{"id": 50, "role_id": 49, "people_id": 149}	\N
236	people	149	DELETE		2026-07-10 11:28:50.637587-04	{"id": 149, "city": "", "email": "e2e-gap6-test@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "Gap6", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}	\N
237	people	150	INSERT		2026-07-10 11:52:10.350397-04	\N	{"id": 150, "city": "", "email": "e2e-gap7-test@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "Gap7", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}
238	user_roles	51	INSERT		2026-07-10 11:52:10.585113-04	\N	{"id": 51, "role_id": 49, "people_id": 150}
239	user_roles	51	DELETE		2026-07-10 11:52:48.443337-04	{"id": 51, "role_id": 49, "people_id": 150}	\N
240	people	150	DELETE		2026-07-10 11:52:48.443337-04	{"id": 150, "city": "", "email": "e2e-gap7-test@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "Gap7", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}	\N
241	people	151	INSERT		2026-07-10 12:08:20.271231-04	\N	{"id": 151, "city": "", "email": "e2e-ats-test@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "ATS", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}
242	user_roles	52	INSERT		2026-07-10 12:08:20.506477-04	\N	{"id": 52, "role_id": 49, "people_id": 151}
243	user_roles	52	DELETE		2026-07-10 12:08:38.614941-04	{"id": 52, "role_id": 49, "people_id": 151}	\N
244	people	151	DELETE		2026-07-10 12:08:38.614941-04	{"id": 151, "city": "", "email": "e2e-ats-test@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "ATS", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}	\N
245	purchase_order	6	INSERT		2026-07-10 12:22:53.024735-04	\N	{"id": 6, "notes": null, "status": "sent", "po_number": "PO-2026-0001", "created_by": null, "order_date": "2026-07-01", "supplier_id": 11, "expected_date": null, "received_date": null, "supplier_ack_notes": "", "supplier_acknowledged_at": null}
246	po_item	10	INSERT		2026-07-10 12:22:53.024735-04	\N	{"id": 10, "po_id": 6, "created_by": "", "product_id": null, "unit_price": 5, "description": "Test Part", "qty_ordered": 10, "qty_received": 0}
247	po_item	10	DELETE		2026-07-10 12:29:42.667398-04	{"id": 10, "po_id": 6, "created_by": "", "product_id": null, "unit_price": 5, "description": "Test Part", "qty_ordered": 10, "qty_received": 0}	\N
248	purchase_order	6	DELETE		2026-07-10 12:29:42.667398-04	{"id": 6, "notes": null, "status": "sent", "po_number": "PO-2026-0001", "created_by": null, "order_date": "2026-07-01", "supplier_id": 11, "expected_date": null, "received_date": null, "supplier_ack_notes": "", "supplier_acknowledged_at": null}	\N
249	people	152	INSERT		2026-07-10 12:54:43.466959-04	\N	{"id": 152, "city": "", "email": "e2e-p10-live@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "P10Live", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}
250	user_roles	53	INSERT		2026-07-10 12:54:43.701022-04	\N	{"id": 53, "role_id": 49, "people_id": 152}
251	user_roles	53	DELETE		2026-07-10 12:55:07.981395-04	{"id": 53, "role_id": 49, "people_id": 152}	\N
252	people	152	DELETE		2026-07-10 12:55:07.981395-04	{"id": 152, "city": "", "email": "e2e-p10-live@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "P10Live", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}	\N
253	people	153	INSERT		2026-07-10 13:17:23.908961-04	\N	{"id": 153, "city": "", "email": "e2e-p11-live@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "P11Live", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}
254	user_roles	54	INSERT		2026-07-10 13:17:24.141427-04	\N	{"id": 54, "role_id": 49, "people_id": 153}
255	user_roles	54	DELETE		2026-07-10 13:17:47.045526-04	{"id": 54, "role_id": 49, "people_id": 153}	\N
256	people	153	DELETE		2026-07-10 13:17:47.045526-04	{"id": 153, "city": "", "email": "e2e-p11-live@example.com", "state": "", "emp_id": null, "address": "", "dept_id": null, "zip_code": "", "last_name": "P11Live", "created_by": null, "first_name": "E2E", "dept_sub_id": null, "employee_id": 0}	\N
\.


--
-- Data for Name: audit_schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_schedule (id, audit_name, audit_type, department, auditor, scheduled, completed, status, notes, created_by) FROM stdin;
1	Annual Financial Audit	Financial	Accounting	External Auditor	2026-05-27		Scheduled		\N
2	SMPL-FIN-Q1 Financial Review	Financial	Finance	External CPA	2026-03-28	2026-04-07	Completed	Sample data	\N
3	SMPL-FIN-IT Systems Compliance Audit	IT	IT	Sarah Moore CPA	2026-05-12	2026-05-17	Completed	Sample data	\N
4	SMPL-FIN-Payroll Tax Compliance Q1	Tax	Finance	External CPA	2026-04-27	2026-05-02	Completed	Sample data	\N
5	SMPL-FIN-Internal Controls Review Q2	Internal	All Depts	Sarah Moore CPA	2026-06-11	\N	In Progress	Sample data	\N
6	SMPL-FIN-Mid-Year Operational Audit	Operational	Production	External CPA	2026-07-11	\N	Scheduled	Sample data	\N
7	SMPL-FIN-Year-End Financial Audit	Financial	Finance	External CPA	2026-12-23	\N	Scheduled	Sample data	\N
8	SMPL-FIN-Tax Preparation Review H2	Tax	Finance	Sarah Moore CPA	2026-10-24	\N	Scheduled	Sample data	\N
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	3	add_permission
6	Can change permission	3	change_permission
7	Can delete permission	3	delete_permission
8	Can view permission	3	view_permission
9	Can add group	2	add_group
10	Can change group	2	change_group
11	Can delete group	2	delete_group
12	Can view group	2	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: bank_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank_account (id, account_name, bank_name, account_number, routing_number, gl_account_id, is_active, notes) FROM stdin;
1	SMPL-FIN-Main Checking	First National Bank	****4821	021000089	\N	1	Sample data
2	SMPL-FIN-Payroll Checking	First National Bank	****3310	021000089	\N	1	Sample data
3	SMPL-FIN-Operating Savings	Midwest Credit Union	****7750	281078056	\N	1	Sample data
4	SMPL-FIN-Reserve Account	Midwest Credit Union	****9012	281078056	\N	1	Sample data
\.


--
-- Data for Name: bank_reconciliation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank_reconciliation (id, statement_id, journal_line_id, statement_item_id, matched_at, matched_by) FROM stdin;
\.


--
-- Data for Name: bank_statement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank_statement (id, bank_account_id, statement_date, beginning_balance, ending_balance, status, reconciled_by, reconciled_at, notes, created_at) FROM stdin;
1	1	2026-04-27	284500	312180	Reconciled	David Kim			2026-06-26 23:36:07.818671-04
2	1	2026-05-27	312180	298450	Reconciled	David Kim			2026-06-26 23:36:07.818671-04
3	1	2026-06-26	298450	271300	In Progress				2026-06-26 23:36:07.818671-04
4	2	2026-05-27	12000	11800	Reconciled	David Kim			2026-06-26 23:36:07.818671-04
5	3	2026-05-27	520000	522100	Reconciled	David Kim			2026-06-26 23:36:07.818671-04
6	1	2026-05-06	284500	312180	Reconciled	David Kim			2026-07-05 00:26:08.123901-04
7	1	2026-06-05	312180	298450	Reconciled	David Kim			2026-07-05 00:26:08.123901-04
8	1	2026-07-05	298450	271300	In Progress				2026-07-05 00:26:08.123901-04
9	2	2026-06-05	12000	11800	Reconciled	David Kim			2026-07-05 00:26:08.123901-04
10	3	2026-06-05	520000	522100	Reconciled	David Kim			2026-07-05 00:26:08.123901-04
\.


--
-- Data for Name: bank_statement_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank_statement_item (id, statement_id, item_date, description, amount, item_type, is_matched, matched_journal_line_id) FROM stdin;
\.


--
-- Data for Name: bank_transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bank_transaction (id, bank_account_id, statement_id, trans_date, amount, description, ref_number, cleared, matched_gl_line_id, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: bom; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bom (id, product_id, component_id, qty_required, unit, notes, scrap_pct) FROM stdin;
1	2	4	1	ea	sample	0
2	2	5	2	ea	sample	0
3	2	6	1	ea	sample	0
4	2	7	1	ea	sample	0
5	3	4	1	ea	sample	0
6	3	5	2	ea	sample	0
7	3	6	1	ea	sample	0
8	3	7	1	ea	sample	0
9	4	8	4	m	sample	0
10	4	9	1	can	sample	10
11	5	10	1	ea	sample	0
12	5	11	32	ea	sample	0
13	5	12	1	ea	sample	0
14	5	13	1	ea	sample	0
\.


--
-- Data for Name: budget; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget (id, budget_name, fiscal_year, dept_id, status, notes, created_by) FROM stdin;
1	SMPL-FIN-Operating Budget 2026	2026	\N	active	Full-year approved operating budget	seed
2	SMPL-FIN-Capital Expenditure Budget 2026	2026	\N	active	Approved CapEx — equipment & facilities	seed
3	SMPL-FIN-Marketing Budget 2026	2026	\N	active	Marketing department budget	seed
4	SMPL-FIN-Operating Budget 2025	2025	\N	closed	Prior year operating budget — closed	seed
5	SMPL-FIN-Draft Budget 2027	2027	\N	draft	Preliminary next-year planning budget	seed
\.


--
-- Data for Name: budget_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.budget_line (id, budget_id, account_id, category, description, budgeted_amount, notes, gl_account_id) FROM stdin;
1	1	\N	Personnel	Salaries & Benefits — All Departments	1.85e+06	Sample data	\N
2	1	\N	Facilities	Rent, Utilities, Maintenance	420000	Sample data	\N
3	1	\N	Materials	Raw Materials & Supplies	680000	Sample data	\N
4	1	\N	IT	Software Licenses, Hardware, Support	95000	Sample data	\N
5	1	\N	Legal	Legal Fees & Compliance	55000	Sample data	\N
6	1	\N	Insurance	Property, Liability, Workers Comp	72000	Sample data	\N
7	1	\N	Travel	Business Travel & Entertainment	38000	Sample data	\N
8	1	\N	Training	Employee Development & Training	24000	Sample data	\N
9	2	\N	Equipment	CNC Mill Replacement	185000	Sample data	\N
10	2	\N	Equipment	Laser Cutter Upgrade	220000	Sample data	\N
11	2	\N	Facilities	Warehouse HVAC Replacement	48000	Sample data	\N
12	2	\N	IT	Server Refresh — Data Center	65000	Sample data	\N
13	2	\N	Vehicles	Forklift Replacement	42000	Sample data	\N
14	3	\N	Advertising	Digital Advertising — Search & Social	58000	Sample data	\N
15	3	\N	Events	Trade Shows & Industry Events	65000	Sample data	\N
16	3	\N	Content	Content Creation & Design	22000	Sample data	\N
17	3	\N	PR	Public Relations Agency	18000	Sample data	\N
18	3	\N	Research	Market Research Studies	12000	Sample data	\N
\.


--
-- Data for Name: calls2; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.calls2 (id, customer_id, call, call_date, call_time, completion_date, completion_time, comments_box, completion_box, created_by) FROM stdin;
1	1	have not received product yet	2025-09-01	11:25				0	
2	\N	Customer unable to track order — shipment delayed 5 days	2026-06-08	09:15	2026-06-09	10:30	Contacted shipping; updated customer with new ETA.	1	seed
3	\N	Wrong item shipped — received shaft collar instead of valve assembly	2026-06-12	14:00	2026-06-13	15:45	Issued return label; replacement shipped same day.	1	seed
4	\N	Invoice shows incorrect unit price from quote	2026-06-16	11:30	2026-06-17	13:00	Finance team corrected invoice; resent to customer.	1	seed
5	\N	Product arrived damaged — packaging crushed in transit	2026-06-19	08:45	2026-06-20	09:20	Filed freight claim; replacement ordered.	1	seed
6	\N	Customer requesting technical specs for valve assembly batch	2026-06-21	16:00				0	seed
7	\N	Complaint: sales rep not returning calls	2026-06-23	10:00			Escalated to Sales Manager for follow-up.	0	seed
8	\N	Requesting early delivery for emergency production run	2026-06-25	14:30			Coordinating with Production to expedite order.	0	seed
9	\N	Customer wants to modify existing blanket order quantities	2026-06-11	13:00	2026-06-12	14:00	Updated order per customer request; confirmed pricing.	1	seed
10	\N	Defective bearing — premature failure after 30 days	2026-06-06	09:00	2026-06-07	10:30	Sent warranty replacement; engineering notified.	1	seed
11	\N	Billing dispute — charged twice for same order	2026-05-27	10:30	2026-05-28	11:00	Accounting confirmed duplicate; credit memo issued.	1	seed
12	\N	Customer cannot find product documentation on portal	2026-06-24	15:00				0	seed
13	\N	Request for custom part modification — non-standard thread	2026-06-18	11:00	2026-06-19	12:15	Forwarded to Engineering for feasibility review.	1	seed
14	\N	Customer unable to track order — shipment delayed 5 days	2026-06-17	09:15	2026-06-18	10:30	Contacted shipping; updated customer with new ETA.	1	SMPL-CS-
15	\N	Wrong item shipped — received shaft collar instead of valve assembly	2026-06-21	14:00	2026-06-22	15:45	Issued return label; replacement shipped same day.	1	SMPL-CS-
16	\N	Invoice shows incorrect unit price from quote	2026-06-25	11:30	2026-06-26	13:00	Finance team corrected invoice; resent to customer.	1	SMPL-CS-
17	\N	Product arrived damaged — packaging crushed in transit	2026-06-28	08:45	2026-06-29	09:20	Filed freight claim; replacement ordered.	1	SMPL-CS-
18	\N	Customer requesting technical specs for valve assembly batch	2026-06-30	16:00				0	SMPL-CS-
19	\N	Complaint: sales rep not returning calls	2026-07-02	10:00			Escalated to Sales Manager for follow-up.	0	SMPL-CS-
20	\N	Requesting early delivery for emergency production run	2026-07-04	14:30			Coordinating with Production to expedite order.	0	SMPL-CS-
21	\N	Customer wants to modify existing blanket order quantities	2026-06-20	13:00	2026-06-21	14:00	Updated order per customer request; confirmed pricing.	1	SMPL-CS-
22	\N	Defective bearing — premature failure after 30 days	2026-06-15	09:00	2026-06-16	10:30	Sent warranty replacement; engineering notified.	1	SMPL-CS-
23	\N	Billing dispute — charged twice for same order	2026-06-05	10:30	2026-06-06	11:00	Accounting confirmed duplicate; credit memo issued.	1	SMPL-CS-
24	\N	Customer cannot find product documentation on portal	2026-07-03	15:00				0	SMPL-CS-
25	\N	Request for custom part modification — non-standard thread	2026-06-27	11:00	2026-06-28	12:15	Forwarded to Engineering for feasibility review.	1	SMPL-CS-
\.


--
-- Data for Name: closed_periods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.closed_periods (id, period_year, period_month, closed_at, closed_by, notes) FROM stdin;
\.


--
-- Data for Name: collection_activity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.collection_activity (id, customer_id, activity_date, activity_type, contact_name, notes, amount_promised, promise_date, follow_up_date, status, created_by) FROM stdin;
1	6	2026-06-10	Call	Tom Briggs	Spoke with AP contact re $4,200 overdue balance; payment promised by end of week	4200	2026-06-17	2026-06-17	Open	SMPL-CUST-
2	6	2026-06-20	Email	Tom Briggs	Sent follow-up email; no payment received — escalating to formal demand	\N	\N	2026-06-27	Open	SMPL-CUST-
3	8	2026-05-16	Call	Frank Russo	Reached owner; promised payment within 7 days — balance $6,800	6800	2026-05-23	2026-05-23	Open	SMPL-CUST-
4	8	2026-05-31	Letter	Frank Russo	Formal collection letter sent; no payment received	\N	\N	2026-06-14	Open	SMPL-CUST-
5	8	2026-06-25	Call	Frank Russo	No response to letter or prior calls; file transferred to collections agency	\N	\N	2026-07-02	Escalated	SMPL-CUST-
\.


--
-- Data for Name: compliance_checklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compliance_checklist (id, template_id, name, owner, status, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: compliance_checklist_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compliance_checklist_item (id, checklist_id, template_item_id, clause_ref, requirement_text, category, sort_order, status, evidence_notes, completed_by, completed_at) FROM stdin;
\.


--
-- Data for Name: compliance_template; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compliance_template (id, name, standard, description, created_by, created_at) FROM stdin;
1	ISO 9001:2015 Quality Management System (starter)	ISO 9001:2015	Illustrative starter checklist — a small representative subset of clauses, not the full standard. Consult the actual standard text and a qualified auditor for real certification work.	system	2026-07-10 11:52:40.127323-04
2	FDA 21 CFR Part 820 Quality System Regulation (starter)	FDA 21 CFR Part 820	Illustrative starter checklist — a small representative subset of clauses, not the full standard. Consult the actual standard text and a qualified auditor for real certification work.	system	2026-07-10 11:52:40.127323-04
\.


--
-- Data for Name: compliance_template_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.compliance_template_item (id, template_id, clause_ref, requirement_text, category, sort_order) FROM stdin;
1	1	4.4	Processes needed for the QMS are identified and their sequence/interaction determined	Context	0
2	1	5.1	Top management demonstrates leadership and commitment to the QMS	Leadership	1
3	1	6.1	Risks and opportunities affecting QMS conformity are identified and addressed	Planning	2
4	1	7.1.5	Monitoring and measuring resources are calibrated/verified at specified intervals	Support	3
5	1	8.5.1	Production is carried out under controlled conditions	Operation	4
6	1	9.2	Internal audits are conducted at planned intervals	Performance Evaluation	5
7	1	10.2	Nonconformities are corrected and root-caused, with corrective action taken	Improvement	6
8	2	820.30	Design controls are established for device design and development	Design Controls	0
9	2	820.50	Purchasing controls verify that suppliers meet specified requirements	Purchasing	1
10	2	820.70	Production and process controls document and control the manufacturing process	Production	2
11	2	820.80	Receiving, in-process, and finished device acceptance activities are documented	Inspection	3
12	2	820.100	A corrective and preventive action (CAPA) procedure is documented and followed	CAPA	4
13	2	820.184	Device history records (DHR) are maintained for each unit/lot/batch	Records	5
\.


--
-- Data for Name: corrective_action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.corrective_action (id, finding_id, description, assigned_to, due_date, completed, status, notes, created_by) FROM stdin;
\.


--
-- Data for Name: cost_center; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cost_center (id, code, name, dept_key, is_active) FROM stdin;
\.


--
-- Data for Name: cost_roll; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cost_roll (id, product_id, effective_date, std_material_cost, std_labor_cost, std_overhead_cost, total_std_cost, roll_notes, created_by, created_at) FROM stdin;
1	8	2026-07-05	3.5	0	0	3.5	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
2	9	2026-07-05	12	0	0	12	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
3	4	2026-07-05	27.2	48	21	96.2	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
4	11	2026-07-05	0.4	0	0	0.4	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
5	10	2026-07-05	18	0	0	18	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
6	12	2026-07-05	22	0	0	22	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
7	13	2026-07-05	6.5	0	0	6.5	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
8	5	2026-07-05	59.3	14.800001	3.4	77.5	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
9	6	2026-07-05	14	0	0	14	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
10	7	2026-07-05	9.5	0	0	9.5	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
11	2	2026-07-05	274.7	39.3	15	329	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
12	8	2026-07-05	3.5	0	0	3.5	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
13	9	2026-07-05	12	0	0	12	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
14	4	2026-07-05	27.2	48	21	96.2	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
15	11	2026-07-05	0.4	0	0	0.4	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
16	10	2026-07-05	18	0	0	18	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
17	12	2026-07-05	22	0	0	22	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
18	13	2026-07-05	6.5	0	0	6.5	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
19	5	2026-07-05	59.3	14.800001	3.4	77.5	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
20	6	2026-07-05	14	0	0	14	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
21	7	2026-07-05	9.5	0	0	9.5	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
22	3	2026-07-05	274.7	37.2	14.099999	326	\N	SMPL-OPS-	2026-07-05 00:26:08.537894-04
\.


--
-- Data for Name: credit_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credit_account (id, customer_id, credit_limit, status, terms, opened_date, notes) FROM stdin;
1	2	25000	good	Net 30	2024-07-05	\N
2	3	15000	good	Net 45	2025-01-11	\N
3	4	50000	good	Net 30	2023-07-06	\N
4	5	10000	good	Net 45	2025-07-05	\N
5	6	20000	hold	Net 30	2024-07-05	Limit reduced; placed on hold pending balance resolution
6	7	30000	good	Net 60	2025-01-03	\N
7	8	8000	suspended	COD	2023-07-06	Suspended after chronic late payments
8	9	35000	good	Net 30	2024-07-05	\N
9	10	12000	good	Net 45	2025-11-07	\N
10	11	5000	good	Net 30	2026-01-06	\N
\.


--
-- Data for Name: credit_application; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credit_application (id, customer_id, applied_date, requested_limit, approved_limit, status, reviewed_by, review_date, notes, created_by) FROM stdin;
1	2	2024-08-04	25000	25000	approved	Finance Dept	2024-08-09	Initial credit line approved — strong trade references	SMPL-CUST-
2	3	2025-01-31	15000	15000	approved	Finance Dept	2025-02-05	Approved based on two-year trade references	SMPL-CUST-
3	4	2023-07-21	50000	50000	approved	Finance Dept	2023-07-26	High-volume account; limit approved with quarterly review	SMPL-CUST-
4	9	2024-07-25	35000	35000	approved	Finance Dept	2024-07-30	Approved after site visit and D&B report review	SMPL-CUST-
5	8	2025-05-31	15000	\N	denied	Finance Dept	2025-06-05	Denied — poor payment history with prior vendors	SMPL-CUST-
6	6	2025-02-20	30000	\N	denied	Finance Dept	2025-02-25	Denied at requested amount; approved at $20,000 via separate review	SMPL-CUST-
7	7	2026-06-25	40000	\N	pending	\N	\N	Requesting increase from $30,000 to $40,000	SMPL-CUST-
8	11	2026-06-30	10000	\N	pending	\N	\N	Initial credit application for new account	SMPL-CUST-
\.


--
-- Data for Name: credit_limit_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credit_limit_history (id, customer_id, changed_date, old_limit, new_limit, old_status, new_status, changed_by, reason) FROM stdin;
1	9	2025-07-05	20000	35000	good	good	SMPL-CUST-	Limit increased — two-year perfect payment record
2	6	2026-04-21	30000	20000	good	hold	SMPL-CUST-	Overdue balance exceeded original limit — limit reduced and placed on hold
3	8	2026-03-07	15000	8000	good	good	SMPL-CUST-	Limit reduced due to chronic late payments
4	8	2026-05-21	8000	8000	good	suspended	SMPL-CUST-	Account suspended — balance outstanding > 90 days
\.


--
-- Data for Name: cs_improvement_plan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cs_improvement_plan (id, title, description, owner, target_date, status, created_date, created_by) FROM stdin;
1	SMPL-CS-Reduce Average Resolution Time	Target: reduce avg ticket resolution from 4.2 days to 2.5 days by end of Q3.	Rachel Green	2026-08-25	In Progress	2026-06-26	seed
2	SMPL-CS-Implement Self-Service Knowledge Base	Launch customer-facing KB portal to reduce repeat inquiries by 30%.	Rachel Green	2026-09-24	Open	2026-06-26	seed
3	SMPL-CS-Escalation Response SLA Update	Revise escalation SLA from 48hrs to 24hrs for critical-priority tickets.	Rachel Green	2026-07-26	Open	2026-06-26	seed
4	SMPL-CS-CS Staff Cross-Training Program	Cross-train all CS reps on Tier-2 technical troubleshooting to reduce referrals.	Rachel Green	2026-10-24	Open	2026-06-26	seed
5	SMPL-CS-Post-Call Survey Rollout	Deploy automated CSAT survey after every resolved ticket.	Rachel Green	2026-06-11	Completed	2026-06-26	seed
\.


--
-- Data for Name: cs_kb_article; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cs_kb_article (id, title, category, content, author, published_date, status, tags, view_count, created_by, created_date) FROM stdin;
1	SMPL-CS-How to Track Your Order Status	Shipping		Rachel Green	2026-05-27	Published	order,tracking,shipping	142	seed	2026-06-26
2	SMPL-CS-Initiating a Return or Exchange	Returns		Rachel Green	2026-06-01	Published	return,refund,exchange	98	seed	2026-06-26
3	SMPL-CS-Reading Your Invoice — Common Questions	Billing		Rachel Green	2026-06-06	Published	invoice,billing,payment	73	seed	2026-06-26
4	SMPL-CS-Valve Assembly Technical Specifications	Product		Rachel Green	2026-06-11	Published	valve,specs,technical,datasheet	210	seed	2026-06-26
5	SMPL-CS-Warranty Policy Overview	Policy		Rachel Green	2026-06-16	Published	warranty,defective,replacement	88	seed	2026-06-26
6	SMPL-CS-How to Set Up Your Customer Portal Account	Account		Rachel Green	2026-06-21	Published	portal,account,login	156	seed	2026-06-26
7	SMPL-CS-Frequently Asked Questions — Shipping Times	FAQ		Rachel Green	2026-06-23	Published	FAQ,shipping,lead time	44	seed	2026-06-26
8	SMPL-CS-Bearing Installation Best Practices	Technical		Rachel Green	\N	In Review	bearing,installation,technical	0	seed	2026-06-26
9	SMPL-CS-Custom Part Request Process	Product		Rachel Green	\N	Draft	custom,special,engineering	0	seed	2026-06-26
\.


--
-- Data for Name: cs_return; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cs_return (id, customer_id, return_date, reason, items_returned, refund_amount, status, notes, created_by, created_date) FROM stdin;
1	\N	2026-06-06	Wrong Item	3x Shaft Collar A-200 (returned)	186	Refunded	Sample data	seed	2026-06-26
2	\N	2026-06-11	Defective	1x Bearing 6205 lot — premature failure	52.5	Approved	Sample data	seed	2026-06-26
3	\N	2026-06-16	Damaged in Shipping	5x Valve Assembly V-100	1245	Approved	Sample data	seed	2026-06-26
4	\N	2026-06-21	Not as Described	10x M10 Bolt Pack (wrong grade)	85	Pending	Sample data	seed	2026-06-26
5	\N	2026-05-27	Changed Mind	2x Hydraulic Hose kit	160	Refunded	Sample data	seed	2026-06-26
6	\N	2026-05-12	Defective	1x Custom Fixture CF-204 — dimensional	880	Closed	Sample data	seed	2026-06-26
7	\N	2026-06-24	Duplicate Order	Full order — customer placed twice	3200	Pending	Sample data	seed	2026-06-26
8	\N	2026-06-15	Wrong Item	3x Shaft Collar A-200 (returned)	186	Refunded	Sample data	SMPL-CS-	2026-07-05
9	\N	2026-06-20	Defective	1x Bearing 6205 lot — premature failure	52.5	Approved	Sample data	SMPL-CS-	2026-07-05
10	\N	2026-06-25	Damaged in Shipping	5x Valve Assembly V-100	1245	Approved	Sample data	SMPL-CS-	2026-07-05
11	\N	2026-06-30	Not as Described	10x M10 Bolt Pack (wrong grade)	85	Pending	Sample data	SMPL-CS-	2026-07-05
12	\N	2026-06-05	Changed Mind	2x Hydraulic Hose kit	160	Refunded	Sample data	SMPL-CS-	2026-07-05
13	\N	2026-05-21	Defective	1x Custom Fixture CF-204 — dimensional	880	Closed	Sample data	SMPL-CS-	2026-07-05
14	\N	2026-07-03	Duplicate Order	Full order — customer placed twice	3200	Pending	Sample data	SMPL-CS-	2026-07-05
\.


--
-- Data for Name: cs_survey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cs_survey (id, title, description, survey_type, status, start_date, end_date, response_count, avg_score, created_by, created_date) FROM stdin;
3	SMPL-CS-Post-Purchase Survey — June	Automated survey after order completion	Post-Purchase	Active	2026-06-06	2026-06-16	0	\N	seed	2026-06-26
4	SMPL-CS-Product Quality Feedback	Targeted survey for valve assembly buyers	Product	Draft	2026-06-21	2026-07-21	0	\N	seed	2026-06-26
1	SMPL-CS-Q1 Customer Satisfaction Survey	Post-purchase CSAT — Q1 closed orders	CSAT	Closed	2026-03-28	2026-01-27	6	8.2	seed	2026-06-26
2	SMPL-CS-Q2 Net Promoter Score	NPS survey sent to all active accounts	NPS	Closed	2026-05-12	2026-04-27	8	8	seed	2026-06-26
\.


--
-- Data for Name: cs_survey_response; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cs_survey_response (id, survey_id, customer_id, score, comments, response_date) FROM stdin;
1	1	\N	8	Fast shipping, product was exactly as described.	2026-04-02
2	1	\N	9	Excellent quality and on-time delivery.	2026-04-05
3	1	\N	6	Packaging could be better — minor damage.	2026-04-07
4	1	\N	10	Best supplier we've worked with.	2026-04-09
5	1	\N	7	Good product but had to follow up on the order.	2026-04-12
6	1	\N	9	Smooth transaction, will order again.	2026-04-15
7	2	\N	9	Would definitely recommend.	2026-05-17
8	2	\N	8	Good quality, competitive pricing.	2026-05-19
9	2	\N	10	Outstanding service and product quality.	2026-05-22
10	2	\N	5	Delivery was two days late.	2026-05-24
11	2	\N	7	Product quality is solid.	2026-05-27
12	2	\N	9	Very responsive to our needs.	2026-05-29
13	2	\N	10	Top-tier supplier.	2026-06-01
14	2	\N	6	Pricing is a bit high versus competitors.	2026-06-06
\.


--
-- Data for Name: cs_training; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cs_training (id, people_id, topic, trainer, train_date, notes, completed) FROM stdin;
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customer (id, first_name, last_name, company_name, phone_number, address, city, state, zip_code, email, created_by) FROM stdin;
1	John	Smith	Ajax services	3334445566	123 Anywhere Way	Anywhere	WV	26777	John@smith.net	\N
2	Bob	Harrison	Apex Metalworks Inc.	555-210-1000	100 Industrial Blvd	Cleveland	OH	44101	b.harrison@apexmetalworks.example.com	SMPL-CUST-
3	Alice	Nguyen	Summit Fabricators LLC	555-210-1001	450 Commerce Dr	Columbus	OH	43201	a.nguyen@summitfab.example.com	SMPL-CUST-
4	James	Chen	Pacific Rim Parts Co.	555-210-1002	800 Pacific Ave	Cincinnati	OH	45201	j.chen@pacificrimparts.example.com	SMPL-CUST-
5	Sandra	Koch	Allied Components Corp.	555-210-1003	220 Allied Way	Toledo	OH	43601	s.koch@alliedcomponents.example.com	SMPL-CUST-
6	Tom	Briggs	Delta Precision Parts LLC	555-210-1004	55 Delta Park	Akron	OH	44301	t.briggs@deltaprecision.example.com	SMPL-CUST-
7	Mary	Sullivan	Crestview Industries LLC	555-210-1005	300 Crest Rd	Dayton	OH	45401	m.sullivan@crestviewind.example.com	SMPL-CUST-
8	Frank	Russo	Ironworks Supply Co.	555-210-1006	110 Steel Mill Rd	Youngstown	OH	44501	f.russo@ironworkssupply.example.com	SMPL-CUST-
9	Karen	Drake	Lakeside Manufacturing Inc.	555-210-1007	900 Lakeview Blvd	Cleveland	OH	44102	k.drake@lakesidemfg.example.com	SMPL-CUST-
10	Paul	Whitfield	Blue Ridge Tooling Inc.	555-210-1008	75 Ridge Rd	Canton	OH	44701	p.whitfield@blueridgetooling.example.com	SMPL-CUST-
11	Diana	Park	Momentum Plastics LLC	555-210-1009	610 Polymer Dr	Lorain	OH	44052	d.park@momentumplastics.example.com	SMPL-CUST-
\.


--
-- Data for Name: dept; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dept (dept_id, dept_name) FROM stdin;
1	Accounting
2	Company
3	Customer Service
4	Engineering
5	Information Technologies
6	Maintenance
7	Marketing
8	Personnel
9	Production
10	Purchasing
11	Quality Assurance
12	Sales
13	Labs
14	Finance
15	Legal
16	Risk Management
17	Warehouse
\.


--
-- Data for Name: dept_sub; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dept_sub (dept_sub_id, dept_sub_name, dept_id) FROM stdin;
6	IT Technition	\N
21	Quality Assurance Technition	\N
23	Lab Technition	\N
1	Accounts payable	1
2	Accounts receivable	1
3	Accounts payable Supervisor	1
4	Accounts receivable Supervisor	1
5	Accounting Manager	1
7	IT Manager	5
8	Customer Service Rep	3
9	Customer Service Lead	3
10	Customer Service Manager	3
11	Personnel Manager	8
12	Personnel Assistant	8
13	Engineer Manager	4
14	Engineer	4
15	Maintenance Manager	6
16	Maintenance Mechanic	6
17	Purchasing Manager	10
18	Purchasing Personnel	10
19	Quality Assurance Manager	11
20	Quality Assurance Lead	11
22	Lab Manager	13
24	Company President	2
25	Company Vice President	2
26	Marketing Manager	7
27	Marketing Personnel	7
28	Production Manager	9
29	Production Foreman	9
30	Production Personnel	9
31	Sales Manager	12
32	Sales Personnel	12
33	Finance Manager	14
34	Finance Personnel	14
35	Legal Manager	15
36	Legal Personnel	15
37	Risk Manager	16
38	Risk Personnel	16
39	Warehouse Manager	17
40	Warehouse Personnel	17
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	group
3	auth	permission
4	auth	user
5	contenttypes	contenttype
6	sessions	session
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2026-05-27 10:22:15.241358-04
2	auth	0001_initial	2026-05-27 10:22:15.274981-04
3	admin	0001_initial	2026-05-27 10:22:15.286058-04
4	admin	0002_logentry_remove_auto_add	2026-05-27 10:22:15.289896-04
5	admin	0003_logentry_add_action_flag_choices	2026-05-27 10:22:15.293811-04
6	contenttypes	0002_remove_content_type_name	2026-05-27 10:22:15.303522-04
7	auth	0002_alter_permission_name_max_length	2026-05-27 10:22:15.308073-04
8	auth	0003_alter_user_email_max_length	2026-05-27 10:22:15.312407-04
9	auth	0004_alter_user_username_opts	2026-05-27 10:22:15.316647-04
10	auth	0005_alter_user_last_login_null	2026-05-27 10:22:15.324967-04
11	auth	0006_require_contenttypes_0002	2026-05-27 10:22:15.32574-04
12	auth	0007_alter_validators_add_error_messages	2026-05-27 10:22:15.330831-04
13	auth	0008_alter_user_username_max_length	2026-05-27 10:22:15.338203-04
14	auth	0009_alter_user_last_name_max_length	2026-05-27 10:22:15.343128-04
15	auth	0010_alter_group_name_max_length	2026-05-27 10:22:15.34873-04
16	auth	0011_update_proxy_permissions	2026-05-27 10:22:15.352576-04
17	auth	0012_alter_user_first_name_max_length	2026-05-27 10:22:15.357508-04
18	sessions	0001_initial	2026-05-27 10:22:15.364012-04
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
zlx5ulqjtr5n7pfjuxunxelp1eh67fxq	.eJxVyjEKwzAQRNG7TG1ygK2Sk4hFHgeRXclorcKY3D2YxEXa9_-BEeyJrsUg0NlLvefmq9b9lptj-g69GSF4nP2ymeuWXtwh-KOqfr6XLcMsac6MgGx98OclkmvVJztkUQu-P84EMkQ:1wSLzm:wcw5etHZtONFySgsiUlfSYBcpT2b9DKK6I10DVR6R50	2026-06-10 17:40:58.408524-04
ajd75tfbew2i4xlk6oeoc3x1bw9sdabq	.eJxVyjEKwzAQRNG7TG1ygK2Sk4hFHgeRXclorcKY3D2YxEXa9_-BEeyJrsUg0NlLvefmq9b9lptj-g69GSF4nP2ymeuWXtwh-KOqfr6XLcMsac6MgGx98OclkmvVJztkUQu-P84EMkQ:1wSM0N:RALC7lJo-sLdgsVprAWFfyNlD77sJDIRLvaewzD9OQQ	2026-06-10 17:41:35.606919-04
2vvep6i0lj7qq4g5bq6u34iejysyniu7	.eJxVyjEKwzAQRNG7TG1ygK2Sk4hFHgeRXclorcKY3D2YxEXa9_-BEeyJrsUg0NlLvefmq9b9lptj-g69GSF4nP2ymeuWXtwh-KOqfr6XLcMsac6MgGx98OclkmvVJztkUQu-P84EMkQ:1wSM1D:54camhOMoHSWIcboJVNWphULSeB981BXuS77bMFwS6w	2026-06-10 17:42:27.459982-04
60fzofuz4a2nxyjfs6iddt18yqo5ru7k	.eJxVyrEKQjEMBdBfkcziB3TS0d29hL7bZzBJpWkHEf9dRN_gejhPmoGeYSxKidClHGNA3NgPpRntv6E3BSU6LSa-2YL7yDc8KNEfOdvnnr22bjyk-e6CcvWmbRXEdutUzVwKIiiNPvFziWzsvKJTqqyB1xsbUDvQ:1wSMAY:-q5Q98uOdMKnZuExlXIsVpmKthZzNeBmQzVPj0Sre2k	2026-06-10 17:52:06.589431-04
n9kntdbfy80v72s3xrzhucwezh5tuxtu	.eJxVi0EKQjEMBa8iWYsH6ErwCB6gxPi-FJNWklYR8e4i1sVfvpl5LxoBzzAuSol6qbw_eXtU7KQZbX_am4IS_ecZt56veFIiGdGbwXPA70WwSirb93aYzea4bpahmlkEEZQW1sAUJbJx5Qt88vcHwCI85A:1wSMAa:96sVHTJVhAkNydtmldgNE8qQqK2_GCo7l0HbGCYZGX8	2026-06-10 17:52:08.945883-04
9ooyn13xmga6bfn9sblbmrh7m1wtxcju	.eJxlyzEOAjEMRNG7TI04QCoazhF5s5PIwnFQzBYIcXeEWApEOf9pHtiCM7OLGhKWsZyq0tZjGR2HD85hRMJ3rrze8oV3JNCbOjnV24-69Pfj_M91M8tSCiOQqlhwB43cxaVx7v35ArfdN9M:1wSMAd:vTTeZRZ4ftjZiqEDGFmKmOOh9G1A_SstTjiH7tdqmnc	2026-06-10 17:52:11.246083-04
ztghliyztyahq6p4gdntnf540yktwm5e	.eJxdijsOwyAMhu_iucoBmCLlIMgiPw2pDRGGAVW9exWlWTp-jzd1Q_VQTkKO9rLl2TS1bQpF6XHVWgTk6MYVR_MvjH-VWc9tKXpwHneKXcRzCDAj12rHzyfzypmfqOQii-HzBZBSMgY:1wSMAf:KAzfEmmrp9adsUS8WbJxE1tcrO7klmgo7TjjxrS7OhI	2026-06-10 17:52:13.481698-04
veryuubhtg34fwifrlheleihqu7uzjn7	.eJxVy7EOwjAMhOFXQZ4RD5AJRnb2yHKvrUXsoDgdEOLdK0QrxPrfdy9aAi3DWAslQlM5R4e6sZ-kGh2_oNUCSnQZTH1vAx493_GkROpjbcZdq-cOmf-Is32-15853CCz11InRex2XErJLIIISiOXwDZoZGPnCW3r7xWWd0LE:1wSMDj:eKPEaNW0ACiNa3vvFNwbrETrgz_dkTV2n-XisG3iGIY	2026-06-10 17:55:23.795338-04
ahkayzm4rnqfi0bgxopxuje00bq6q32w	.eJxVy7EOwjAMhOFXQZ4RD5AJRnb2yHKvrUXsoDgdEOLdK0QrxPrfdy9aAi3DWAslQlM5R4e6sZ-kGh2_oNUCSnQZTH1vAx493_GkROpjbcZdq-cOmf-Is32-15853CCz11InRex2XErJLIIISiOXwDZoZGPnCW3r7xWWd0LE:1wSMEg:OgbXYy0IUNgtGjygFD31vlD-w_1kQFD68y7rlcdxV5E	2026-06-10 17:56:22.999445-04
gzp64v4rjazvf1xhg9t4wztim2tp5d9w	.eJxVyzEOAjEMRNGrINeIA6SCkp4-sryTXYvYQXG2QIi7IwQrRDv_zYPWQM8w1kqJ0FWOMaBu7AdpRvsP6K2CEp0mU9-2CbeRr7hTIvXSuvHQ5nlAlj_ibO_v-Wd2F8jirbZZEZsta62ZRRBBqXANfINGNnae0SmNvuL5AlRUQnk:1wSMGp:LyP-XJSAGz-nP-awF5nP2ow48PWS4vpB2ecbCnqWwDk	2026-06-10 17:58:35.816087-04
z8io26r4qlihs76jkmg1njnsscmzqvjd	.eJxVyzEOAjEMRNGrINeIA6SCkp4-sryTXYvYQXG2QIi7IwQrRDv_zYPWQM8w1kqJ0FWOMaBu7AdpRvsP6K2CEp0mU9-2CbeRr7hTIvXSuvHQ5nlAlj_ibO_v-Wd2F8jirbZZEZsta62ZRRBBqXANfINGNnae0SmNvuL5AlRUQnk:1wSMHZ:lmNixw2M3JY3WDhTiWyFOdtQcWXWokgUcHvs68OzBhg	2026-06-10 17:59:21.170214-04
c20kzxegl940bkfjxnx544hrfwxfrafx	.eJxdijsOwyAMhu_iucoBmCLlIMgiPw2pDRGGAVW9exWlWTp-jzd1Q_VQTkKO9rLl2TS1bQpF6XHVWgTk6MYVR_MvjH-VWc9tKXpwHneKXcRzCDAj12rHzyfzypmfqOQii-HzBZBSMgY:1wSMJq:R3YLH2Y4grrUhR3tvr9TFMo3B_8KtCjZNTDOuVoFLLs	2026-06-10 18:01:42.209646-04
okpt56zb8algjys9bsjlp19dknf6lkaz	.eJxdijsOwyAMhu_iucoBmCLlIMgiPw2pDRGGAVW9exWlWTp-jzd1Q_VQTkKO9rLl2TS1bQpF6XHVWgTk6MYVR_MvjH-VWc9tKXpwHneKXcRzCDAj12rHzyfzypmfqOQii-HzBZBSMgY:1wSMLi:IJiwmKBE2Nlv3-kkpTPD5rBNLVVnZkmBqa3wa8bZZEc	2026-06-10 18:03:38.310577-04
0txvvy2sk1wyz8zcb8icxwp7p9fyy7yq	.eJxdijsOwyAMhu_iucoBmCLlIMgiPw2pDRGGAVW9exWlWTp-jzd1Q_VQTkKO9rLl2TS1bQpF6XHVWgTk6MYVR_MvjH-VWc9tKXpwHneKXcRzCDAj12rHzyfzypmfqOQii-HzBZBSMgY:1wSMMp:hp6Oap4ywGTBOKi1HjK4Zd3YnhSTcdij0idzCypLEUM	2026-06-10 18:04:47.816152-04
hzdro45qe5n18zd2dmppm8k6a576kdac	.eJxdijsOwyAMhu_iucoBmCLlIMgiPw2pDRGGAVW9exWlWTp-jzd1Q_VQTkKO9rLl2TS1bQpF6XHVWgTk6MYVR_MvjH-VWc9tKXpwHneKXcRzCDAj12rHzyfzypmfqOQii-HzBZBSMgY:1wSMNs:4tLNK4rJnn8D8HttL-8EkEUofqkhV7R7yyve9328seU	2026-06-10 18:05:52.114045-04
40ip2iwol0x7s0mjj4nwh1y9pdzbmlbp	.eJxVzEEKwjAQheG7zLr0AF0VvIA3CEP6lOhMEmYSsIh3N1C7cPv9j_em7rAA5SS00IMVPke2BlvxYq2CORal6dhZEYzZ1eBpQ26nb6gtPLGP9kd5_A27FK2c9zPdukjgGOFOS7OOnycPypnvsIM_X6LfOUA:1wh9Sj:uRqH-dzHrAXSUlICtItCxgkLpBdEMn2S8AmlOz_RBRc	2026-07-21 13:20:01.613524-04
qa944ccw6l6b4m9av7ftm3ivmjpkfl7g	.eJxVykEKwkAMRuG7ZG1duOzKI3iDIaS_OjSZlmQGKuLdLVSh3X7vvakFPME4K_WECzrNpS2dPCHjFQvbrDjLZHTaVp8U63lzRB5Q6t8HzDWNeK3tQIUNO7s31cQiiKC-esPPcyTjwg_4xp8viz03Lg:1whfr5:fVmGHbJLV2ndSAjvkrrHosXeL0UjamwyqdqT_eFyeKA	2026-07-22 23:55:19.85426-04
1od7y0j08yhjodkuqx5flzz3yaqh0eig	.eJxVykEKwkAMRuG7ZG1dCG668gjeYAjT3zKYTIckA4p49xaqoNvvvRd1hyUoF6GRcMIwczsPAY8LHqxNcMyL0mEfbRFs39XgZUKNr09oke54bu2PKit-7NZFEucMdxrDOj5ePClXnmE7v1f3gjYt:1wiD3A:Hs84Pyq7fMRlHNlRKr7cTaTxl-fnsmxuzM3AUW4KAR8	2026-07-24 11:22:00.620393-04
g7x7zvxg010xrc5o2w9o37o9bz8ouj60	.eJxVykEKwkAMRuG7ZG1duHDRlUfwBkOY_pbBZDokGVDEu7dQBd1-772oOyxBuQiNhBOGmdt5CHhc8GBtgmNelA77aItg-64GLxNqfH1Ci3THc2t_VFnxY7cukjhnuNMY1vHx4km58gzb-b0C-AQ2Lg:1wiD9c:zhYxES0NUrBj-lxficVLj81nXTL_P-JbV4iUvyhutcA	2026-07-24 11:28:40.58067-04
hz1l00b8do1y490slaa79bhs2gdd9um7	.eJxVykEKwkAMRuG7ZG1duBG68gjeYAjT3zKYTIckA4p49xaqoNvvvRd1hyUoF6GRcMIwczsPAY8LHqxNcMyL0mEfbRFs39XgZUKNr09oke54bu2PKit-7NZFEucMdxrDOj5ePClXnmE7v1f4hjYv:1wiDWq:hph6guvBktcrk69XjdDSLsUnahOhmBXMir7FvYoI_28	2026-07-24 11:52:40.051563-04
512plk16mn07u2350fnb6eqoa154tp70	.eJxVykEKwkAMRuG7ZG1duOzKI_QGQ5j-ytBkWpIMtIh3t1CFuv3ee1FzWIJyEeoJN3Qc3gU87lhZF8E1z0qX47NZsG-DwcuIGj8fsUSasO3tjyorTvZoIolzhjv1YQ1fL56UKz9hB78_3Rw2CA:1wiDm9:CwiMyP-IyysPKvtpIiVzm5v-AM0tGVJQX6LICISkuAY	2026-07-24 12:08:29.604138-04
4wemq63vydvz9oguvamh75ce5pim5m1m	.eJyrVirILypJzIkvLi0oyMlMLYrPTFGyMjTUgYmn5iZm5ihZKaUaperC1OjmZJalOqRWJOYW5KTqJefnKsGVAzkFiXmVQA0-QDUKzhmpydkKwVB9Cs75SrUAVnkpDg:1wiE0G:sE7G2DEf5CA43jj9zY2KyGKXodL65FeEY9geIlPEYco	2026-07-24 12:23:04.675662-04
fxr0fsey4vtp8i3y23o1zjx4k9blxeh0	.eJyrVirILypJzIkvLi0oyMlMLYrPTFGyMjTUgYmn5iZm5ihZKaUaperC1OjmZJalOqRWJOYW5KTqJefnKsGVAzkFiXmVQA0-QDUKzhmpydkKwVB9Cs75SrUAVnkpDg:1wiE6W:5CjEy02hN_EifsNEyt_Z9uM8TtgT63ZlQd4KZDYCZH8	2026-07-24 12:29:32.365849-04
e1okzyd01wp7407gbokcj1u7yeak7f4x	.eJxVykEKwjAQRuG7zLoV67Irj-ANwpD-leBMGmYSUcS7t1AF3X7vvag5LEA5CY2EE_oyHHtJd5zxYC2CQ1yUuv2zRbBtF4OnCbl-fUKp4Ybn1v4os-LH5iYSOEa401it4ePJg3LmK2zn9wqYrDWB:1wiEV6:4QXpRZeV4xluH4mQALcneIV88VLusTMUj9V_IywhuYk	2026-07-24 12:54:56.498917-04
2del6tk6ewu9iidj02qs99m4yj7e0a89	.eJxVykEKwjAQRuG7zNoKddmVR_AGYUh_JTiThplEWsS7W6iFuv3ee1NzWIByEhoIF3Sl7ztJL1wxsxbBOU5Kp-2zSbBuN4OnEbnuPqLU8MSytj_KrDjYvYkEjhHuNFRr-HnyoJz5Adv48wWZLjWC:1wiEr1:JaldEKZrfBkw05t4eqW8yAW_UZIOcspGk1LW8U7qat8	2026-07-24 13:17:35.115829-04
mc127lwgyd1le7mdi9kb120bhfxabefd	.eJxVzEEKwjAQheG7zLr0AF0VvIA3CEP6lOhMEmYSsIh3N1C7cPv9j_em7rAA5SS00IMVPke2BlvxYq2CORal6dhZEYzZ1eBpQ26nb6gtPLGP9kd5_A27FK2c9zPdukjgGOFOS7OOnycPypnvsIM_X6LfOUA:1wkpb4:vFECWRoiiZHCipM77841Ki4TWOzT-uEkIwi5IxQQ0Hg	2026-07-31 16:55:50.338678-04
u2qljvfdrnjldabnyboigywolip98up5	.eJxVzEEKwjAQheG7zLr0AF0VvIA3CEP6lOhMEmYSsIh3N1C7cPv9j_em7rAA5SS00IMVPke2BlvxYq2CORal6dhZEYzZ1eBpQ26nb6gtPLGP9kd5_A27FK2c9zPdukjgGOFOS7OOnycPypnvsIM_X6LfOUA:1wkpiV:zE_dIfCxlINpD_a41rE6tTduavtaCyHOJJITBckhIAU	2026-07-31 17:03:31.477692-04
smo78o45jsfvatzvbtt0o818bip14gwl	.eJxVzjEOwjAMheGroMyIA3RiZWNgj6z0tVgkNrLdASHuTlCpEOv_Pkt-psVhGY24piHBuBw9wNJIDkVb2q_AtKLvZ4PzCImtj7hHvuHRN5ZJrVGwSg6U6x8Rap_708_sLt2IVp0ZvtlpqTVTKXBPQ9iCb2fP_SGaYWt-vQFGPUPz:1wlypa:7SHnjsA5pMV2rQE2LoosENBtLgqMsjdfONPx7NYYdkk	2026-08-03 20:59:34.110784-04
\.


--
-- Data for Name: employee_deduction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_deduction (id, people_id, deduction_type_id, calc_method, amount, is_active, effective_date, end_date, notes, created_by) FROM stdin;
1	101	1	flat	250	1	2026-06-27	\N		seed
2	101	2	flat	45	1	2026-06-27	\N		seed
3	101	3	flat	12	1	2026-06-27	\N		seed
4	101	4	percent	6	1	2026-06-27	\N		seed
5	101	5	flat	25	1	2026-06-27	\N		seed
6	102	1	flat	250	1	2026-06-27	\N		seed
7	102	2	flat	45	1	2026-06-27	\N		seed
8	102	4	percent	5	1	2026-06-27	\N		seed
9	102	5	flat	15	1	2026-06-27	\N		seed
10	117	1	flat	250	1	2026-06-27	\N		seed
11	117	2	flat	45	1	2026-06-27	\N		seed
12	117	4	percent	4	1	2026-06-27	\N		seed
13	121	1	flat	250	1	2026-06-27	\N		seed
14	121	2	flat	45	1	2026-06-27	\N		seed
15	121	3	flat	12	1	2026-06-27	\N		seed
16	121	4	percent	5	1	2026-06-27	\N		seed
17	121	5	flat	15	1	2026-06-27	\N		seed
18	125	1	flat	250	1	2026-06-27	\N		seed
19	125	4	percent	3	1	2026-06-27	\N		seed
20	109	1	flat	250	1	2026-06-27	\N		seed
21	110	1	flat	250	1	2026-06-27	\N		seed
22	111	1	flat	250	1	2026-06-27	\N		seed
23	115	1	flat	250	1	2026-06-27	\N		seed
24	115	4	percent	3	1	2026-06-27	\N		seed
25	116	1	flat	250	1	2026-06-27	\N		seed
26	116	4	percent	4	1	2026-06-27	\N		seed
27	123	1	flat	250	1	2026-06-27	\N		seed
28	129	1	flat	250	1	2026-06-27	\N		seed
29	101	6	flat	250	1	2026-07-05	\N		SMPL-PAY-
30	101	7	flat	45	1	2026-07-05	\N		SMPL-PAY-
31	101	8	flat	12	1	2026-07-05	\N		SMPL-PAY-
32	101	9	percent	6	1	2026-07-05	\N		SMPL-PAY-
33	101	10	flat	25	1	2026-07-05	\N		SMPL-PAY-
34	102	6	flat	250	1	2026-07-05	\N		SMPL-PAY-
35	102	7	flat	45	1	2026-07-05	\N		SMPL-PAY-
36	102	9	percent	5	1	2026-07-05	\N		SMPL-PAY-
37	102	10	flat	15	1	2026-07-05	\N		SMPL-PAY-
38	117	6	flat	250	1	2026-07-05	\N		SMPL-PAY-
39	117	7	flat	45	1	2026-07-05	\N		SMPL-PAY-
40	117	9	percent	4	1	2026-07-05	\N		SMPL-PAY-
41	121	6	flat	250	1	2026-07-05	\N		SMPL-PAY-
42	121	7	flat	45	1	2026-07-05	\N		SMPL-PAY-
43	121	8	flat	12	1	2026-07-05	\N		SMPL-PAY-
44	121	9	percent	5	1	2026-07-05	\N		SMPL-PAY-
45	121	10	flat	15	1	2026-07-05	\N		SMPL-PAY-
46	125	6	flat	250	1	2026-07-05	\N		SMPL-PAY-
47	125	9	percent	3	1	2026-07-05	\N		SMPL-PAY-
48	109	6	flat	250	1	2026-07-05	\N		SMPL-PAY-
49	110	6	flat	250	1	2026-07-05	\N		SMPL-PAY-
50	111	6	flat	250	1	2026-07-05	\N		SMPL-PAY-
51	115	6	flat	250	1	2026-07-05	\N		SMPL-PAY-
52	115	9	percent	3	1	2026-07-05	\N		SMPL-PAY-
53	116	6	flat	250	1	2026-07-05	\N		SMPL-PAY-
54	116	9	percent	4	1	2026-07-05	\N		SMPL-PAY-
55	123	6	flat	250	1	2026-07-05	\N		SMPL-PAY-
56	129	6	flat	250	1	2026-07-05	\N		SMPL-PAY-
\.


--
-- Data for Name: employee_pay; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_pay (id, people_id, pay_type, pay_rate, effective_date, created_by) FROM stdin;
1	101	salary	120000	2025-06-27	seed
2	102	salary	85000	2025-08-31	seed
3	109	hourly	20	2025-12-09	seed
4	110	hourly	24	2025-12-29	seed
5	111	hourly	19.5	2026-01-28	seed
6	115	hourly	26	2025-05-23	seed
7	116	hourly	32	2025-07-12	seed
8	117	salary	65000	2025-09-20	seed
9	121	salary	90000	2025-08-11	seed
10	123	hourly	24	2025-09-10	seed
11	125	salary	70000	2025-10-10	seed
12	129	hourly	26	2025-11-09	seed
\.


--
-- Data for Name: eng_design_review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.eng_design_review (id, ecr_number, title, product_id, project_id, requested_by, review_date, status, notes) FROM stdin;
1	SMPL-ENG-ECR-2026-0001	ECR: Drive Shaft Material Change to 4340 Steel	\N	1	Sarah Chen	2026-04-27	approved	Sample data
2	SMPL-ENG-ECR-2026-0002	ECR: Frame Wall Thickness Reduction	\N	2	Raj Patel	2026-05-12	pending	Sample data
3	SMPL-ENG-ECR-2026-0003	ECR: Fixture Quick-Change Clamp Design	\N	3	Sarah Chen	2026-06-19	draft	Sample data
4	SMPL-ENG-ECR-2026-0004	ECR: Hydraulic Pump Relocation	\N	4	Wei Zhang	2026-05-27	rejected	Sample data
5	SMPL-ENG-ECR-2026-0005	ECR: Laser Safety Interlock Wiring Revision	\N	5	Wei Zhang	2025-12-28	approved	Sample data
6	SMPL-ENG-ECR-2026-0006	ECR: Add RFID Tracking to Compact Module	\N	6	Raj Patel	2026-06-24	draft	Sample data
\.


--
-- Data for Name: eng_project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.eng_project (id, project_number, title, product_id, engineer, start_date, due_date, status, notes) FROM stdin;
1	SMPL-ENG-PROJ-2026-0001	Next-Gen Drive Shaft Redesign	\N	Sarah Chen	2026-02-26	2026-04-27	in_progress	Sample data
2	SMPL-ENG-PROJ-2026-0002	Weight Reduction Initiative — Frame	\N	Raj Patel	2026-03-28	2026-04-27	in_progress	Sample data
3	SMPL-ENG-PROJ-2026-0003	Automated Assembly Fixture Design	\N	Sarah Chen	2026-05-12	2026-08-10	planning	Sample data
4	SMPL-ENG-PROJ-2026-0004	Hydraulic System Upgrade v2	\N	Wei Zhang	2025-12-28	2025-12-18	on_hold	Sample data
5	SMPL-ENG-PROJ-2026-0005	Laser Cutter Integration Study	\N	Raj Patel	2025-12-08	2025-11-08	completed	Sample data
6	SMPL-ENG-PROJ-2026-0006	New Product Line — Compact Module	\N	Wei Zhang	2026-05-27	2026-09-24	planning	Sample data
\.


--
-- Data for Name: eng_standard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.eng_standard (id, standard_number, title, category, version, status, review_date, description, notes, created_by, created_date) FROM stdin;
1	ISO 9001:2015	Quality Management Systems — Requirements	ISO	2015	Active	2025-06-26		 Sample data	seed	2026-06-26
2	ANSI B11.1-2009	Safety Requirements for Mechanical Power Presses	ANSI	2009	Active	2025-12-28		 Sample data	seed	2026-06-26
3	ASME Y14.5-2018	Dimensioning and Tolerancing (GD&T)	ASME	2018	Active	2026-03-28		 Sample data	seed	2026-06-26
4	IEEE 519-2014	Harmonic Control in Electric Power Systems	IEEE	2014	Active	2025-09-29		 Sample data	seed	2026-06-26
5	OSHA 1910.147	Lockout/Tagout — Control of Hazardous Energy	OSHA	2019	Active	2026-04-27		 Sample data	seed	2026-06-26
6	INT-WI-CNC-04	CNC Machining Work Instruction — Setup & Operation	Internal	Rev 3	Active	2026-05-27		 Sample data	seed	2026-06-26
7	INT-QP-INS-01	Incoming Inspection Procedure	Internal	Rev 7	Under Review	2026-06-11		 Sample data	seed	2026-06-26
8	ANSI B11.19-2019	Performance Requirements for Safeguarding Machinery	ANSI	2019	Active	2026-02-26		 Sample data	seed	2026-06-26
9	ISO 9001:2015	Quality Management Systems — Requirements	ISO	2015	Active	2025-07-05		 Sample data	SMPL-ENG-	2026-07-05
10	ANSI B11.1-2009	Safety Requirements for Mechanical Power Presses	ANSI	2009	Active	2026-01-06		 Sample data	SMPL-ENG-	2026-07-05
11	ASME Y14.5-2018	Dimensioning and Tolerancing (GD&T)	ASME	2018	Active	2026-04-06		 Sample data	SMPL-ENG-	2026-07-05
12	IEEE 519-2014	Harmonic Control in Electric Power Systems	IEEE	2014	Active	2025-10-08		 Sample data	SMPL-ENG-	2026-07-05
13	OSHA 1910.147	Lockout/Tagout — Control of Hazardous Energy	OSHA	2019	Active	2026-05-06		 Sample data	SMPL-ENG-	2026-07-05
14	INT-WI-CNC-04	CNC Machining Work Instruction — Setup & Operation	Internal	Rev 3	Active	2026-06-05		 Sample data	SMPL-ENG-	2026-07-05
15	INT-QP-INS-01	Incoming Inspection Procedure	Internal	Rev 7	Under Review	2026-06-20		 Sample data	SMPL-ENG-	2026-07-05
16	ANSI B11.19-2019	Performance Requirements for Safeguarding Machinery	ANSI	2019	Active	2026-03-07		 Sample data	SMPL-ENG-	2026-07-05
\.


--
-- Data for Name: eng_task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.eng_task (id, project_id, task_name, assigned_to, due_date, priority, status, notes) FROM stdin;
1	1	Literature review — shaft fatigue analysis	Sarah Chen	2026-04-07	high	completed	Sample data
2	1	FEA model — torsional stress under peak load	Sarah Chen	2026-05-07	critical	completed	Sample data
3	1	Prototype drawing release to shop	Raj Patel	2026-07-06	high	in_progress	Sample data
4	1	Material selection sign-off	Wei Zhang	2026-07-16	medium	open	Sample data
5	2	Topology optimization — frame cross-member	Raj Patel	2026-05-27	high	completed	Sample data
6	2	Weight budget review with management	Sarah Chen	2026-07-11	medium	in_progress	Sample data
7	2	Supplier RFQ for aluminum extrusions	Wei Zhang	2026-07-21	medium	open	Sample data
8	3	Fixture concept sketches	Sarah Chen	2026-07-26	low	in_progress	Sample data
9	3	Interference check with existing tooling	Raj Patel	2026-08-25	medium	open	Sample data
10	5	Site survey — laser integration points	Wei Zhang	2025-12-18	high	completed	Sample data
11	5	Integration report final draft	Wei Zhang	2026-01-27	high	completed	Sample data
\.


--
-- Data for Name: gl_account; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gl_account (id, account_number, account_name, account_type, account_sub, is_active, notes) FROM stdin;
1	1000	Cash	Asset	Current	1	
2	1010	Petty Cash	Asset	Current	1	
3	1100	Accounts Receivable	Asset	Current	1	
4	1150	Allowance for Doubtful Accts	Asset	Current	1	
5	1200	Raw Materials Inventory	Asset	Current	1	
6	1210	Work in Process Inventory	Asset	Current	1	
7	1220	Finished Goods Inventory	Asset	Current	1	
8	1300	Prepaid Expenses	Asset	Current	1	
9	1500	Property, Plant & Equipment	Asset	Fixed	1	
10	1510	Accumulated Depreciation	Asset	Fixed	1	
11	1600	Other Assets	Asset	Other	1	
12	2000	Accounts Payable	Liability	Current	1	
13	2100	Accrued Liabilities	Liability	Current	1	
14	2200	Payroll Liabilities	Liability	Current	1	
15	2300	Sales Tax Payable	Liability	Current	1	
16	2400	Notes Payable - Short Term	Liability	Current	1	
17	2500	Notes Payable - Long Term	Liability	Long-term	1	
18	2600	Other Long-Term Liabilities	Liability	Long-term	1	
19	3000	Common Stock	Equity		1	
20	3100	Retained Earnings	Equity		1	
21	3200	Dividends Paid	Equity		1	
22	3900	Current Year Earnings	Equity		1	
23	4000	Sales Revenue	Revenue	Operating	1	
24	4100	Service Revenue	Revenue	Operating	1	
25	4200	Shipping & Handling Income	Revenue	Operating	1	
26	4900	Other Income	Revenue	Other	1	
27	5000	Cost of Goods Sold	COGS		1	
28	5100	Raw Materials Used	COGS		1	
29	5200	Direct Labor	COGS		1	
30	5300	Manufacturing Overhead	COGS		1	
31	5400	Freight & Shipping	COGS		1	
32	6000	Salaries & Wages	Expense	Operating	1	
33	6100	Payroll Taxes	Expense	Operating	1	
34	6200	Rent Expense	Expense	Operating	1	
35	6300	Utilities	Expense	Operating	1	
36	6400	Insurance	Expense	Operating	1	
37	6500	Depreciation Expense	Expense	Operating	1	
38	6600	Office Supplies	Expense	Operating	1	
39	6700	Marketing & Advertising	Expense	Operating	1	
40	6800	Professional Services	Expense	Operating	1	
41	6900	Travel & Entertainment	Expense	Operating	1	
42	7000	Interest Expense	Expense	Non-operating	1	
43	7100	Bank Charges	Expense	Non-operating	1	
44	7900	Other Expense	Expense	Other	1	
\.


--
-- Data for Name: gl_account_map; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gl_account_map (id, category, account_number, description, is_active) FROM stdin;
1	raw_material	1200	Inventory — raw material	t
2	wip	1200	Inventory — work in process	t
3	finished_goods	1200	Inventory — finished goods	t
4	cogs	5000	Direct Materials (COGS)	t
5	material_variance	5000	Material variance posts to Direct Materials	t
6	labor_variance	5100	Labor variance posts to Direct Labor	t
7	ap_payable	2000	Accounts Payable	t
\.


--
-- Data for Name: gl_journal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gl_journal (id, journal_date, reference, description, posted, created_by, created_at) FROM stdin;
2	2026-05-19	AP-2026-0001	AP Invoice - Test Vendor	1	System	2026-05-19 15:05:40
3	2026-05-19	AR-2026-0001	AR Invoice - Test Customer	1	System	2026-05-19 15:05:40
4	2026-05-19	PAYROLL-2026-05-06	Payroll run 2026-05-06 – 2026-05-19 (Bi-Weekly)	1	System	2026-05-19 15:05:40
5	2026-01-01	OB-2026-0001	Opening balance — initial cash investment	1	System	2026-05-19 16:33:28
6	2026-06-01	SMPL-ACCT-JE-2026-001	Record product sales — May	1	seed	2026-06-26 23:36:07
7	2026-06-01	SMPL-ACCT-JE-2026-002	Record AP — Metal Fab invoice	1	seed	2026-06-26 23:36:07
8	2026-06-25	SMPL-ACCT-JE-2026-003	Monthly rent expense — June	1	seed	2026-06-26 23:36:07
9	2026-06-19	SMPL-ACCT-JE-2026-004	Payroll — bi-weekly run	1	seed	2026-06-26 23:36:07
10	2026-06-21	SMPL-ACCT-JE-2026-005	Payroll funding — ACH	1	seed	2026-06-26 23:36:07
11	2026-05-27	SMPL-ACCT-JE-2026-006	Monthly depreciation	1	seed	2026-06-26 23:36:07
12	2026-04-27	SMPL-ACCT-JE-2026-007	Insurance premium — Q2	1	seed	2026-06-26 23:36:07
13	2026-06-08	SMPL-ACCT-JE-2026-008	AR receipt — Greenfield	1	seed	2026-06-26 23:36:07
\.


--
-- Data for Name: gl_journal_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gl_journal_line (id, journal_id, account_id, debit, credit, memo, cost_center_id) FROM stdin;
3	2	44	500	0	AP Invoice AP-2026-0001	\N
4	2	12	0	500	AP Invoice AP-2026-0001	\N
5	3	3	1200	0	AR Invoice AR-2026-0001	\N
6	3	23	0	1200	AR Invoice AR-2026-0001	\N
7	4	32	8400	0	Gross wages	\N
8	4	1	0	6930	Net pay disbursed	\N
9	4	14	0	1470	Taxes & withholding	\N
10	5	1	50000	0	Opening cash balance	\N
11	5	19	0	50000	Owner investment	\N
12	6	23	0	48500	Product sales revenue	\N
13	6	3	48500	0	AR — Apex Manufacturing	\N
14	7	27	12400	0	Steel sheet materials	\N
15	7	12	0	12400	AP — Metal Fab Co.	\N
16	8	33	8500	0	Office & plant rent	\N
17	8	1	0	8500	Checking account	\N
18	9	32	62400	0	Salaries & wages	\N
19	9	13	0	62400	Accrued payroll	\N
20	10	13	62400	0	Clear accrued payroll	\N
21	10	1	0	62400	Checking account	\N
22	11	36	3800	0	Depreciation expense	\N
23	11	10	0	3800	Accum depr — equipment	\N
24	12	39	4200	0	Insurance expense	\N
25	12	1	0	4200	Checking account	\N
26	13	1	22300	0	Cash receipt	\N
27	13	3	0	22300	AR — Greenfield Assembly	\N
\.


--
-- Data for Name: inventory_transaction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_transaction (id, product_id, trans_date, trans_type, quantity, reference, notes, lot_id) FROM stdin;
\.


--
-- Data for Name: it_asset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.it_asset (id, asset_tag, asset_type, make, model, serial_number, assigned_to, department, purchase_date, warranty_exp, status, notes, created_by) FROM stdin;
1	SMPL-IT-ASSET-001	Desktop	Dell	OptiPlex 7090	DL7090-001	Linda Carter	Accounting	2024-07-05	2027-07-05	active	Sample data	
2	SMPL-IT-ASSET-002	Laptop	HP	EliteBook 840	HP840-002	James Wu	Production	2025-07-05	2028-07-04	active	Sample data	
3	SMPL-IT-ASSET-003	Laptop	Lenovo	ThinkPad T14	LN14-003	Priya Sharma	Engineering	2026-01-06	2029-01-05	active	Sample data	
4	SMPL-IT-ASSET-004	Server	Dell	PowerEdge R750	DPE750-004		IT	2024-01-17	2029-01-15	active	Sample data	
5	SMPL-IT-ASSET-005	Printer	HP	LaserJet Pro M428	HPLJ-005		Production	2025-05-31	2027-05-31	repair	Sample data	
6	SMPL-IT-ASSET-006	Desktop	HP	EliteDesk 800	HPED-006	Bob Nguyen	Sales	2025-02-20	2028-02-20	active	Sample data	
7	SMPL-IT-ASSET-007	Monitor	Dell	UltraSharp U2722	DU2722-007	Anna Kowalski	HR	2025-12-17	2028-12-16	active	Sample data	
8	SMPL-IT-ASSET-008	Switch	Cisco	Catalyst 2960-X	CS2960-008		IT	2023-07-01	2028-06-29	active	Sample data	
9	SMPL-IT-ASSET-009	Laptop	Apple	MacBook Pro 14	MBPRO-009	Rachel Green	Cust Svc	2026-04-06	2029-04-05	active	Sample data	
10	SMPL-IT-ASSET-010	Desktop	Dell	OptiPlex 5090	DL5090-010	Carlos Ruiz	Production	2024-04-26	2027-04-26	active	Sample data	
11	SMPL-IT-ASSET-011	UPS	APC	Smart-UPS 1500	APC1500-011		IT	2024-11-12	2027-11-12	active	Sample data	
12	SMPL-IT-ASSET-012	Laptop	Dell	Latitude 5530	DL5530-012	Susan Park	Legal	2026-03-07	2029-03-06	active	Sample data	
13	SMPL-IT-ASSET-013	Phone	Cisco	IP Phone 8841	CIPH-013	David Kim	Finance	2025-05-31	2028-05-30	active	Sample data	
14	SMPL-IT-ASSET-014	Desktop	HP	EliteDesk 705	HPED-014		Warehouse	2023-03-23	2026-03-22	retired	Sample data	
15	SMPL-IT-ASSET-015	Server	HP	ProLiant DL380	HPDL-015		IT	2025-02-20	2030-02-19	active	Sample data	
\.


--
-- Data for Name: it_asset_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.it_asset_history (id, asset_tag, asset_id, event_type, description, changed_by, changed_at) FROM stdin;
\.


--
-- Data for Name: it_bandwidth_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.it_bandwidth_log (id, interface_name, recorded_at, mbps_in, mbps_out, notes, created_by) FROM stdin;
\.


--
-- Data for Name: it_license; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.it_license (id, software_name, vendor, license_key, license_type, seats, seats_used, purchase_date, expiry_date, cost, status, notes, created_by) FROM stdin;
1	Microsoft 365 Business	Microsoft	MS365-XXXX-YYYY	subscription	50	38	2025-07-05	2026-07-05	12000	active	Sample data	SMPL-IT-
2	Adobe Creative Cloud	Adobe	ACC-XXXX-YYYY	subscription	5	3	2026-01-06	2026-07-05	3000	active	Sample data	SMPL-IT-
3	AutoCAD LT 2024	Autodesk	ACAD-XXXX-YYYY	subscription	3	2	2026-04-06	2027-01-06	2400	active	Sample data	SMPL-IT-
4	SOLIDWORKS Standard	Dassault	SW-XXXX-YYYY	perpetual	2	2	2024-07-05	2034-07-03	8000	active	Sample data	SMPL-IT-
5	Salesforce Starter	Salesforce	SF-XXXX-YYYY	subscription	10	6	2026-05-06	2027-03-07	6000	active	Sample data	SMPL-IT-
6	Zoom Business	Zoom	ZOOM-XXXX-YYYY	subscription	25	18	2026-04-07	2027-01-08	4500	active	Sample data	SMPL-IT-
7	DocuSign Business Pro	DocuSign	DS-XXXX-YYYY	subscription	5	2	2026-06-05	2027-05-06	1500	active	Sample data	SMPL-IT-
8	Antivirus Enterprise	Bitdefender	BD-XXXX-YYYY	subscription	60	55	2025-07-05	2025-07-05	1800	expired	Sample data	SMPL-IT-
9	Old MES License	Legacy Corp	MES-XXXX-YYYY	perpetual	5	1	2023-07-06	2033-07-03	15000	active	Sample data	SMPL-IT-
\.


--
-- Data for Name: it_network_device; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.it_network_device (id, hostname, ip_address, mac_address, device_type, manufacturer, model, location, status, last_seen, notes, created_by) FROM stdin;
1	core-sw-01	10.0.0.1	00:1A:2B:3C:4D:01	Switch	Cisco	Catalyst 2960-X	Server Room	online	2026-07-05	Sample data	SMPL-IT-
2	core-sw-02	10.0.0.2	00:1A:2B:3C:4D:02	Switch	Cisco	Catalyst 2960-X	Server Room	online	2026-07-05	Sample data	SMPL-IT-
3	fw-01	10.0.0.254	00:1A:2B:3C:4D:FE	Firewall	Fortinet	FortiGate 200F	Server Room	online	2026-07-05	Sample data	SMPL-IT-
4	ap-floor1-01	10.0.1.10	00:1A:2B:3C:4D:10	Access Point	Ubiquiti	UniFi AP-AC-Pro	Floor 1	online	2026-07-05	Sample data	SMPL-IT-
5	ap-floor2-01	10.0.2.10	00:1A:2B:3C:4D:20	Access Point	Ubiquiti	UniFi AP-AC-Pro	Floor 2	online	2026-07-04	Sample data	SMPL-IT-
6	nas-01	10.0.0.10	00:1A:2B:3C:4D:0A	NAS	Synology	DS1821+	Server Room	online	2026-07-05	Sample data	SMPL-IT-
7	srv-app-01	10.0.0.20	00:1A:2B:3C:4D:14	Server	Dell	PowerEdge R750	Server Room	online	2026-07-05	Sample data	SMPL-IT-
8	srv-db-01	10.0.0.21	00:1A:2B:3C:4D:15	Server	HP	ProLiant DL380	Server Room	online	2026-07-05	Sample data	SMPL-IT-
9	prt-acct-01	10.0.3.5	00:1A:2B:3C:4D:30	Printer	HP	LaserJet Pro M428	Accounting	offline	2026-07-02	Sample data	SMPL-IT-
10	ap-wh-01	10.0.4.10	00:1A:2B:3C:4D:40	Access Point	Ubiquiti	UniFi AP-HD	Warehouse	maintenance	2026-07-03	Sample data	SMPL-IT-
\.


--
-- Data for Name: it_network_incident; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.it_network_incident (id, title, severity, status, description, affected_systems, reported_date, resolved_date, notes, created_by) FROM stdin;
\.


--
-- Data for Name: it_repair; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.it_repair (id, asset_tag, problem_description, reported_by, reported_date, assigned_to, priority, status, resolution, completed_date, notes, created_by) FROM stdin;
1	SMPL-IT-ASSET-005	Paper feed jam and roller worn out	Bob Nguyen	2026-06-30	Mike Torres	medium	in_progress		\N	Sample data	SMPL-IT-
2	SMPL-IT-ASSET-010	Overheating — fan replaced, thermal paste	Carlos Ruiz	2026-06-23	Sara Patel	high	completed		2026-06-30	Sample data	SMPL-IT-
3	SMPL-IT-ASSET-002	Cracked screen after drop, needs replacement	James Wu	2026-07-03	Mike Torres	high	open		\N	Sample data	SMPL-IT-
4	SMPL-IT-ASSET-014	PSU failure on retired unit — for parts	IT Dept	2026-06-05	Sara Patel	low	cancelled		\N	Sample data	SMPL-IT-
\.


--
-- Data for Name: it_software_install; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.it_software_install (id, asset_tag, software_name, version, vendor, install_date, status, installed_by, notes, created_by) FROM stdin;
1	SMPL-IT-ASSET-001	Microsoft 365	2024	Microsoft	2025-07-05	installed	Mike Torres	Sample data	SMPL-IT-
2	SMPL-IT-ASSET-001	Adobe Acrobat Pro	2024.1	Adobe	2025-09-08	installed	Mike Torres	Sample data	SMPL-IT-
3	SMPL-IT-ASSET-002	Microsoft 365	2024	Microsoft	2026-01-06	installed	Sara Patel	Sample data	SMPL-IT-
4	SMPL-IT-ASSET-002	AutoCAD LT	2024	Autodesk	2026-01-06	installed	Sara Patel	Sample data	SMPL-IT-
5	SMPL-IT-ASSET-003	Microsoft 365	2024	Microsoft	2026-04-06	installed	Mike Torres	Sample data	SMPL-IT-
6	SMPL-IT-ASSET-003	SOLIDWORKS	2024 SP2	Dassault	2026-04-06	installed	Mike Torres	Sample data	SMPL-IT-
7	SMPL-IT-ASSET-006	Salesforce CRM	Winter 25	Salesforce	2026-05-06	installed	Sara Patel	Sample data	SMPL-IT-
8	SMPL-IT-ASSET-006	Microsoft 365	2024	Microsoft	2025-02-20	installed	Mike Torres	Sample data	SMPL-IT-
9	SMPL-IT-ASSET-009	Microsoft 365	2024	Microsoft	2026-04-07	installed	Sara Patel	Sample data	SMPL-IT-
10	SMPL-IT-ASSET-009	Zoom	5.17	Zoom Video	2026-04-07	installed	Sara Patel	Sample data	SMPL-IT-
11	SMPL-IT-ASSET-010	MES Client	3.4.1	Internal	2024-04-26	installed	Mike Torres	Sample data	SMPL-IT-
12	SMPL-IT-ASSET-012	Microsoft 365	2024	Microsoft	2026-03-07	installed	Mike Torres	Sample data	SMPL-IT-
13	SMPL-IT-ASSET-012	DocuSign	23.4	DocuSign	2026-06-05	installed	Sara Patel	Sample data	SMPL-IT-
14	SMPL-IT-ASSET-001	Old ERP Client	7.1	Legacy Corp	2024-07-05	removed	Mike Torres	Sample data	SMPL-IT-
\.


--
-- Data for Name: it_task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.it_task (id, task_number, task_name, task_type, description, assigned_to, department, priority, scheduled_date, due_date, completed_date, status, notes, created_by) FROM stdin;
1	SMPL-IT-TASK-001	Patch Tuesday server updates	Maintenance	Apply June security patches to all servers	Mike Torres	IT	high	2026-07-04	2026-07-05	\N	in_progress	Sample data	SMPL-IT-
2	SMPL-IT-TASK-002	Deploy new user workstations	Hardware Setup	Set up 3 desktops for new Accounting hires	Sara Patel	Accounting	medium	2026-07-02	2026-07-06	\N	pending	Sample data	SMPL-IT-
3	SMPL-IT-TASK-003	Firewall rule audit	Security	Review and clean up stale firewall rules	Mike Torres	IT	high	2026-06-28	2026-06-28	\N	in_progress	Sample data	SMPL-IT-
4	SMPL-IT-TASK-004	Upgrade NAS firmware	Upgrade	Synology DSM upgrade to 7.2.1	Sara Patel	IT	medium	2026-06-21	2026-06-11	2026-06-12	completed	Sample data	SMPL-IT-
5	SMPL-IT-TASK-005	Configure new VoIP phones	Configuration	Set up 10 Cisco phones for Sales expansion	Mike Torres	Sales	medium	2026-07-05	2026-07-10	\N	pending	Sample data	SMPL-IT-
6	SMPL-IT-TASK-006	Wireless survey floor 3	Network	Site survey for AP placement on new floor	Sara Patel	IT	low	2026-07-03	2026-07-13	\N	pending	Sample data	SMPL-IT-
7	SMPL-IT-TASK-007	Onboard new ERP module	Software Deployment	Install and configure procurement module on app server	Mike Torres	Production	high	2026-06-30	2026-07-02	\N	in_progress	Sample data	SMPL-IT-
8	SMPL-IT-TASK-008	Quarterly backup verification	Backup / Recovery	Restore test from NAS to verify backup integrity	Sara Patel	IT	high	2026-06-05	2026-05-11	2026-05-12	completed	Sample data	SMPL-IT-
9	SMPL-IT-TASK-009	Decommission old file server	Maintenance	Migrate remaining shares, wipe and retire srv-old-01	Mike Torres	IT	low	2026-07-05	2026-07-19	\N	pending	Sample data	SMPL-IT-
10	SMPL-IT-TASK-010	SSL certificate renewal	Security	Renew wildcard cert expiring in 45 days	Sara Patel	IT	critical	2026-07-04	2026-08-03	\N	in_progress	Sample data	SMPL-IT-
\.


--
-- Data for Name: it_ticket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.it_ticket (id, ticket_number, requester, department, issue_type, description, priority, assigned_to, submitted_date, due_date, resolved_date, status, notes, created_by) FROM stdin;
1	SMPL-IT-TKT-001	Linda Carter	Accounting	Software	Excel crashes on large pivot tables — latest update broke something	high	Mike Torres	2026-07-03	2026-07-06	\N	open		SMPL-IT-
2	SMPL-IT-TKT-002	James Wu	Production	Hardware	CNC machine workstation won't power on after storm outage	critical	Sara Patel	2026-07-04	2026-07-05	\N	in_progress		SMPL-IT-
3	SMPL-IT-TKT-003	Anna Kowalski	HR	Account	New hire needs domain account and email setup	medium		2026-07-02	2026-07-07	\N	open		SMPL-IT-
4	SMPL-IT-TKT-004	Bob Nguyen	Sales	Network	VPN drops every hour when working from home	low		2026-07-01	2026-07-08	\N	open		SMPL-IT-
5	SMPL-IT-TKT-005	Priya Sharma	Engineering	Printer	HP printer in lab won't accept jobs from macOS clients	medium	Mike Torres	2026-06-25	2026-06-20	2026-06-21	resolved		SMPL-IT-
6	SMPL-IT-TKT-006	Tom Bradley	Warehouse	Hardware	Barcode scanner keeps dropping Bluetooth connection	high	Sara Patel	2026-07-04	2026-07-06	\N	in_progress		SMPL-IT-
7	SMPL-IT-TKT-007	Rachel Green	Customer Svc	Email	Outlook not syncing shared calendar with team	medium	Mike Torres	2026-06-21	2026-06-12	2026-06-13	closed		SMPL-IT-
8	SMPL-IT-TKT-008	David Kim	Finance	Software	QuickBooks license expired — need renewal or replacement	low		2026-07-04	2026-07-09	\N	open		SMPL-IT-
9	SMPL-IT-TKT-009	Susan Park	Legal	Access / Permissions	Cannot access contract management folder on share drive	medium	Sara Patel	2026-07-02	2026-07-04	\N	in_progress		SMPL-IT-
10	SMPL-IT-TKT-010	Carlos Ruiz	Production	Hardware	Monitor on assembly line PC showing color distortion	critical		2026-07-05	2026-07-06	\N	open		SMPL-IT-
11	SMPL-IT-TKT-011	Janet Mills	Purchasing	Other	Keyboard sticking on multiple keys — request replacement	low	Mike Torres	2026-06-15	2026-05-31	2026-06-01	resolved		SMPL-IT-
12	SMPL-IT-TKT-012	Frank Deluca	IT	Network	Core switch log showing excessive CRC errors on port 24	high		2026-07-04	2026-07-05	\N	open		SMPL-IT-
\.


--
-- Data for Name: legal_compliance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.legal_compliance (id, requirement, regulation, owner, due_date, completed_date, status, notes) FROM stdin;
1	OSHA 1910.147 Lockout/Tagout Annual Training	OSHA 29 CFR 1910.147	Janet Flores	2026-07-26	\N	Pending	Sample data
2	EPA Tier II Hazardous Chemical Reporting	EPA EPCRA Sec. 312	Sandra Pierce	2026-08-25	\N	In Progress	Sample data
3	GDPR Data Processing Agreement Review	GDPR Article 28	Janet Flores	2026-08-10	\N	In Progress	Sample data
4	Annual ITAR Compliance Self-Assessment	22 CFR Part 120-130	Sandra Pierce	2026-09-24	\N	Pending	Sample data
5	Workers Comp Insurance Renewal	State Labor Code	Janet Flores	2026-07-26	\N	Pending	Sample data
6	ISO 9001 Certificate Renewal	ISO 9001:2015	Sandra Pierce	2026-12-23	\N	Pending	Sample data
7	ADA Website Accessibility Audit	ADA Title III	Janet Flores	2026-08-25	\N	Pending	Sample data
8	OSHA 300 Log Annual Summary Posting	OSHA 29 CFR 1904.32	Sandra Pierce	2026-05-27	2026-05-29	Complete	Sample data
9	PCI-DSS Payment Card Security Review	PCI-DSS v4.0	Janet Flores	2026-04-27	2026-05-02	Complete	Sample data
10	State Sales Tax Nexus Review	State Rev. Code	Sandra Pierce	2026-06-11	2026-06-16	Complete	Sample data
11	Export Control Classification Review — New Parts	EAR 15 CFR Part 730	Janet Flores	2026-07-10	\N	In Progress	Sample data
12	Annual Employee Handbook Update	State Employment Law	Sandra Pierce	2026-10-24	\N	Pending	Sample data
\.


--
-- Data for Name: legal_contract; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.legal_contract (id, title, counterparty, contract_type, value, start_date, end_date, owner, status, notes) FROM stdin;
1	SMPL-LEGAL-Apex Manufacturing — Annual Supply Agreement	Apex Manufacturing Inc.	Service Agreement	96000	2025-06-26	2025-06-26	Sandra Pierce	Active	Sample data
2	SMPL-LEGAL-Office Lease — Main Plant	Realty Group LLC	Lease	204000	2024-06-26	2025-06-26	Sandra Pierce	Active	Sample data
3	SMPL-LEGAL-Software License — ERP System	TechCorp ERP	Licensing	28500	2025-06-26	2025-06-26	Janet Flores	Active	Sample data
4	SMPL-LEGAL-NDA — Summit Fabricators	Summit Fabricators	NDA	0	2026-05-27	2027-04-27	Sandra Pierce	Active	Sample data
5	SMPL-LEGAL-Vendor Agreement — Metal Fab Co.	Metal Fab Co.	Vendor	0	2025-12-28	2026-07-01	Janet Flores	Active	Sample data
6	SMPL-LEGAL-NDA — Pacific Rim Parts	Pacific Rim Parts	NDA	0	2026-06-16	2027-06-06	Sandra Pierce	Active	Sample data
7	SMPL-LEGAL-Employment Contract — Engineering Director	Raj Patel	Employment	145000	2025-06-26	2025-06-26	Janet Flores	Active	Sample data
8	SMPL-LEGAL-IT Services Agreement — TechSupport Co.	TechSupport Co.	Service Agreement	18000	2026-03-28	2026-02-26	Janet Flores	Expired	Sample data
9	SMPL-LEGAL-Partnership Agreement — Allied Components	Allied Components	Partnership	55000	2026-04-27	2027-02-26	Sandra Pierce	Active	Sample data
10	SMPL-LEGAL-Consulting Services — Apex Consulting	Apex Consulting LLC	Service Agreement	38000	2026-02-26	2026-01-27	Sandra Pierce	Expired	Sample data
11	SMPL-LEGAL-Renewal — ERP Software License	TechCorp ERP	Licensing	30000	2026-06-25	2027-06-24	Janet Flores	Draft	Sample data
12	SMPL-LEGAL-Confidentiality — Inova Systems	Inova Systems	NDA	0	2026-06-21	2027-06-16	Sandra Pierce	Active	Sample data
\.


--
-- Data for Name: legal_employment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.legal_employment (id, matter, employee, matter_type, owner, opened_date, closed_date, status, notes) FROM stdin;
\.


--
-- Data for Name: legal_governance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.legal_governance (id, item, category, owner, ref_date, reference, status, notes) FROM stdin;
\.


--
-- Data for Name: legal_ip; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.legal_ip (id, title, ip_type, registration_no, jurisdiction, filed_date, expiry_date, status, notes) FROM stdin;
\.


--
-- Data for Name: legal_litigation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.legal_litigation (id, case_name, opposing_party, court, case_type, filed_date, status, outcome, notes) FROM stdin;
1	SMPL-LEGAL-Smith v. Company — Slip & Fall	Robert Smith	Ohio Court of Common Pleas	Civil	2025-06-26	Settled	Settlement — $18,500 paid; no admission of liability	Sample data
2	SMPL-LEGAL-Patent Dispute — Valve Design	ValveTech Industries	Federal District Court N.D.	IP	2025-12-28	In Discovery	Discovery phase ongoing; hearing scheduled Q4	Sample data
3	SMPL-LEGAL-Breach of Contract — Delta Components	Delta Components Co.	Ohio Court of Common Pleas	Contract Dispute	2026-03-28	Open		Sample data
4	SMPL-LEGAL-Employment Claim — Former Employee	Mark Jennings	EEOC / Mediation	Employment	2026-05-12	Dismissed	EEOC dismissed claim; no probable cause found	Sample data
5	SMPL-LEGAL-Regulatory Notice — EPA	U.S. EPA	Administrative	Regulatory	2026-05-27	Open	Response to EPA information request — in progress	Sample data
\.


--
-- Data for Name: location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.location (id, name, code, is_active) FROM stdin;
1	Main Plant	MAIN	t
2	Warehouse	WH	t
3	Office	OFF	t
\.


--
-- Data for Name: lot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lot (id, lot_number, product_id, qty, received_date, expiry_date, status, notes, created_by, created_at) FROM stdin;
1	SMPL-OPS-STEEL-01	8	400	2026-06-05	\N	available	Incoming coil stock	SMPL-OPS-	2026-07-05 00:26:08.53046-04
2	SMPL-OPS-RIM-01	10	30	2026-06-30	\N	quarantine	Awaiting incoming inspection	SMPL-OPS-	2026-07-05 00:26:08.53046-04
3	SMPL-OPS-PAINT-01	9	15	2026-06-25	\N	hold	Batch recalled by supplier pending QA review	SMPL-OPS-	2026-07-05 00:26:08.53046-04
4	SMPL-OPS-TUBE-01	13	25	2026-03-27	2026-07-30	available	Rubber compound approaching shelf-life limit	SMPL-OPS-	2026-07-05 00:26:08.53046-04
5	SMPL-OPS-HBAR-01	6	5	2026-06-20	\N	rejected	Failed dimensional check, returned to supplier	SMPL-OPS-	2026-07-05 00:26:08.53046-04
6	SMPL-OPS-TIRE-01	12	0	2026-05-06	\N	consumed	Fully consumed in production	SMPL-OPS-	2026-07-05 00:26:08.53046-04
7	SMPL-OPS-WHEEL-01	5	8	2026-07-02	\N	available	Produced on SMPL-WO-4	SMPL-OPS-	2026-07-05 00:26:08.53046-04
\.


--
-- Data for Name: maint_downtime; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maint_downtime (id, equipment, reason, category, down_date, hours, cost, status, notes, created_by) FROM stdin;
1	Laser Cutter	Optics misaligned after power surge	Breakdown	2026-06-24	6.5	1200	Investigating	Sample data	seed
2	Industrial Chiller	Refrigerant leak detected	Breakdown	2026-06-25	10.0	2500	Ongoing	Sample data	seed
3	CNC Mill #1	Bearing failure	Breakdown	2026-05-27	8.0	950	Resolved	Sample data	seed
4	Conveyor Belt #1	Scheduled changeover to new product	Changeover	2026-05-12	2.0	0	Resolved	Sample data	seed
5	Air Compressor	Pressure valve failure	Breakdown	2026-06-11	4.0	480	Resolved	Sample data	seed
6	Paint Booth	Exhaust fan motor overheating	Breakdown	2026-06-21	3.0	320	Investigating	Sample data	seed
7	Laser Cutter	Optics misaligned after power surge	Breakdown	2026-07-03	6.5	1200	Investigating	Sample data	SMPL-MAINT-
8	Industrial Chiller	Refrigerant leak detected	Breakdown	2026-07-04	10.0	2500	Ongoing	Sample data	SMPL-MAINT-
9	CNC Mill #1	Bearing failure	Breakdown	2026-06-05	8.0	950	Resolved	Sample data	SMPL-MAINT-
10	Conveyor Belt #1	Scheduled changeover to new product	Changeover	2026-05-21	2.0	0	Resolved	Sample data	SMPL-MAINT-
11	Air Compressor	Pressure valve failure	Breakdown	2026-06-20	4.0	480	Resolved	Sample data	SMPL-MAINT-
12	Paint Booth	Exhaust fan motor overheating	Breakdown	2026-06-30	3.0	320	Investigating	Sample data	SMPL-MAINT-
\.


--
-- Data for Name: maint_equipment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maint_equipment (id, name, asset_tag, location, manufacturer, install_date, last_service, status, notes, created_by, parent_id) FROM stdin;
1	CNC Mill #1	SMPL-MAINT-EQ-001	Shop Floor A	Haas	2021-06-27	2026-05-27	Operational	Sample data	seed	\N
2	Hydraulic Press	SMPL-MAINT-EQ-002	Shop Floor B	Enerpac	2022-06-27	2026-03-28	Operational	Sample data	seed	\N
3	Air Compressor	SMPL-MAINT-EQ-003	Mechanical Rm	Ingersoll	2024-06-26	2026-06-12	Needs Service	Sample data	seed	\N
4	Conveyor Belt #1	SMPL-MAINT-EQ-004	Assembly Line	Hytrol	2023-06-27	2026-04-27	Operational	Sample data	seed	\N
5	MIG Welder	SMPL-MAINT-EQ-005	Fab Room	Miller	2025-06-26	2026-06-19	Operational	Sample data	seed	\N
6	Laser Cutter	SMPL-MAINT-EQ-006	Shop Floor A	Trumpf	2020-06-27	2026-05-12	Under Repair	Sample data	seed	\N
7	Overhead Crane	SMPL-MAINT-EQ-007	Warehouse	Gorbel	2018-06-28	2026-02-26	Operational	Sample data	seed	\N
8	Industrial Chiller	SMPL-MAINT-EQ-008	Mechanical Rm	Carrier	2024-12-25	2026-06-06	Down	Sample data	seed	\N
9	Injection Molder	SMPL-MAINT-EQ-009	Shop Floor B	Arburg	2021-12-27	2026-05-27	Operational	Sample data	seed	\N
10	Paint Booth	SMPL-MAINT-EQ-010	Finishing	Binks	2023-12-27	2025-12-28	Needs Service	Sample data	seed	\N
\.


--
-- Data for Name: maint_inspection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maint_inspection (id, area, inspection_type, inspector, scheduled_date, completed_date, result, status, notes, created_by) FROM stdin;
1	Press Area	Machine Guarding	SMPL-MAINT-Denise Fowler	2026-05-27	2026-05-28	All guards in place	Passed	Sample data	seed
2	Electrical Panel #3	Electrical	SMPL-MAINT-Denise Fowler	2026-06-12	2026-06-13	Panel overheating	Failed	Sample data	seed
3	Welding Station	Fire Safety	SMPL-MAINT-Tim Okafor	2026-04-27	2026-04-28	Passed	Passed	Sample data	seed
4	Paint Booth	Environmental	SMPL-MAINT-Tim Okafor	2026-06-19	2026-06-20	Passed with minor notes	Follow-up	Sample data	seed
5	Crane Bay	Lockout/Tagout	SMPL-MAINT-Lynn Marsh	2026-06-23			Scheduled	Sample data	seed
6	Assembly Floor	General	SMPL-MAINT-Bob Harmon	2026-07-01			Scheduled	Sample data	seed
7	Press Area	Machine Guarding	SMPL-MAINT-Denise Fowler	2026-06-05	2026-06-06	All guards in place	Passed	Sample data	SMPL-MAINT-
8	Electrical Panel #3	Electrical	SMPL-MAINT-Denise Fowler	2026-06-21	2026-06-22	Panel overheating	Failed	Sample data	SMPL-MAINT-
9	Welding Station	Fire Safety	SMPL-MAINT-Tim Okafor	2026-05-06	2026-05-07	Passed	Passed	Sample data	SMPL-MAINT-
10	Paint Booth	Environmental	SMPL-MAINT-Tim Okafor	2026-06-28	2026-06-29	Passed with minor notes	Follow-up	Sample data	SMPL-MAINT-
11	Crane Bay	Lockout/Tagout	SMPL-MAINT-Lynn Marsh	2026-07-02			Scheduled	Sample data	SMPL-MAINT-
12	Assembly Floor	General	SMPL-MAINT-Bob Harmon	2026-07-10			Scheduled	Sample data	SMPL-MAINT-
\.


--
-- Data for Name: maint_mechanic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maint_mechanic (id, name, trade, shift, phone, status, notes, created_by) FROM stdin;
1	SMPL-MAINT-Bob Harmon	Mechanical	Day	555-2101	Active	Sample data	seed
2	SMPL-MAINT-Denise Fowler	Electrical	Day	555-2102	Active	Sample data	seed
3	SMPL-MAINT-Carlos Vega	Hydraulics	Swing	555-2103	Active	Sample data	seed
4	SMPL-MAINT-Tim Okafor	HVAC	Day	555-2104	Active	Sample data	seed
5	SMPL-MAINT-Lynn Marsh	Welding	Night	555-2105	Active	Sample data	seed
6	SMPL-MAINT-Ed Paulson	General	Day	555-2106	On Leave	Sample data	seed
\.


--
-- Data for Name: maint_part; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maint_part (id, name, part_number, category, location, quantity, reorder_level, unit_cost, status, notes, created_by, equipment_id) FROM stdin;
1	V-Belt A78	SMPL-MAINT-PRT-001	Belts	Bin A-12	6	3	12.5	In Stock	Sample data	seed	\N
2	Ball Bearing 6205	SMPL-MAINT-PRT-002	Bearings	Bin B-05	12	6	18.75	In Stock	Sample data	seed	\N
3	Oil Filter OF-220	SMPL-MAINT-PRT-003	Filters	Bin C-03	8	4	9	In Stock	Sample data	seed	\N
4	5 HP Motor 3-Phase	SMPL-MAINT-PRT-004	Motors	Shelf D	1	2	385	Low Stock	Sample data	seed	\N
5	Fuse 20A 600V	SMPL-MAINT-PRT-005	Electrical	Bin E-01	50	20	1.25	In Stock	Sample data	seed	\N
6	Hydraulic Hose 3/4"	SMPL-MAINT-PRT-006	Hydraulics	Shelf F	3	2	48	In Stock	Sample data	seed	\N
7	M10 Hex Bolt (50pk)	SMPL-MAINT-PRT-007	Fasteners	Bin G-08	10	5	8.5	In Stock	Sample data	seed	\N
8	ISO 46 Hydraulic Oil	SMPL-MAINT-PRT-008	Lubricants	Shelf H	2	2	42	Low Stock	Sample data	seed	\N
9	Laser Focusing Lens	SMPL-MAINT-PRT-009	Other	Safe Box	0	1	620	Out of Stock	Sample data	seed	\N
10	Air Compressor Belt B56	SMPL-MAINT-PRT-010	Belts	Bin A-15	4	3	15	In Stock	Sample data	seed	\N
\.


--
-- Data for Name: maint_schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maint_schedule (id, task, equipment, frequency, assigned_to, last_done, next_due, status, notes, created_by) FROM stdin;
1	Lubricate spindle bearings	CNC Mill #1	Monthly	SMPL-MAINT-Bob Harmon	2026-05-29	2026-05-31	Scheduled	Sample data	seed
2	Check hydraulic fluid level	Hydraulic Press	Weekly	SMPL-MAINT-Carlos Vega	2026-06-19	2026-06-19	Due	Sample data	seed
3	Inspect air filters	Air Compressor	Monthly	SMPL-MAINT-Tim Okafor	2026-05-12	2026-04-27	Overdue	Sample data	seed
4	Calibrate laser optics	Laser Cutter	Quarterly	SMPL-MAINT-Bob Harmon	2026-03-28	2026-03-30	Scheduled	Sample data	seed
5	Test crane load limit switch	Overhead Crane	Semi-Annual	SMPL-MAINT-Lynn Marsh	2025-12-28	2025-12-29	Due	Sample data	seed
6	Replace conveyor belt lacing	Conveyor Belt #1	Annual	SMPL-MAINT-Bob Harmon	2025-06-26	2025-07-01	Scheduled	Sample data	seed
7	Clean paint booth exhaust filters	Paint Booth	Monthly	SMPL-MAINT-Denise Fowler	2026-06-16	2026-07-06	Scheduled	Sample data	seed
8	Inspect MIG welder gas lines	MIG Welder	Weekly	SMPL-MAINT-Carlos Vega	2026-06-22	2026-06-25	Scheduled	Sample data	seed
9	Check chiller refrigerant level	Industrial Chiller	Quarterly	SMPL-MAINT-Tim Okafor	2026-06-06	2026-08-15	Scheduled	Sample data	seed
10	Inspect injection molder clamps	Injection Molder	Monthly	SMPL-MAINT-Carlos Vega	2026-05-27	2026-05-27	Due	Sample data	seed
11	Lubricate spindle bearings	CNC Mill #1	Monthly	SMPL-MAINT-Bob Harmon	2026-06-07	2026-06-09	Scheduled	Sample data	SMPL-MAINT-
12	Check hydraulic fluid level	Hydraulic Press	Weekly	SMPL-MAINT-Carlos Vega	2026-06-28	2026-06-28	Due	Sample data	SMPL-MAINT-
13	Inspect air filters	Air Compressor	Monthly	SMPL-MAINT-Tim Okafor	2026-05-21	2026-05-06	Overdue	Sample data	SMPL-MAINT-
14	Calibrate laser optics	Laser Cutter	Quarterly	SMPL-MAINT-Bob Harmon	2026-04-06	2026-04-08	Scheduled	Sample data	SMPL-MAINT-
15	Test crane load limit switch	Overhead Crane	Semi-Annual	SMPL-MAINT-Lynn Marsh	2026-01-06	2026-01-07	Due	Sample data	SMPL-MAINT-
16	Replace conveyor belt lacing	Conveyor Belt #1	Annual	SMPL-MAINT-Bob Harmon	2025-07-05	2025-07-10	Scheduled	Sample data	SMPL-MAINT-
17	Clean paint booth exhaust filters	Paint Booth	Monthly	SMPL-MAINT-Denise Fowler	2026-06-25	2026-07-15	Scheduled	Sample data	SMPL-MAINT-
18	Inspect MIG welder gas lines	MIG Welder	Weekly	SMPL-MAINT-Carlos Vega	2026-07-01	2026-07-04	Scheduled	Sample data	SMPL-MAINT-
19	Check chiller refrigerant level	Industrial Chiller	Quarterly	SMPL-MAINT-Tim Okafor	2026-06-15	2026-08-24	Scheduled	Sample data	SMPL-MAINT-
20	Inspect injection molder clamps	Injection Molder	Monthly	SMPL-MAINT-Carlos Vega	2026-06-05	2026-06-05	Due	Sample data	SMPL-MAINT-
\.


--
-- Data for Name: maint_work_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maint_work_order (id, title, equipment, work_type, priority, assigned_to, requested_date, due_date, completed_date, status, notes, created_by) FROM stdin;
1	Replace worn bearings on CNC Mill #1	CNC Mill #1	Replacement	High	SMPL-MAINT-Bob Harmon	2026-06-23	2026-06-27		In Progress	Sample data	seed
2	Quarterly PM — Hydraulic Press	Hydraulic Press	Preventive	Medium	SMPL-MAINT-Carlos Vega	2026-06-19	2026-06-19		Assigned	Sample data	seed
3	Air compressor pressure relief check	Air Compressor	Inspection	High	SMPL-MAINT-Denise Fowler	2026-06-25	2026-06-27		Open	Sample data	seed
4	Laser cutter alignment & calibration	Laser Cutter	Calibration	Critical	SMPL-MAINT-Bob Harmon	2026-06-24	2026-06-25		In Progress	Sample data	seed
5	Industrial chiller coil cleaning	Industrial Chiller	Cleaning	Critical	SMPL-MAINT-Tim Okafor	2026-06-25	2026-06-26		Assigned	Sample data	seed
6	Conveyor belt tension adjustment	Conveyor Belt #1	Repair	Medium	SMPL-MAINT-Bob Harmon	2026-06-12	2026-06-02	2026-06-03	Completed	Sample data	seed
7	Paint booth filter replacement	Paint Booth	Replacement	Medium	SMPL-MAINT-Ed Paulson	2026-06-21	2026-06-24		On Hold	Sample data	seed
8	Annual overhead crane inspection	Overhead Crane	Inspection	High	SMPL-MAINT-Lynn Marsh	2026-05-27	2026-04-30	2026-05-01	Completed	Sample data	seed
9	MIG welder electrode tip replacement	MIG Welder	Replacement	Low	SMPL-MAINT-Carlos Vega	2026-06-24	2026-06-29		Open	Sample data	seed
10	Injection molder hydraulic fluid flush	Injection Molder	Preventive	Medium	SMPL-MAINT-Carlos Vega	2026-06-16	2026-06-11	2026-06-12	Completed	Sample data	seed
11	Replace worn bearings on CNC Mill #1	CNC Mill #1	Replacement	High	SMPL-MAINT-Bob Harmon	2026-07-02	2026-07-06		In Progress	Sample data	SMPL-MAINT-
12	Quarterly PM — Hydraulic Press	Hydraulic Press	Preventive	Medium	SMPL-MAINT-Carlos Vega	2026-06-28	2026-06-28		Assigned	Sample data	SMPL-MAINT-
13	Air compressor pressure relief check	Air Compressor	Inspection	High	SMPL-MAINT-Denise Fowler	2026-07-04	2026-07-06		Open	Sample data	SMPL-MAINT-
14	Laser cutter alignment & calibration	Laser Cutter	Calibration	Critical	SMPL-MAINT-Bob Harmon	2026-07-03	2026-07-04		In Progress	Sample data	SMPL-MAINT-
15	Industrial chiller coil cleaning	Industrial Chiller	Cleaning	Critical	SMPL-MAINT-Tim Okafor	2026-07-04	2026-07-05		Assigned	Sample data	SMPL-MAINT-
16	Conveyor belt tension adjustment	Conveyor Belt #1	Repair	Medium	SMPL-MAINT-Bob Harmon	2026-06-21	2026-06-11	2026-06-12	Completed	Sample data	SMPL-MAINT-
17	Paint booth filter replacement	Paint Booth	Replacement	Medium	SMPL-MAINT-Ed Paulson	2026-06-30	2026-07-03		On Hold	Sample data	SMPL-MAINT-
18	Annual overhead crane inspection	Overhead Crane	Inspection	High	SMPL-MAINT-Lynn Marsh	2026-06-05	2026-05-09	2026-05-10	Completed	Sample data	SMPL-MAINT-
19	MIG welder electrode tip replacement	MIG Welder	Replacement	Low	SMPL-MAINT-Carlos Vega	2026-07-03	2026-07-08		Open	Sample data	SMPL-MAINT-
20	Injection molder hydraulic fluid flush	Injection Molder	Preventive	Medium	SMPL-MAINT-Carlos Vega	2026-06-25	2026-06-20	2026-06-21	Completed	Sample data	SMPL-MAINT-
\.


--
-- Data for Name: marketing_ad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketing_ad (id, name, channel, campaign_name, budget, spend, impressions, clicks, conversions, start_date, end_date, status, owner, notes) FROM stdin;
1	SMPL-MKT-Google Search — Valve Q2	Google Ads	SMPL-MKT-Google Search — Valve Parts	5000	3820	128000	640	24	2026-05-27	2026-07-26	Active	Marco Reyes	Sample data
2	SMPL-MKT-LinkedIn Brand Q3 — Banner	LinkedIn	SMPL-MKT-Q3 LinkedIn Brand Awareness	3000	1450	92000	320	8	2026-06-11	2026-08-25	Active	Priya Nair	Sample data
3	SMPL-MKT-Spring Trade Show Display Ad	Display	SMPL-MKT-Trade Show Spring Circuit	2500	2500	54000	180	12	2026-03-28	2026-02-26	Completed	Marco Reyes	Sample data
4	SMPL-MKT-Facebook Retargeting — Launch	Facebook	SMPL-MKT-Summer Product Launch 2026	4000	2100	76000	420	18	2026-05-12	2026-06-26	Active	Priya Nair	Sample data
5	SMPL-MKT-Email Promo — Partner Co-brand	Email	SMPL-MKT-Partner Newsletter Co-marketing	1500	1500	41000	920	31	2026-04-27	2026-04-12	Completed	Priya Nair	Sample data
6	SMPL-MKT-Holiday Display Banner Set	Display	SMPL-MKT-Holiday Promo Direct Mail	3500	0	0	0	0	2026-07-26	2026-10-24	Scheduled	Marco Reyes	Sample data
\.


--
-- Data for Name: marketing_analytics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketing_analytics (id, metric, campaign, channel, target, actual, measured_date, status, notes) FROM stdin;
\.


--
-- Data for Name: marketing_budget; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketing_budget (id, item, campaign, category, amount, requested_by, request_date, status, notes) FROM stdin;
\.


--
-- Data for Name: marketing_campaign; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketing_campaign (id, name, channel, objective, owner, start_date, end_date, budget, status, notes) FROM stdin;
1	SMPL-MKT-Summer Product Launch 2026	Email	Launch	Priya Nair	2026-05-12	2026-06-26	18000	Active	Sample data
2	SMPL-MKT-Trade Show Spring Circuit	Event	Lead Gen	Marco Reyes	2026-03-28	2026-02-26	32000	Completed	Sample data
3	SMPL-MKT-Q3 LinkedIn Brand Awareness	Social	Awareness	Priya Nair	2026-06-11	2026-08-25	9500	Active	Sample data
4	SMPL-MKT-Google Search — Valve Parts	Search	Conversion	Marco Reyes	2026-05-27	2026-07-26	14000	Active	Sample data
5	SMPL-MKT-Partner Newsletter Co-marketing	Email	Lead Gen	Priya Nair	2026-04-27	2026-04-12	5500	Completed	Sample data
6	SMPL-MKT-Product Webinar Series Q2	Webinar	Retention	Marco Reyes	2026-06-06	2026-06-16	7200	Active	Sample data
7	SMPL-MKT-Holiday Promo Direct Mail	Direct Mail	Conversion	Priya Nair	2026-07-26	2026-10-24	11000	Planned	Sample data
8	SMPL-MKT-Industry Expo Q4	Event	Lead Gen	Marco Reyes	2026-08-25	2026-12-23	28000	Planned	Sample data
\.


--
-- Data for Name: marketing_content; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketing_content (id, title, content_type, channel, author, due_date, publish_date, status, notes) FROM stdin;
1	SMPL-MKT-5 Ways to Extend Valve Life	Blog	Email	Priya Nair	2026-05-27	2026-05-29	Published	Sample data
2	SMPL-MKT-Precision Parts Buyer's Guide 2026	Whitepaper	Content	Marco Reyes	2026-06-06	2026-06-11	Published	Sample data
3	SMPL-MKT-Summer Launch — Social Post Series	Social Post	Social	Priya Nair	2026-06-16	2026-06-18	Published	Sample data
4	SMPL-MKT-Webinar Slide Deck — Q2	Video	Webinar	Marco Reyes	2026-06-21	2026-06-23	Published	Sample data
5	SMPL-MKT-Customer Success Story — Apex Mfg.	Case Study	Email	Priya Nair	2026-07-01	\N	In Review	Sample data
6	SMPL-MKT-Q3 Email Newsletter Draft	Email	Email	Marco Reyes	2026-07-06	\N	Draft	Sample data
7	SMPL-MKT-Product Comparison Infographic	Infographic	Social	Priya Nair	2026-07-11	\N	Draft	Sample data
8	SMPL-MKT-Holiday Promo Landing Page	Landing Page	Display	Marco Reyes	2026-07-21	\N	Draft	Sample data
9	SMPL-MKT-Industry Expo Ad Copy	Ad Copy	Display	Priya Nair	2026-08-05	\N	Draft	Sample data
\.


--
-- Data for Name: marketing_lead; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketing_lead (id, name, company, email, source, owner, captured_date, status, notes) FROM stdin;
1	Daniel Park	Summit Fab	d.park@summit.example	Event	Priya Nair	2026-06-21	New	Sample data
2	Rachel Cho	Pacific Tools Inc.	r.cho@pactools.example	Web	Marco Reyes	2026-06-14	Contacted	Sample data
3	Omar Hassan	NW Manufacturing	o.hassan@nwmfg.example	Ad	Priya Nair	2026-06-23	New	Sample data
4	Tanya Birch	BlueRidge Systems	t.birch@blueridge.example	Referral	Marco Reyes	2026-06-06	Qualified	Sample data
5	Chen Wei	Inova Parts	c.wei@inovaparts.example	Social	Priya Nair	2026-06-18	Contacted	Sample data
6	Fatima Al-Said	Gulf Industrial	f.alsaid@gulfindu.example	Event	Marco Reyes	2026-05-12	Converted	Sample data
7	Greg Nelson	Lakeside Assembly	g.nelson@lakeside.example	Partner	Priya Nair	2026-04-27	Nurturing	Sample data
8	Sandra Lee	Coastal Precision	s.lee@coastalprec.example	Cold Outreach	Marco Reyes	2026-03-28	Lost	Sample data
9	Victor Osei	Accra Engineering	v.osei@accra-eng.example	Social	Priya Nair	2026-06-25	New	Sample data
10	Hannah Brandt	Rhine Components	h.brandt@rhinecomp.example	Referral	Marco Reyes	2026-06-19	Qualified	Sample data
\.


--
-- Data for Name: marketing_research; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.marketing_research (id, title, research_type, owner, methodology, start_date, completed_date, status, findings, created_by) FROM stdin;
1	SMPL-MKT-Q2 Customer Satisfaction Survey	Survey	Priya Nair	Online survey via email to all Q1 customers	2026-05-12	2026-06-11	Completed		seed
2	SMPL-MKT-Competitor Pricing Analysis 2026	Competitor Analysis	Marco Reyes	Benchmark pricing against top 3 competitors	2026-04-27	2026-06-06	Completed		seed
3	SMPL-MKT-New Market — Aerospace Segment	Market Trend	Priya Nair	Secondary research + interviews with aerospace buyers	2026-05-27	\N	In Progress		seed
4	SMPL-MKT-Trade Show Lead Quality A/B Test	A/B Test	Marco Reyes	Compare lead conversion from Spring vs Fall trade shows	2026-03-28	2026-04-27	Completed		seed
5	SMPL-MKT-Product Naming Focus Group	Focus Group	Priya Nair	3 focus groups, 7 participants each, recorded sessions	2026-06-16	\N	In Progress		seed
6	SMPL-MKT-Q3 Market Sizing — Southeast US	Market Trend	Marco Reyes	Industry reports + CRM deal data analysis	2026-07-11	\N	Planned		seed
\.


--
-- Data for Name: mrp_planned_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrp_planned_order (id, run_id, product_id, order_type, qty, need_date, lead_time_days, status, released_ref, start_date) FROM stdin;
\.


--
-- Data for Name: mrp_run; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mrp_run (id, run_date, horizon_days, notes) FROM stdin;
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notification (id, people_id, type, entity_type, entity_id, message, read_at, created_at) FROM stdin;
\.


--
-- Data for Name: passwd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.passwd (id, people_id, password) FROM stdin;
1	1	root
2	2	root
3	3	root
4	4	root
5	5	root
6	6	root
7	7	root
8	8	root
9	9	password
10	10	root
11	11	root
12	12	root
13	13	root
14	14	root
15	15	root
16	16	root
17	17	root
18	18	root
19	19	root
20	20	root
22	99	changeme
23	0	changeme
21	21	$2b$12$z5/8AJEi9maXjeFUEoZPnOH54QT.qqkMsAK0VzTsX3y41cTBGx8uW
25	101	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
26	102	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
27	103	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
28	104	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
29	105	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
30	106	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
31	107	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
32	108	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
33	109	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
34	110	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
35	111	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
36	112	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
37	113	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
38	114	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
39	115	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
40	116	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
41	117	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
42	118	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
43	119	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
44	120	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
45	121	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
46	122	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
47	123	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
48	124	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
49	125	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
50	126	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
51	127	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
52	128	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
53	129	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
54	130	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
55	131	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
56	132	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
57	133	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
58	134	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
59	135	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
60	136	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
61	137	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
62	138	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
63	139	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
64	140	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
65	141	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
66	142	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
67	143	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
68	144	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
69	145	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
70	146	$2b$12$PpSGwnBs8YegYithKNipgebGhAaEeZHIerOpETFv2RI0xdX4PFipi
\.


--
-- Data for Name: payroll_deduction_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payroll_deduction_type (id, name, category, is_pre_tax, is_active, created_by) FROM stdin;
1	Health Insurance	Benefits	1	1	seed
2	Dental Insurance	Benefits	1	1	seed
3	Vision Insurance	Benefits	1	1	seed
4	401k Contribution	Retirement	1	1	seed
5	Life Insurance	Benefits	0	1	seed
6	Health Insurance	Benefits	1	1	SMPL-PAY-
7	Dental Insurance	Benefits	1	1	SMPL-PAY-
8	Vision Insurance	Benefits	1	1	SMPL-PAY-
9	401k Contribution	Retirement	1	1	SMPL-PAY-
10	Life Insurance	Benefits	0	1	SMPL-PAY-
\.


--
-- Data for Name: payroll_entry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payroll_entry (id, run_id, people_id, regular_hours, overtime_hours, gross_pay, federal_tax, state_tax, social_security, medicare, net_pay, pre_tax_deductions, post_tax_deductions) FROM stdin;
1	1	101	0	0	4615.38	886.92	201.57	249.95	58.46	2609.56	583.92	25
2	1	102	0	0	3269.23	618.37	140.54	174.27	40.76	1821.83	458.46	15
3	1	109	80	0	1600	297	67.5	83.7	19.57	882.23	250	0
4	1	110	80	0	1920	367.4	83.5	103.54	24.21	1091.35	250	0
5	1	111	80	0	1560	288.2	65.5	81.22	19	856.08	250	0
6	1	115	80	0	2080	388.87	88.38	109.59	25.63	1155.13	312.4	0
7	1	116	80	0	2560	485.67	110.38	136.87	32.01	1442.67	352.4	0
8	1	117	0	0	2500	463.1	105.25	130.51	30.52	1375.62	395	0
9	1	121	0	0	3461.54	655.92	149.07	184.85	43.23	1933.39	480.08	15
10	1	123	80	0	1920	367.4	83.5	103.54	24.21	1091.35	250	0
11	1	125	0	0	2692.31	519.54	118.08	146.42	34.24	1543.26	330.77	0
12	1	129	80	0	2080	402.6	91.5	113.46	26.54	1195.9	250	0
13	2	101	0	0	4615.38	886.92	201.57	249.95	58.46	2609.56	583.92	25
14	2	102	0	0	3269.23	618.37	140.54	174.27	40.76	1821.83	458.46	15
15	2	109	80	0	1600	297	67.5	83.7	19.57	882.23	250	0
16	2	110	80	5	2100	407	92.5	114.7	26.83	1208.97	250	0
17	2	111	80	0	1560	288.2	65.5	81.22	19	856.08	250	0
18	2	115	80	3	2197	413.84	94.05	116.63	27.28	1229.29	315.91	0
19	2	116	80	0	2560	485.67	110.38	136.87	32.01	1442.67	352.4	0
20	2	117	0	0	2500	463.1	105.25	130.51	30.52	1375.62	395	0
21	2	121	0	0	3461.54	655.92	149.07	184.85	43.23	1933.39	480.08	15
22	2	123	80	0	1920	367.4	83.5	103.54	24.21	1091.35	250	0
23	2	125	0	0	2692.31	519.54	118.08	146.42	34.24	1543.26	330.77	0
24	2	129	80	0	2080	402.6	91.5	113.46	26.54	1195.9	250	0
25	3	101	0	0	4615.38	886.92	201.57	249.95	58.46	2609.56	583.92	25
26	3	102	0	0	3269.23	618.37	140.54	174.27	40.76	1821.83	458.46	15
27	3	109	80	0	1600	297	67.5	83.7	19.57	882.23	250	0
28	3	110	80	0	1920	367.4	83.5	103.54	24.21	1091.35	250	0
29	3	111	80	0	1560	288.2	65.5	81.22	19	856.08	250	0
30	3	115	80	0	2080	388.87	88.38	109.59	25.63	1155.13	312.4	0
31	3	116	80	0	2560	485.67	110.38	136.87	32.01	1442.67	352.4	0
32	3	117	0	0	2500	463.1	105.25	130.51	30.52	1375.62	395	0
33	3	121	0	0	3461.54	655.92	149.07	184.85	43.23	1933.39	480.08	15
34	3	123	80	4	2064	399.08	90.7	112.47	26.3	1185.45	250	0
35	3	125	0	0	2692.31	519.54	118.08	146.42	34.24	1543.26	330.77	0
36	3	129	80	0	2080	402.6	91.5	113.46	26.54	1195.9	250	0
37	4	101	0	0	4615.38	886.92	201.57	249.95	58.46	2609.56	583.92	25
38	4	102	0	0	3269.23	618.37	140.54	174.27	40.76	1821.83	458.46	15
39	4	109	80	0	1600	297	67.5	83.7	19.57	882.23	250	0
40	4	110	80	0	1920	367.4	83.5	103.54	24.21	1091.35	250	0
41	4	111	80	0	1560	288.2	65.5	81.22	19	856.08	250	0
42	4	115	80	0	2080	388.87	88.38	109.59	25.63	1155.13	312.4	0
43	4	116	80	0	2560	485.67	110.38	136.87	32.01	1442.67	352.4	0
44	4	117	0	0	2500	463.1	105.25	130.51	30.52	1375.62	395	0
45	4	121	0	0	3461.54	655.92	149.07	184.85	43.23	1933.39	480.08	15
46	4	123	80	0	1920	367.4	83.5	103.54	24.21	1091.35	250	0
47	4	125	0	0	2692.31	519.54	118.08	146.42	34.24	1543.26	330.77	0
48	4	129	80	0	2080	402.6	91.5	113.46	26.54	1195.9	250	0
49	5	101	0	0	4615.38	886.92	201.57	249.95	58.46	2609.56	583.92	25
50	5	102	0	0	3269.23	618.37	140.54	174.27	40.76	1821.83	458.46	15
51	5	109	80	0	1600	297	67.5	83.7	19.57	882.23	250	0
52	5	110	80	5	2100	407	92.5	114.7	26.83	1208.97	250	0
53	5	111	80	0	1560	288.2	65.5	81.22	19	856.08	250	0
54	5	115	80	3	2197	413.84	94.05	116.63	27.28	1229.29	315.91	0
55	5	116	80	0	2560	485.67	110.38	136.87	32.01	1442.67	352.4	0
56	5	117	0	0	2500	463.1	105.25	130.51	30.52	1375.62	395	0
57	5	121	0	0	3461.54	655.92	149.07	184.85	43.23	1933.39	480.08	15
58	5	123	80	0	1920	367.4	83.5	103.54	24.21	1091.35	250	0
59	5	125	0	0	2692.31	519.54	118.08	146.42	34.24	1543.26	330.77	0
60	5	129	80	0	2080	402.6	91.5	113.46	26.54	1195.9	250	0
61	6	101	0	0	4615.38	886.92	201.57	249.95	58.46	2609.56	583.92	25
62	6	102	0	0	3269.23	618.37	140.54	174.27	40.76	1821.83	458.46	15
63	6	109	80	0	1600	297	67.5	83.7	19.57	882.23	250	0
64	6	110	80	0	1920	367.4	83.5	103.54	24.21	1091.35	250	0
65	6	111	80	0	1560	288.2	65.5	81.22	19	856.08	250	0
66	6	115	80	0	2080	388.87	88.38	109.59	25.63	1155.13	312.4	0
67	6	116	80	0	2560	485.67	110.38	136.87	32.01	1442.67	352.4	0
68	6	117	0	0	2500	463.1	105.25	130.51	30.52	1375.62	395	0
69	6	121	0	0	3461.54	655.92	149.07	184.85	43.23	1933.39	480.08	15
70	6	123	80	4	2064	399.08	90.7	112.47	26.3	1185.45	250	0
71	6	125	0	0	2692.31	519.54	118.08	146.42	34.24	1543.26	330.77	0
72	6	129	80	0	2080	402.6	91.5	113.46	26.54	1195.9	250	0
\.


--
-- Data for Name: payroll_entry_deduction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payroll_entry_deduction (id, entry_id, deduction_name, is_pre_tax, amount) FROM stdin;
1	1	Health Insurance	1	250
2	1	Dental Insurance	1	45
3	1	Vision Insurance	1	12
4	1	401k Contribution	1	276.92
5	1	Life Insurance	0	25
6	2	Health Insurance	1	250
7	2	Dental Insurance	1	45
8	2	401k Contribution	1	163.46
9	2	Life Insurance	0	15
10	3	Health Insurance	1	250
11	4	Health Insurance	1	250
12	5	Health Insurance	1	250
13	6	Health Insurance	1	250
14	6	401k Contribution	1	62.4
15	7	Health Insurance	1	250
16	7	401k Contribution	1	102.4
17	8	Health Insurance	1	250
18	8	Dental Insurance	1	45
19	8	401k Contribution	1	100
20	9	Health Insurance	1	250
21	9	Dental Insurance	1	45
22	9	Vision Insurance	1	12
23	9	401k Contribution	1	173.08
24	9	Life Insurance	0	15
25	10	Health Insurance	1	250
26	11	Health Insurance	1	250
27	11	401k Contribution	1	80.77
28	12	Health Insurance	1	250
29	13	Health Insurance	1	250
30	13	Dental Insurance	1	45
31	13	Vision Insurance	1	12
32	13	401k Contribution	1	276.92
33	13	Life Insurance	0	25
34	14	Health Insurance	1	250
35	14	Dental Insurance	1	45
36	14	401k Contribution	1	163.46
37	14	Life Insurance	0	15
38	15	Health Insurance	1	250
39	16	Health Insurance	1	250
40	17	Health Insurance	1	250
41	18	Health Insurance	1	250
42	18	401k Contribution	1	65.91
43	19	Health Insurance	1	250
44	19	401k Contribution	1	102.4
45	20	Health Insurance	1	250
46	20	Dental Insurance	1	45
47	20	401k Contribution	1	100
48	21	Health Insurance	1	250
49	21	Dental Insurance	1	45
50	21	Vision Insurance	1	12
51	21	401k Contribution	1	173.08
52	21	Life Insurance	0	15
53	22	Health Insurance	1	250
54	23	Health Insurance	1	250
55	23	401k Contribution	1	80.77
56	24	Health Insurance	1	250
57	25	Health Insurance	1	250
58	25	Dental Insurance	1	45
59	25	Vision Insurance	1	12
60	25	401k Contribution	1	276.92
61	25	Life Insurance	0	25
62	26	Health Insurance	1	250
63	26	Dental Insurance	1	45
64	26	401k Contribution	1	163.46
65	26	Life Insurance	0	15
66	27	Health Insurance	1	250
67	28	Health Insurance	1	250
68	29	Health Insurance	1	250
69	30	Health Insurance	1	250
70	30	401k Contribution	1	62.4
71	31	Health Insurance	1	250
72	31	401k Contribution	1	102.4
73	32	Health Insurance	1	250
74	32	Dental Insurance	1	45
75	32	401k Contribution	1	100
76	33	Health Insurance	1	250
77	33	Dental Insurance	1	45
78	33	Vision Insurance	1	12
79	33	401k Contribution	1	173.08
80	33	Life Insurance	0	15
81	34	Health Insurance	1	250
82	35	Health Insurance	1	250
83	35	401k Contribution	1	80.77
84	36	Health Insurance	1	250
85	37	Health Insurance	1	250
86	37	Dental Insurance	1	45
87	37	Vision Insurance	1	12
88	37	401k Contribution	1	276.92
89	37	Life Insurance	0	25
90	38	Health Insurance	1	250
91	38	Dental Insurance	1	45
92	38	401k Contribution	1	163.46
93	38	Life Insurance	0	15
94	39	Health Insurance	1	250
95	40	Health Insurance	1	250
96	41	Health Insurance	1	250
97	42	Health Insurance	1	250
98	42	401k Contribution	1	62.4
99	43	Health Insurance	1	250
100	43	401k Contribution	1	102.4
101	44	Health Insurance	1	250
102	44	Dental Insurance	1	45
103	44	401k Contribution	1	100
104	45	Health Insurance	1	250
105	45	Dental Insurance	1	45
106	45	Vision Insurance	1	12
107	45	401k Contribution	1	173.08
108	45	Life Insurance	0	15
109	46	Health Insurance	1	250
110	47	Health Insurance	1	250
111	47	401k Contribution	1	80.77
112	48	Health Insurance	1	250
113	49	Health Insurance	1	250
114	49	Dental Insurance	1	45
115	49	Vision Insurance	1	12
116	49	401k Contribution	1	276.92
117	49	Life Insurance	0	25
118	50	Health Insurance	1	250
119	50	Dental Insurance	1	45
120	50	401k Contribution	1	163.46
121	50	Life Insurance	0	15
122	51	Health Insurance	1	250
123	52	Health Insurance	1	250
124	53	Health Insurance	1	250
125	54	Health Insurance	1	250
126	54	401k Contribution	1	65.91
127	55	Health Insurance	1	250
128	55	401k Contribution	1	102.4
129	56	Health Insurance	1	250
130	56	Dental Insurance	1	45
131	56	401k Contribution	1	100
132	57	Health Insurance	1	250
133	57	Dental Insurance	1	45
134	57	Vision Insurance	1	12
135	57	401k Contribution	1	173.08
136	57	Life Insurance	0	15
137	58	Health Insurance	1	250
138	59	Health Insurance	1	250
139	59	401k Contribution	1	80.77
140	60	Health Insurance	1	250
141	61	Health Insurance	1	250
142	61	Dental Insurance	1	45
143	61	Vision Insurance	1	12
144	61	401k Contribution	1	276.92
145	61	Life Insurance	0	25
146	62	Health Insurance	1	250
147	62	Dental Insurance	1	45
148	62	401k Contribution	1	163.46
149	62	Life Insurance	0	15
150	63	Health Insurance	1	250
151	64	Health Insurance	1	250
152	65	Health Insurance	1	250
153	66	Health Insurance	1	250
154	66	401k Contribution	1	62.4
155	67	Health Insurance	1	250
156	67	401k Contribution	1	102.4
157	68	Health Insurance	1	250
158	68	Dental Insurance	1	45
159	68	401k Contribution	1	100
160	69	Health Insurance	1	250
161	69	Dental Insurance	1	45
162	69	Vision Insurance	1	12
163	69	401k Contribution	1	173.08
164	69	Life Insurance	0	15
165	70	Health Insurance	1	250
166	71	Health Insurance	1	250
167	71	401k Contribution	1	80.77
168	72	Health Insurance	1	250
\.


--
-- Data for Name: payroll_run; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payroll_run (id, pay_period_start, pay_period_end, run_date, pay_frequency, federal_tax_rate, state_tax_rate, status, created_by) FROM stdin;
1	2026-05-02	2026-05-15	2026-05-15	Bi-Weekly	0.22	0.05	processed	seed
2	2026-05-16	2026-05-29	2026-05-29	Bi-Weekly	0.22	0.05	processed	seed
3	2026-05-30	2026-06-12	2026-06-12	Bi-Weekly	0.22	0.05	processed	seed
4	2026-05-10	2026-05-23	2026-05-23	Bi-Weekly	0.22	0.05	processed	SMPL-PAY-
5	2026-05-24	2026-06-06	2026-06-06	Bi-Weekly	0.22	0.05	processed	SMPL-PAY-
6	2026-06-07	2026-06-20	2026-06-20	Bi-Weekly	0.22	0.05	processed	SMPL-PAY-
\.


--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.people (id, first_name, last_name, employee_id, address, city, state, zip_code, email, emp_id, dept_id, dept_sub_id, created_by) FROM stdin;
0			0					newuser@test.com	\N	\N	\N	\N
1	John	Elder	0	123 Elder St.	Las Vegas	NV	89137	john@elder.com	\N	1	\N	\N
2	Mary	Smith	0	435 West Lookout	Chicago	IL	60610	mary@smith.com	\N	1	\N	\N
3	Tim	Tanaka	0	246 Main St.	New York	NY	12345	tim@tanaka.com	\N	1	\N	\N
4	Erin	Erinton	0	333 Top Way.	Los Angeles	CA	90210	erin@erinton.com	\N	1	\N	\N
5	Bob	Bobberly	0	876 Left St.	Memphis	TN	34321	bob@bobberly.com	\N	1	\N	\N
6	Steve	Smith	0	1234 Main St.	Miami	FL	12321	steve@smith.com	0	2	\N	\N
7	Tina	Browne	0	654 Street Ave.	Chicago	IL	60611	tina@browne.com	0	3	\N	\N
8	Mark	Lane	0	12 East St.	Nashville	TN	54345	mark@lane.com	0	8	\N	\N
9	John	Smith	0	678 North Ave.	St. Louis	MO	67821	john@smith.com	0	2	\N	\N
10	Mary	Todd	0	9 Elder Way.	Dallas	TX	88720	mary@todd.com	0	10	\N	\N
11	John	Lincoln	0	123 Elder St.	Las Vegas	NV	89137	john@lincoln.com	0	13	\N	\N
12	Mary	Bush	0	435 West Lookout	Chicago	IL	60610	mary@bush.com	0	3	\N	\N
13	Tim	Reagan	0	246 Main St.	New York	NY	12345	tim@reagan.com	0	6	\N	\N
14	Erin	Smith	0	333 Top Way.	Los Angeles	CA	90210	erin@smith.com	0	6	\N	\N
15	Bob	Field	0	876 Left St.	Memphis	TN	34321	bob@field.com	0	4	\N	\N
16	Steve	Target	0	1234 Main St.	Miami	FL	12321	steve@target.com	0	2	\N	\N
17	Tina	Walton	0	654 Street Ave.	Chicago	IL	60611	tina@walton.com	0	10	\N	\N
18	Mark	Erendale	0	12 East St.	Nashville	TN	54345	mark@erendale.com	0	4	\N	\N
19	John	Nowerton	0	678 North Ave.	St. Louis	MO	67821	john@nowerton.com	0	13	\N	\N
20	Mary	Hornblower	0	9 Elder Way.	Dallas	TX	88948	mary@hornblower.com	0	8	\N	\N
21	Eric	Steinman	0	2727 Steinman Way	Steinman	WV	27275	eric@steinman.com	0	5	\N	\N
99	Jane	Doe	0	123 Main St	Springfield	IL	62701	newuser@test.com	0	3	\N	\N
101	James	Carter	1001					james.carter@example.com	\N	2	24	\N
102	Mary	Mitchell	1002					mary.mitchell@example.com	\N	11	19	\N
103	Robert	Perez	1003					robert.perez@example.com	\N	11	20	\N
104	Patricia	Roberts	1004					patricia.roberts@example.com	\N	7	26	\N
105	John	Turner	1005					john.turner@example.com	\N	7	27	\N
106	Jennifer	Phillips	1006					jennifer.phillips@example.com	\N	7	27	\N
107	Michael	Campbell	1007					michael.campbell@example.com	\N	7	27	\N
108	Linda	Parker	1008					linda.parker@example.com	\N	9	28	\N
109	David	Evans	1009					david.evans@example.com	\N	9	29	\N
110	Elizabeth	Edwards	1010					elizabeth.edwards@example.com	\N	9	29	\N
111	William	Collins	1011					william.collins@example.com	\N	9	30	\N
112	Barbara	Stewart	1012					barbara.stewart@example.com	\N	9	30	\N
113	Richard	Sanchez	1013					richard.sanchez@example.com	\N	9	30	\N
114	Susan	Morris	1014					susan.morris@example.com	\N	9	30	\N
115	Joseph	Rogers	1015					joseph.rogers@example.com	\N	1	5	\N
116	Jessica	Reed	1016					jessica.reed@example.com	\N	5	7	\N
117	Thomas	Cook	1017					thomas.cook@example.com	\N	3	9	\N
118	Sarah	Morgan	1018					sarah.morgan@example.com	\N	12	31	\N
119	Charles	Bell	1019					charles.bell@example.com	\N	3	8	\N
120	Karen	Murphy	1020					karen.murphy@example.com	\N	3	8	\N
121	Daniel	Bailey	1021					daniel.bailey@example.com	\N	4	14	\N
122	Nancy	Rivera	1022					nancy.rivera@example.com	\N	4	14	\N
123	Matthew	Cooper	1023					matthew.cooper@example.com	\N	6	16	\N
124	Lisa	Richardson	1024					lisa.richardson@example.com	\N	6	16	\N
125	Anthony	Cox	1025					anthony.cox@example.com	\N	12	32	\N
126	Betty	Howard	1026					betty.howard@example.com	\N	12	32	\N
127	Mark	Ward	1027					mark.ward@example.com	\N	10	18	\N
128	Margaret	Torres	1028					margaret.torres@example.com	\N	8	12	\N
129	Donald	Peterson	1029					donald.peterson@example.com	\N	1	1	\N
130	Sandra	Gray	1030					sandra.gray@example.com	\N	1	2	\N
131	Steven	Ramirez	1031					steven.ramirez@example.com	\N	1	3	\N
132	Ashley	James	1032					ashley.james@example.com	\N	1	4	\N
133	Paul	Watson	1033					paul.watson@example.com	\N	3	10	\N
134	Kimberly	Brooks	1034					kimberly.brooks@example.com	\N	4	13	\N
135	Andrew	Kelly	1035					andrew.kelly@example.com	\N	14	33	\N
136	Emily	Sanders	1036					emily.sanders@example.com	\N	14	34	\N
137	Joshua	Price	1037					joshua.price@example.com	\N	14	34	\N
138	Donna	Bennett	1038					donna.bennett@example.com	\N	15	35	\N
139	Kenneth	Wood	1039					kenneth.wood@example.com	\N	15	36	\N
140	Michelle	Barnes	1040					michelle.barnes@example.com	\N	15	36	\N
141	James	Carter2	1041					james.carter2@example.com	\N	16	37	\N
142	Mary	Mitchell2	1042					mary.mitchell2@example.com	\N	16	38	\N
143	Robert	Perez2	1043					robert.perez2@example.com	\N	16	38	\N
144	Patricia	Roberts2	1044					patricia.roberts2@example.com	\N	17	39	\N
145	John	Turner2	1045					john.turner2@example.com	\N	17	40	\N
146	Jennifer	Phillips2	1046					jennifer.phillips2@example.com	\N	17	40	\N
\.


--
-- Data for Name: pers_review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pers_review (id, people_id, review_type, review_date, reviewer, rating, status, notes, created_by) FROM stdin;
\.


--
-- Data for Name: pers_training; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pers_training (id, people_id, course_name, training_type, start_date, end_date, status, notes, created_by) FROM stdin;
\.


--
-- Data for Name: po_approval; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.po_approval (id, po_id, requested_by, requested_at, status, decided_by, decided_at, notes) FROM stdin;
\.


--
-- Data for Name: po_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.po_item (id, po_id, description, product_id, qty_ordered, unit_price, qty_received, created_by) FROM stdin;
1	1	Steel Tube	8	100	3.5	0	
2	1	Paint Can	9	20	12	0	
3	2	Rim	10	30	18	0	
4	2	Tire	12	25	22	0	
5	3	Spoke	11	500	0.4	200	
6	3	Inner Tube	13	25	6.5	25	
7	4	Handlebar	6	15	14	15	
8	4	Seat	7	15	9.5	15	
9	5	Tire	12	10	22	0	
\.


--
-- Data for Name: position; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."position" (id, people_id, job_title, created_by) FROM stdin;
1	1		
2	2		
3	3		
4	4		
5	101	Company President	
6	102	Quality Assurance Manager	
7	103	Quality Assurance Lead	
8	104	Marketing Manager	
9	105	Marketing Personnel	
10	106	Marketing Personnel	
11	107	Marketing Personnel	
12	108	Production Manager	
13	109	Production Foreman	
14	110	Production Foreman	
15	111	Production Personnel	
16	112	Production Personnel	
17	113	Production Personnel	
18	114	Production Personnel	
19	115	Accounting Manager	
20	116	IT Manager	
21	117	Customer Service Lead	
22	118	Sales Manager	
23	119	Customer Service Rep	
24	120	Customer Service Rep	
25	121	Engineer	
26	122	Engineer	
27	123	Maintenance Mechanic	
28	124	Maintenance Mechanic	
29	125	Sales Personnel	
30	126	Sales Personnel	
31	127	Purchasing Personnel	
32	128	Personnel Assistant	
33	129	Accounts payable	
34	130	Accounts receivable	
35	131	Accounts payable Supervisor	
36	132	Accounts receivable Supervisor	
37	133	Customer Service Manager	
38	134	Engineer Manager	
39	135	Finance Manager	
40	136	Finance Personnel	
41	137	Finance Personnel	
42	138	Legal Manager	
43	139	Legal Personnel	
44	140	Legal Personnel	
45	141	Risk Manager	
46	142	Risk Personnel	
47	143	Risk Personnel	
48	144	Warehouse Manager	
49	145	Warehouse Personnel	
50	146	Warehouse Personnel	
\.


--
-- Data for Name: product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product (id, supplier_id, name, purchase_date, purchase_price, bin, amount, reorder_point, item_type, lead_time_days, uom) FROM stdin;
1	2	Chromium	2025-08-05	1050	3	850	0	buy	0	ea
2	\N	Mountain Bike	\N	0	SAMPLE	0	0	make	1	ea
3	\N	Road Bike	\N	0	SAMPLE	0	0	make	1	ea
4	\N	Bike Frame	\N	0	SAMPLE	0	0	make	2	ea
5	\N	Wheel Assembly	\N	0	SAMPLE	0	0	make	1	ea
6	\N	Handlebar	\N	14	SAMPLE	15	10	buy	14	ea
7	\N	Seat	\N	9.5	SAMPLE	15	10	buy	14	ea
8	\N	Steel Tube	\N	3.5	SAMPLE	100	50	buy	14	m
9	\N	Paint Can	\N	12	SAMPLE	20	10	buy	7	can
11	\N	Spoke	\N	0.4	SAMPLE	500	400	buy	10	ea
10	\N	Rim	\N	18	SAMPLE	15	20	buy	21	ea
12	\N	Tire	\N	22	SAMPLE	18	20	buy	14	ea
13	\N	Inner Tube	\N	6.5	SAMPLE	8	20	buy	10	ea
\.


--
-- Data for Name: purchase_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_order (id, po_number, supplier_id, order_date, expected_date, status, notes, created_by, received_date, supplier_acknowledged_at, supplier_ack_notes) FROM stdin;
1	SMPL-PO-1	1	2026-06-18	2026-07-02	draft	Restock frame raw material	\N	\N	\N	
2	SMPL-PO-2	1	2026-06-15	2026-06-29	sent	Wheel components — awaiting delivery	\N	\N	\N	
3	SMPL-PO-3	1	2026-06-08	2026-06-22	partial	Spokes partially received	\N	\N	\N	
4	SMPL-PO-4	1	2026-05-29	2026-06-12	received	Cockpit parts — fully received	\N	\N	\N	
5	SMPL-PO-5	1	2026-06-10	2026-06-24	cancelled	Duplicate order — cancelled	\N	\N	\N	
\.


--
-- Data for Name: purchase_requisition; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_requisition (id, req_number, requester_id, dept_id, dept_sub_id, needed_date, justification, status, created_date, po_id, created_by, purpose, notes) FROM stdin;
1	SMPL-REQ-001	\N	\N	\N	2026-07-19	New workstation components for expanding helpdesk team	draft	2026-07-05	\N	SMPL-PURCH-	\N	\N
2	SMPL-REQ-002	123	6	16	2026-07-12	Replacement bearings for main conveyor line	submitted	2026-07-02	\N	SMPL-PURCH-	\N	\N
3	SMPL-REQ-003	109	9	29	2026-07-15	Raw material restock for Q3 production schedule	dept_approved	2026-06-28	\N	SMPL-PURCH-	\N	\N
4	SMPL-REQ-004	121	4	14	2026-07-26	Prototype tooling for new lightweight frame design	dept_denied	2026-06-30	\N	SMPL-PURCH-	\N	\N
5	SMPL-REQ-005	119	3	8	2026-07-10	Ergonomic furniture for CS team expansion — 6 new hires	approved	2026-06-25	\N	SMPL-PURCH-	\N	\N
6	SMPL-REQ-006	\N	\N	\N	2026-07-08	Printer toner emergency restock — all floors below minimum	denied	2026-06-27	\N	SMPL-PURCH-	\N	\N
7	SMPL-REQ-007	123	6	16	2026-08-04	Annual safety equipment refresh per OSHA inspection findings	cancelled	2026-07-03	\N	SMPL-PURCH-	\N	\N
\.


--
-- Data for Name: qa_audit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_audit (id, title, audit_type, auditor, scheduled_date, completed_date, result, status, findings, created_by) FROM stdin;
1	ISO 9001 Surveillance Audit Q2	ISO 9001	Apex Registrar	2026-04-27	2026-04-29	Minor findings — 2 observations	Closed	Two observation-level findings on document control; no non-conformities.	seed
2	Production Process Audit — CNC	Process	Lisa Novak	2026-05-27	2026-05-29	Passed	Closed	Process adheres to work instructions; recommended updating WI-CNC-04.	seed
3	Supplier Audit — Metal Fab Co.	Supplier	Maria Santos	2026-06-12	2026-06-14	Conditional pass	Follow-up	3 minor findings; re-audit in 60 days.	seed
4	Internal Audit — Receiving	Internal	James Kim	2026-06-19	2026-06-21	Passed with comments	Complete	Process compliant; update inspection forms recommended.	seed
5	Product Audit — Shaft Collar Lot	Product	Lisa Novak	2026-06-23			In Progress		seed
6	Q3 ISO 9001 Internal Audit	ISO 9001	Maria Santos	2026-07-06			Scheduled		seed
7	Welding Process Audit	Process	James Kim	2026-07-16			Scheduled		seed
8	ISO 9001 Surveillance Audit Q2	ISO 9001	Apex Registrar	2026-05-06	2026-05-08	Minor findings — 2 observations	Closed	Two observation-level findings on document control; no non-conformities.	SMPL-QA-
9	Production Process Audit — CNC	Process	Lisa Novak	2026-06-05	2026-06-07	Passed	Closed	Process adheres to work instructions; recommended updating WI-CNC-04.	SMPL-QA-
10	Supplier Audit — Metal Fab Co.	Supplier	Maria Santos	2026-06-21	2026-06-23	Conditional pass	Follow-up	3 minor findings; re-audit in 60 days.	SMPL-QA-
11	Internal Audit — Receiving	Internal	James Kim	2026-06-28	2026-06-30	Passed with comments	Complete	Process compliant; update inspection forms recommended.	SMPL-QA-
12	Product Audit — Shaft Collar Lot	Product	Lisa Novak	2026-07-02			In Progress		SMPL-QA-
13	Q3 ISO 9001 Internal Audit	ISO 9001	Maria Santos	2026-07-15			Scheduled		SMPL-QA-
14	Welding Process Audit	Process	James Kim	2026-07-25			Scheduled		SMPL-QA-
\.


--
-- Data for Name: qa_capa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_capa (id, title, capa_type, ncr_ref, owner, due_date, completed_date, status, action_plan, created_by) FROM stdin;
1	Update incoming inspection for fastener grade	Corrective	NCR-003	Maria Santos	2026-07-10		In Progress	Revise incoming inspection checklist to verify material grade cert against PO.	seed
2	Re-train welding team on porosity prevention	Corrective	NCR-005	Lisa Novak	2026-07-17		Open	Schedule hands-on training session; update weld procedure WP-07.	seed
3	Implement pre-shipment paint adhesion test	Preventive	NCR-004	James Kim	2026-07-03	2026-06-23	Closed	Add adhesion pull test to pre-ship QC checklist and document results.	seed
4	Calibration frequency review for all gauges	Preventive	NCR-007	Maria Santos	2026-07-26		In Progress	Audit all gauges; reduce calibration interval from 12 to 6 months.	seed
5	Supplier audit for Bolt Vendor — Grade Compliance	Corrective	NCR-003	Lisa Novak	2026-08-10		Open	Schedule on-site audit; require updated material certs with every shipment.	seed
6	Review lubrication oil receiving procedure	Corrective	NCR-008	James Kim	2026-07-01		Open	Add batch sampling to receiving; partner with lab for contamination testing.	seed
7	Update incoming inspection for fastener grade	Corrective	NCR-003	Maria Santos	2026-07-19		In Progress	Revise incoming inspection checklist to verify material grade cert against PO.	SMPL-QA-
8	Re-train welding team on porosity prevention	Corrective	NCR-005	Lisa Novak	2026-07-26		Open	Schedule hands-on training session; update weld procedure WP-07.	SMPL-QA-
9	Implement pre-shipment paint adhesion test	Preventive	NCR-004	James Kim	2026-07-12	2026-07-02	Closed	Add adhesion pull test to pre-ship QC checklist and document results.	SMPL-QA-
10	Calibration frequency review for all gauges	Preventive	NCR-007	Maria Santos	2026-08-04		In Progress	Audit all gauges; reduce calibration interval from 12 to 6 months.	SMPL-QA-
11	Supplier audit for Bolt Vendor — Grade Compliance	Corrective	NCR-003	Lisa Novak	2026-08-19		Open	Schedule on-site audit; require updated material certs with every shipment.	SMPL-QA-
12	Review lubrication oil receiving procedure	Corrective	NCR-008	James Kim	2026-07-10		Open	Add batch sampling to receiving; partner with lab for contamination testing.	SMPL-QA-
\.


--
-- Data for Name: qa_defect; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_defect (id, insp_id, defect_type, severity, description, resolved, created_by) FROM stdin;
1	2	Surface Finish	major	Ra > 3.2 µm on inner bore — exceeds drawing tolerance	1	seed
2	2	Dimensional	minor	OD 0.003" over nominal; within functional tolerance	1	seed
3	4	Documentation	minor	Missing heat number on material cert	0	seed
\.


--
-- Data for Name: qa_inspection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_inspection (id, insp_number, product_id, wo_id, insp_date, inspector, result, notes, created_by) FROM stdin;
1	SMPL-QA-INS-001	\N	\N	2026-06-16	Lisa Novak	passed	All dimensions within spec	seed
2	SMPL-QA-INS-002	\N	\N	2026-06-18	James Kim	failed	Two surface finish failures; see defects	seed
3	SMPL-QA-INS-003	\N	\N	2026-06-21	Maria Santos	passed	Batch 2026-B lot acceptance inspection	seed
4	SMPL-QA-INS-004	\N	\N	2026-06-23	Lisa Novak	on_hold	Awaiting material certification docs	seed
5	SMPL-QA-INS-005	\N	\N	2026-06-25	James Kim	pending	In-process inspection — CNC run #48	seed
6	SMPL-QA-INS-006	\N	\N	2026-06-26	Maria Santos	pending	Final inspection — Valve Assembly	seed
\.


--
-- Data for Name: qa_ncr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_ncr (id, title, source, severity, product, detected_date, disposition, owner, closed_date, status, notes, created_by) FROM stdin;
1	Surface finish below spec on Frame Assembly	In-Process	Major	Frame Assembly	2026-06-21	Rework	Maria Santos		Under Review	Sample data	seed
2	Dimensional deviation — Shaft Collar OD	Final	Minor	Shaft Collar	2026-06-14	Use As-Is	James Kim		Dispositioned	Sample data	seed
3	Supplier delivered wrong grade fasteners	Incoming	Critical	M10 Hex Bolt	2026-06-24	Return	Maria Santos		Open	Sample data	seed
4	Customer returned batch with paint defects	Customer	Major	Painted Housing	2026-06-06	Scrap	James Kim	2026-06-13	Closed	Sample data	seed
5	Weld porosity detected on bracket	In-Process	Minor	Support Bracket	2026-06-19	Rework	Lisa Novak		Under Review	Sample data	seed
6	Missing certification docs on valve lot	Incoming	Minor	Safety Valve	2026-06-23	Pending	Lisa Novak		Open	Sample data	seed
7	Gauge reading out of calibration tolerance	Audit	Major	Gauge Assembly	2026-06-11	Rework	Maria Santos	2026-06-18	Closed	Sample data	seed
8	Contamination found in lubrication oil batch	In-Process	Critical	Hydraulic Oil	2026-06-25	Scrap	James Kim		Open	Sample data	seed
9	Surface finish below spec on Frame Assembly	In-Process	Major	Frame Assembly	2026-06-30	Rework	Maria Santos		Under Review	Sample data	SMPL-QA-
10	Dimensional deviation — Shaft Collar OD	Final	Minor	Shaft Collar	2026-06-23	Use As-Is	James Kim		Dispositioned	Sample data	SMPL-QA-
11	Supplier delivered wrong grade fasteners	Incoming	Critical	M10 Hex Bolt	2026-07-03	Return	Maria Santos		Open	Sample data	SMPL-QA-
12	Customer returned batch with paint defects	Customer	Major	Painted Housing	2026-06-15	Scrap	James Kim	2026-06-22	Closed	Sample data	SMPL-QA-
13	Weld porosity detected on bracket	In-Process	Minor	Support Bracket	2026-06-28	Rework	Lisa Novak		Under Review	Sample data	SMPL-QA-
14	Missing certification docs on valve lot	Incoming	Minor	Safety Valve	2026-07-02	Pending	Lisa Novak		Open	Sample data	SMPL-QA-
15	Gauge reading out of calibration tolerance	Audit	Major	Gauge Assembly	2026-06-20	Rework	Maria Santos	2026-06-27	Closed	Sample data	SMPL-QA-
16	Contamination found in lubrication oil batch	In-Process	Critical	Hydraulic Oil	2026-07-04	Scrap	James Kim		Open	Sample data	SMPL-QA-
\.


--
-- Data for Name: qa_spec; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_spec (id, product_id, spec_name, min_value, max_value, unit, notes) FROM stdin;
\.


--
-- Data for Name: qa_supplier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.qa_supplier (id, supplier, material, rating, ppm, last_audit, status, notes, created_by) FROM stdin;
1	Metal Fab Co.	Steel Sheet 1018	B	850	2026-06-12	Conditional	Sample data	seed
2	FastPro Supply	M10 Hex Bolt Grade 8	C	3200	2026-06-21	Probation	Sample data	seed
3	Allied Polymers	ABS Resin	A	120	2026-03-28	Approved	Sample data	seed
4	Acme Electronics	PCB Assemblies	A	45	2025-12-28	Approved	Sample data	seed
5	PaintTech Solutions	Epoxy Primer	B	650	2026-05-12	Approved	Sample data	seed
6	Valley Hydraulics	Hydraulic Hose	A	200	2026-04-27	Approved	Sample data	seed
7	New Era Bearings	Ball Bearing 6205	B	500	2026-02-26	Approved	Sample data	seed
8	Generic Import Co.	Misc Hardware	D	8500	2026-05-27	Disqualified	Sample data	seed
9	Metal Fab Co.	Steel Sheet 1018	B	850	2026-06-21	Conditional	Sample data	SMPL-QA-
10	FastPro Supply	M10 Hex Bolt Grade 8	C	3200	2026-06-30	Probation	Sample data	SMPL-QA-
11	Allied Polymers	ABS Resin	A	120	2026-04-06	Approved	Sample data	SMPL-QA-
12	Acme Electronics	PCB Assemblies	A	45	2026-01-06	Approved	Sample data	SMPL-QA-
13	PaintTech Solutions	Epoxy Primer	B	650	2026-05-21	Approved	Sample data	SMPL-QA-
14	Valley Hydraulics	Hydraulic Hose	A	200	2026-05-06	Approved	Sample data	SMPL-QA-
15	New Era Bearings	Ball Bearing 6205	B	500	2026-03-07	Approved	Sample data	SMPL-QA-
16	Generic Import Co.	Misc Hardware	D	8500	2026-06-05	Disqualified	Sample data	SMPL-QA-
\.


--
-- Data for Name: receiving; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.receiving (id, rcv_number, po_id, rcv_date, supplier, carrier, tracking_number, status, notes, created_by) FROM stdin;
1	SMPL-RCV-001	\N	2026-06-07	Steel Works Inc.	UPS	1Z999AA10123456784	pending	Awaiting dock assignment	SMPL-RCV-
2	SMPL-RCV-002	\N	2026-06-10	Metro Rubber Products	FedEx	770199000456123789	pending	Expected delivery this week	SMPL-RCV-
3	SMPL-RCV-003	\N	2026-06-15	Apex Fasteners LLC	UPS	1Z999AA10987654321	partial	Back-ordered items pending second shipment	SMPL-RCV-
4	SMPL-RCV-004	\N	2026-06-20	Allied Bearings Corp.	DHL	1234567891234567	partial	Partial shipment; remainder ships next week	SMPL-RCV-
5	SMPL-RCV-005	\N	2026-06-23	Delta Components Co.	FedEx	770199001122334455	received	All items verified and put away	SMPL-RCV-
6	SMPL-RCV-006	\N	2026-06-27	Summit Fabricators	UPS	1Z999AA10246813579	received	Inspected and signed off by receiving manager	SMPL-RCV-
7	SMPL-RCV-007	\N	2026-07-01	Pacific Rim Parts	USPS	9400111899223401000678	received	No discrepancies noted	SMPL-RCV-
8	SMPL-RCV-008	\N	2026-07-03	National Coating Supply	FedEx	770199009988776655	rejected	Wrong paint color; entire shipment returned to supplier	SMPL-RCV-
\.


--
-- Data for Name: receiving_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.receiving_item (id, receiving_id, description, product_id, qty_ordered, qty_received, created_by) FROM stdin;
1	1	1.5" OD Steel Tubing, 6061 Grade, 20 ft lengths	\N	50	0	
2	1	3/8" Hex Head Cap Screws, Grade 8, zinc-plated (box/100)	\N	20	0	
3	1	Sheet Metal, 11-gauge, 4x8 ft panels	\N	30	0	
4	2	Natural Rubber Gaskets, 3" ID x 4" OD	\N	200	0	
5	2	EPDM O-Ring Seals, AS568-210 (bag/50)	\N	500	0	
6	2	Neoprene Strip, 1/4" thick x 2" wide, 10 ft rolls	\N	40	0	
7	3	M10 x 1.5mm Hex Bolts, Grade 10.9, 50mm (box/50)	\N	30	30	
8	3	1/4" Drive Socket Set, SAE/Metric, 40-piece	\N	5	3	
9	3	Lock Washers, #10, stainless steel (box/100)	\N	25	25	
10	3	5/16" Nylon Insert Lock Nuts (box/100)	\N	40	20	
11	4	Deep Groove Ball Bearings, 6204-2RS, 20mm bore	\N	60	40	
12	4	Needle Roller Bearings, HK2020, 20x26x20mm	\N	30	30	
13	4	Thrust Washers, 22mm ID, hardened steel	\N	100	50	
14	5	Cold-Drawn Steel Rod, 1" diameter, 12 ft	\N	24	24	
15	5	Flat Washer, SAE, 5/16" (box/100)	\N	15	15	
16	5	3/4" NPT Pipe Nipples, Schedule 40, 6" length	\N	36	36	
17	5	Steel Angle Iron, 2x2x1/4", 10 ft	\N	20	20	
18	6	Carbon Steel Weld Fittings, 1/2" 90-deg Elbow	\N	80	80	
19	6	Mild Steel Plate, 1/4" thick, 24x48"	\N	12	12	
20	6	Structural Steel Channel, 3x4.1, 10 ft	\N	16	16	
21	7	Industrial Roller Chain, ANSI #60, 10 ft section	\N	8	8	
22	7	Compression Springs, 0.5" OD x 2" free length (pack/10)	\N	20	20	
23	7	Rubber Anti-Vibration Mounts, M8 stud (pack/4)	\N	25	25	
24	7	Silicone Sealant, High-Temp 600F, 10.1 oz cartridge	\N	36	36	
25	8	Acrylic Enamel Paint, Machinery Gray, 1-gallon	\N	24	0	
26	8	Two-Part Epoxy Primer, 1-quart kit	\N	12	0	
27	8	Aerosol Touch-Up Paint, Safety Yellow, 12oz (case/12)	\N	6	0	
\.


--
-- Data for Name: requisition_approval; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.requisition_approval (id, req_id, level, approver_id, decision, comment, decided_date) FROM stdin;
1	3	dept	108	approved	Budget confirmed; forward to Purchasing for supplier selection.	2026-07-04
2	4	dept	134	denied	Prototype budget exhausted for Q2; resubmit in Q4.	2026-07-04
3	5	dept	133	approved	Headcount confirmed; furniture needed before new hires start.	2026-07-04
4	5	purchasing	\N	approved	Sourced from Global Office Solutions; PO to follow.	2026-07-04
5	6	dept	116	approved	Routine consumable; approved to proceed.	2026-07-04
6	6	purchasing	\N	denied	Consolidate with Q2 office supply blanket order; resubmit next cycle.	2026-07-04
\.


--
-- Data for Name: requisition_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.requisition_item (id, req_id, description, product_id, qty, est_unit_price) FROM stdin;
1	1	16-port managed network switch	\N	2	450
2	1	USB-C docking stations	\N	5	89.99
3	2	6205 deep-groove ball bearings (box of 10)	\N	20	4.75
4	2	SAE 30 machine oil, 5-gallon drum	\N	4	28.5
5	3	Steel tube 1-inch OD, 12-ft lengths	\N	200	3.5
6	3	Paint cans — gloss blue, 1-quart	\N	50	12
7	4	CNC carbide cutting insert set (10-pack)	\N	3	185
8	4	Precision calibration fixture	\N	1	620
9	5	Ergonomic office chair, mesh back	\N	6	219.99
10	5	Adjustable dual-monitor arm	\N	6	49.99
11	6	HP LaserJet toner cartridge — black	\N	12	38.5
12	6	HP LaserJet toner cartridge — color	\N	6	54
13	7	Safety harness, ANSI-rated full-body	\N	10	89
14	7	Winter hard-hat liner, universal fit	\N	20	12.5
15	7	High-vis safety vest, XL	\N	15	8.75
\.


--
-- Data for Name: rfq; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rfq (id, rfq_number, status, notes, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: rfq_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rfq_item (id, rfq_id, description, product_id, qty, target_price, awarded_vendor_id, po_id) FROM stdin;
\.


--
-- Data for Name: rfq_quote_line; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rfq_quote_line (id, rfq_item_id, vendor_id, quoted_price, lead_time_days) FROM stdin;
\.


--
-- Data for Name: rfq_vendor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rfq_vendor (id, rfq_id, supplier_id) FROM stdin;
\.


--
-- Data for Name: risk_assessment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.risk_assessment (id, title, category, likelihood, impact, risk_level, owner, assessed_date, status, notes) FROM stdin;
\.


--
-- Data for Name: risk_audit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.risk_audit (id, audit, framework, auditor, scheduled_date, completed_date, finding, status, notes) FROM stdin;
\.


--
-- Data for Name: risk_continuity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.risk_continuity (id, plan, scope, criticality, owner, last_tested, next_test, status, notes) FROM stdin;
\.


--
-- Data for Name: risk_insurance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.risk_insurance (id, policy, insurer, policy_type, coverage, premium, start_date, end_date, status, notes) FROM stdin;
\.


--
-- Data for Name: risk_kri; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.risk_kri (id, indicator, category, threshold, current_value, owner, measured_date, status, notes) FROM stdin;
\.


--
-- Data for Name: risk_register; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.risk_register (id, risk, category, severity, response, owner, target_date, status, mitigation) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, role_name, description) FROM stdin;
49	President	Full access — company president
50	Vice President	Full access — company vice president
51	Department Manager	Full access to own department including management screens
52	Supervisor	Access to own department operational screens
53	Auditor	Read-only browse access across all departments — cannot launch apps
54	HR / Personnel	Full access to Personnel department
\.


--
-- Data for Name: routing; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.routing (id, product_id, operation_seq, operation_name, workcenter_id, std_hours, notes, created_by) FROM stdin;
1	4	10	Cut Tube	1	0.5	\N	SMPL-OPS-
2	4	20	Weld Frame	1	1	\N	SMPL-OPS-
3	4	30	Paint Frame	2	0.75	\N	SMPL-OPS-
4	5	10	Build Wheel	3	0.4	\N	SMPL-OPS-
5	5	20	True & Inspect	5	0.2	\N	SMPL-OPS-
6	2	10	Final Assembly	4	1.5	\N	SMPL-OPS-
7	2	20	QA Inspection	5	0.3	\N	SMPL-OPS-
8	3	10	Final Assembly	4	1.4	\N	SMPL-OPS-
9	3	20	QA Inspection	5	0.3	\N	SMPL-OPS-
\.


--
-- Data for Name: sales_coaching_note; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_coaching_note (id, rep, subject, note, status, coach, created_by, created_date) FROM stdin;
\.


--
-- Data for Name: sales_commission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_commission (id, rep, period, sales_amount, rate, commission, status, notes, created_by) FROM stdin;
1	Karen Walsh	Q1-2026	192400	0.07	13468	Paid	Sample data	seed
2	Tom Deluca	Q1-2026	138200	0.05	6910	Paid	Sample data	seed
3	Jenna Park	Q1-2026	171600	0.05	8580	Paid	Sample data	seed
4	Ryan Torres	Q1-2026	125800	0.05	6290	Paid	Sample data	seed
5	Karen Walsh	Q2-2026	148000	0.07	10360	Approved	Sample data	seed
6	Tom Deluca	Q2-2026	162300	0.05	8115	Approved	Sample data	seed
7	Jenna Park	Q2-2026	180100	0.05	9005	Approved	Sample data	seed
8	Ryan Torres	Q2-2026	141500	0.05	7075	Pending	Sample data	seed
9	Karen Walsh	Q1-2026	192400	0.07	13468	Paid	Sample data	SMPL-SALES-
10	Tom Deluca	Q1-2026	138200	0.05	6910	Paid	Sample data	SMPL-SALES-
11	Jenna Park	Q1-2026	171600	0.05	8580	Paid	Sample data	SMPL-SALES-
12	Ryan Torres	Q1-2026	125800	0.05	6290	Paid	Sample data	SMPL-SALES-
13	Karen Walsh	Q2-2026	148000	0.07	10360	Approved	Sample data	SMPL-SALES-
14	Tom Deluca	Q2-2026	162300	0.05	8115	Approved	Sample data	SMPL-SALES-
15	Jenna Park	Q2-2026	180100	0.05	9005	Approved	Sample data	SMPL-SALES-
16	Ryan Torres	Q2-2026	141500	0.05	7075	Pending	Sample data	SMPL-SALES-
\.


--
-- Data for Name: sales_commission_plan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_commission_plan (id, name, plan_type, rate, description, active, created_by, created_date) FROM stdin;
1	Standard Rep Plan	Flat Rate	0.05	5% flat commission on all closed sales	t	seed	2026-06-26
2	Senior Rep Plan	Flat Rate	0.07	7% flat commission — for reps exceeding 150k/quarter	t	seed	2026-06-26
3	Tiered Quota Plan	Tiered	0.06	6% base; 8% above 125% quota attainment	t	seed	2026-06-26
4	Quota-Based Bonus	Quota-Based	0.04	4% + bonus on reaching 100%+ of quarterly quota	t	seed	2026-06-26
\.


--
-- Data for Name: sales_contract; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_contract (id, customer, title, value, start_date, end_date, renewal_date, status, owner, notes, created_by, created_date) FROM stdin;
1	Apex Manufacturing Inc.	Annual Supply Agreement — Valve Assemblies	96000	2025-06-26	2025-06-26	\N	Active	Karen Walsh	Sample data	seed	2026-06-26
2	Castillo Industries	Preferred Vendor Agreement	60000	2025-12-28	2026-07-01	\N	Active	Karen Walsh	Sample data	seed	2026-06-26
3	Delta Components Co.	One-Time Supply Contract Q4	16800	2026-03-28	2026-02-26	\N	Expired	Tom Deluca	Sample data	seed	2026-06-26
4	Greenfield Assembly	Blanket Order Agreement — Q3/Q4	44600	2026-04-27	2026-08-25	\N	Active	Karen Walsh	Sample data	seed	2026-06-26
5	BlueStar Engineering	Partnership Supply Contract	236000	2026-05-27	2027-04-27	\N	Active	Karen Walsh	Sample data	seed	2026-06-26
6	Falcon Precision Parts	Emergency Supply Agreement	11800	2026-02-26	2025-11-28	\N	Expired	Tom Deluca	Sample data	seed	2026-06-26
7	Apex Manufacturing Inc.	Annual Supply Agreement — Valve Assemblies	96000	2025-07-05	2025-07-05	\N	Active	Karen Walsh	Sample data	SMPL-SALES-	2026-07-05
8	Castillo Industries	Preferred Vendor Agreement	60000	2026-01-06	2026-07-10	\N	Active	Karen Walsh	Sample data	SMPL-SALES-	2026-07-05
9	Delta Components Co.	One-Time Supply Contract Q4	16800	2026-04-06	2026-03-07	\N	Expired	Tom Deluca	Sample data	SMPL-SALES-	2026-07-05
10	Greenfield Assembly	Blanket Order Agreement — Q3/Q4	44600	2026-05-06	2026-09-03	\N	Active	Karen Walsh	Sample data	SMPL-SALES-	2026-07-05
11	BlueStar Engineering	Partnership Supply Contract	236000	2026-06-05	2027-05-06	\N	Active	Karen Walsh	Sample data	SMPL-SALES-	2026-07-05
12	Falcon Precision Parts	Emergency Supply Agreement	11800	2026-03-07	2025-12-07	\N	Expired	Tom Deluca	Sample data	SMPL-SALES-	2026-07-05
\.


--
-- Data for Name: sales_customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_customer (id, name, contact, email, phone, segment, region, owner, status, notes) FROM stdin;
\.


--
-- Data for Name: sales_forecast; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_forecast (id, rep, period, fiscal_year, product_line, expected_value, probability, weighted_value, status, notes, created_by, created_date) FROM stdin;
1	Karen Walsh	Q3	2026	Valve Assemblies	210000	85	178500	Submitted	Sample data	seed	2026-06-26
2	Karen Walsh	Q3	2026	Retrofit Kits	78000	70	54600	Submitted	Sample data	seed	2026-06-26
3	Tom Deluca	Q3	2026	Shaft Collars	95000	60	57000	Draft	Sample data	seed	2026-06-26
4	Jenna Park	Q3	2026	Bearing Products	145000	80	116000	Approved	Sample data	seed	2026-06-26
5	Ryan Torres	Q3	2026	Custom Fixtures	62000	55	34100	Draft	Sample data	seed	2026-06-26
6	Karen Walsh	Q4	2026	Valve Assemblies	225000	75	168750	Draft	Sample data	seed	2026-06-26
7	Jenna Park	Annual	2026	All Product Lines	680000	72	489600	Approved	Sample data	seed	2026-06-26
8	Karen Walsh	Q3	2026	Valve Assemblies	210000	85	178500	Submitted	Sample data	SMPL-SALES-	2026-07-05
9	Karen Walsh	Q3	2026	Retrofit Kits	78000	70	54600	Submitted	Sample data	SMPL-SALES-	2026-07-05
10	Tom Deluca	Q3	2026	Shaft Collars	95000	60	57000	Draft	Sample data	SMPL-SALES-	2026-07-05
11	Jenna Park	Q3	2026	Bearing Products	145000	80	116000	Approved	Sample data	SMPL-SALES-	2026-07-05
12	Ryan Torres	Q3	2026	Custom Fixtures	62000	55	34100	Draft	Sample data	SMPL-SALES-	2026-07-05
13	Karen Walsh	Q4	2026	Valve Assemblies	225000	75	168750	Draft	Sample data	SMPL-SALES-	2026-07-05
14	Jenna Park	Annual	2026	All Product Lines	680000	72	489600	Approved	Sample data	SMPL-SALES-	2026-07-05
\.


--
-- Data for Name: sales_lead; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_lead (id, company, contact, source, status, priority, estimated_value, owner, notes, created_by, created_date) FROM stdin;
1	Summit Fabricators	Dan Cho	Trade Show	Qualified	High	55000	Karen Walsh	Sample data	seed	2026-06-26
2	Pacific Rim Parts	Aida Santos	Referral	Contacted	Medium	28000	Tom Deluca	Sample data	seed	2026-06-26
3	Northwest Tooling	Greg Burns	Cold Call	New	Low	12000	Tom Deluca	Sample data	seed	2026-06-26
4	Inova Systems	Chloe Kim	Website	Proposal	High	94000	Karen Walsh	Sample data	seed	2026-06-26
5	Precision Mold Inc.	Frank Obi	Email Campaign	Contacted	Medium	31000	Jenna Park	Sample data	seed	2026-06-26
6	Highline Assembly	Tara Mendez	Partner	Qualified	High	72000	Karen Walsh	Sample data	seed	2026-06-26
7	Central Machine Co.	Brian Lau	Cold Call	New	Low	8500	Ryan Torres	Sample data	seed	2026-06-26
8	BlueStar Engineering	Nina Sharma	Referral	Won	High	118000	Karen Walsh	Sample data	seed	2026-06-26
9	Allied Components	Paul Estes	Trade Show	Lost	Medium	45000	Tom Deluca	Sample data	seed	2026-06-26
10	Redstone Industries	Laura Chen	Website	Nurturing	Medium	37500	Ryan Torres	Sample data	seed	2026-06-26
11	Summit Fabricators	Dan Cho	Trade Show	Qualified	High	55000	Karen Walsh	Sample data	SMPL-SALES-	2026-07-05
12	Pacific Rim Parts	Aida Santos	Referral	Contacted	Medium	28000	Tom Deluca	Sample data	SMPL-SALES-	2026-07-05
13	Northwest Tooling	Greg Burns	Cold Call	New	Low	12000	Tom Deluca	Sample data	SMPL-SALES-	2026-07-05
14	Inova Systems	Chloe Kim	Website	Proposal	High	94000	Karen Walsh	Sample data	SMPL-SALES-	2026-07-05
15	Precision Mold Inc.	Frank Obi	Email Campaign	Contacted	Medium	31000	Jenna Park	Sample data	SMPL-SALES-	2026-07-05
16	Highline Assembly	Tara Mendez	Partner	Qualified	High	72000	Karen Walsh	Sample data	SMPL-SALES-	2026-07-05
17	Central Machine Co.	Brian Lau	Cold Call	New	Low	8500	Ryan Torres	Sample data	SMPL-SALES-	2026-07-05
18	BlueStar Engineering	Nina Sharma	Referral	Won	High	118000	Karen Walsh	Sample data	SMPL-SALES-	2026-07-05
19	Allied Components	Paul Estes	Trade Show	Lost	Medium	45000	Tom Deluca	Sample data	SMPL-SALES-	2026-07-05
20	Redstone Industries	Laura Chen	Website	Nurturing	Medium	37500	Ryan Torres	Sample data	SMPL-SALES-	2026-07-05
\.


--
-- Data for Name: sales_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_order (id, so_number, customer_id, order_date, ship_date, status, notes, created_by) FROM stdin;
1	SMPL-SO-1	\N	2026-06-18	2026-07-09	confirmed	sample	
2	SMPL-SO-2	\N	2026-06-18	2026-07-09	confirmed	sample	
3	SMPL-SO-3	\N	2026-06-18	2026-07-09	draft	sample	
\.


--
-- Data for Name: sales_perf_review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_perf_review (id, rep, review_date, period, rating, strengths, improvements, goals, status, reviewer, created_by, created_date) FROM stdin;
\.


--
-- Data for Name: sales_quote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_quote (id, customer, description, amount, owner, quote_date, valid_until, status, notes, created_by) FROM stdin;
1	Apex Manufacturing Inc.	Annual valve assembly supply — 500 units	48500	Karen Walsh	2026-06-16	2026-07-16	Sent	Sample data	seed
2	Bridgewater Tools LLC	Custom fixture set for new product line	12750	Tom Deluca	2026-06-21	2026-07-11	Draft	Sample data	seed
3	Castillo Industries	Q3 bearing order — standard + heavy-duty mix	31200	Karen Walsh	2026-06-06	2026-06-16	Won	Sample data	seed
4	Delta Components Co.	Replacement shaft collar batch — 200 pcs	8400	Tom Deluca	2026-05-12	2026-04-27	Expired	Sample data	seed
5	Evergreen Systems	Retrofit kit supply — 12 machine installations	67000	Karen Walsh	2026-06-24	2026-08-08	Draft	Sample data	seed
6	Falcon Precision Parts	Emergency PO — hydraulic fittings	5900	Tom Deluca	2026-05-27	2026-05-07	Lost	Sample data	seed
7	Greenfield Assembly	Recurring Q4 parts kit — blanket order	22300	Karen Walsh	2026-06-19	2026-08-18	Sent	Sample data	seed
8	Harbor Engineering	New customer trial order — 50 units	4100	Tom Deluca	2026-06-23	2026-07-23	Draft	Sample data	seed
9	Apex Manufacturing Inc.	Annual valve assembly supply — 500 units	48500	Karen Walsh	2026-06-25	2026-07-25	Sent	Sample data	SMPL-SALES-
10	Bridgewater Tools LLC	Custom fixture set for new product line	12750	Tom Deluca	2026-06-30	2026-07-20	Draft	Sample data	SMPL-SALES-
11	Castillo Industries	Q3 bearing order — standard + heavy-duty mix	31200	Karen Walsh	2026-06-15	2026-06-25	Won	Sample data	SMPL-SALES-
12	Delta Components Co.	Replacement shaft collar batch — 200 pcs	8400	Tom Deluca	2026-05-21	2026-05-06	Expired	Sample data	SMPL-SALES-
13	Evergreen Systems	Retrofit kit supply — 12 machine installations	67000	Karen Walsh	2026-07-03	2026-08-17	Draft	Sample data	SMPL-SALES-
14	Falcon Precision Parts	Emergency PO — hydraulic fittings	5900	Tom Deluca	2026-06-05	2026-05-16	Lost	Sample data	SMPL-SALES-
15	Greenfield Assembly	Recurring Q4 parts kit — blanket order	22300	Karen Walsh	2026-06-28	2026-08-27	Sent	Sample data	SMPL-SALES-
16	Harbor Engineering	New customer trial order — 50 units	4100	Tom Deluca	2026-07-02	2026-08-01	Draft	Sample data	SMPL-SALES-
\.


--
-- Data for Name: sales_target; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_target (id, rep, period, target, actual, region, status, notes, created_by) FROM stdin;
1	Karen Walsh	Q1-2026	180000	192400	Northeast	Achieved	Sample data	seed
2	Tom Deluca	Q1-2026	150000	138200	Southeast	Behind	Sample data	seed
3	Jenna Park	Q1-2026	165000	171600	Midwest	Achieved	Sample data	seed
4	Ryan Torres	Q1-2026	130000	125800	West	Behind	Sample data	seed
5	Karen Walsh	Q2-2026	195000	148000	Northeast	Behind	Sample data	seed
6	Tom Deluca	Q2-2026	160000	162300	Southeast	On Track	Sample data	seed
7	Jenna Park	Q2-2026	175000	180100	Midwest	Achieved	Sample data	seed
8	Ryan Torres	Q2-2026	140000	141500	West	On Track	Sample data	seed
9	Karen Walsh	Q1-2026	180000	192400	Northeast	Achieved	Sample data	SMPL-SALES-
10	Tom Deluca	Q1-2026	150000	138200	Southeast	Behind	Sample data	SMPL-SALES-
11	Jenna Park	Q1-2026	165000	171600	Midwest	Achieved	Sample data	SMPL-SALES-
12	Ryan Torres	Q1-2026	130000	125800	West	Behind	Sample data	SMPL-SALES-
13	Karen Walsh	Q2-2026	195000	148000	Northeast	Behind	Sample data	SMPL-SALES-
14	Tom Deluca	Q2-2026	160000	162300	Southeast	On Track	Sample data	SMPL-SALES-
15	Jenna Park	Q2-2026	175000	180100	Midwest	Achieved	Sample data	SMPL-SALES-
16	Ryan Torres	Q2-2026	140000	141500	West	On Track	Sample data	SMPL-SALES-
\.


--
-- Data for Name: sales_territory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_territory (id, name, region, assigned_rep, status, notes, created_by, created_date) FROM stdin;
1	New England	Northeast	Karen Walsh	Active	Sample data	seed	2026-06-26
2	Mid-Atlantic	Northeast	Jenna Park	Active	Sample data	seed	2026-06-26
3	Southeast	Southeast	Tom Deluca	Active	Sample data	seed	2026-06-26
4	Gulf Coast	Southeast		Under Review	Sample data	seed	2026-06-26
5	Great Lakes	Midwest	Jenna Park	Active	Sample data	seed	2026-06-26
6	Plains	Midwest		Inactive	Sample data	seed	2026-06-26
7	Pacific Coast	West	Ryan Torres	Active	Sample data	seed	2026-06-26
8	Mountain West	West	Ryan Torres	Active	Sample data	seed	2026-06-26
9	New England	Northeast	Karen Walsh	Active	Sample data	SMPL-SALES-	2026-07-05
10	Mid-Atlantic	Northeast	Jenna Park	Active	Sample data	SMPL-SALES-	2026-07-05
11	Southeast	Southeast	Tom Deluca	Active	Sample data	SMPL-SALES-	2026-07-05
12	Gulf Coast	Southeast		Under Review	Sample data	SMPL-SALES-	2026-07-05
13	Great Lakes	Midwest	Jenna Park	Active	Sample data	SMPL-SALES-	2026-07-05
14	Plains	Midwest		Inactive	Sample data	SMPL-SALES-	2026-07-05
15	Pacific Coast	West	Ryan Torres	Active	Sample data	SMPL-SALES-	2026-07-05
16	Mountain West	West	Ryan Torres	Active	Sample data	SMPL-SALES-	2026-07-05
\.


--
-- Data for Name: serial_number; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.serial_number (id, serial_number, product_id, lot_id, status, notes, created_by, created_at) FROM stdin;
1	SMPL-OPS-SN-WA-0001	5	7	issued	\N	SMPL-OPS-	2026-07-05 00:26:08.53046-04
2	SMPL-OPS-SN-WA-0002	5	7	issued	\N	SMPL-OPS-	2026-07-05 00:26:08.53046-04
3	SMPL-OPS-SN-WA-0003	5	7	available	\N	SMPL-OPS-	2026-07-05 00:26:08.53046-04
4	SMPL-OPS-SN-WA-0004	5	7	available	\N	SMPL-OPS-	2026-07-05 00:26:08.53046-04
5	SMPL-OPS-SN-WA-0005	5	7	available	\N	SMPL-OPS-	2026-07-05 00:26:08.53046-04
6	SMPL-OPS-SN-WA-0006	5	7	available	\N	SMPL-OPS-	2026-07-05 00:26:08.53046-04
7	SMPL-OPS-SN-WA-0007	5	7	available	\N	SMPL-OPS-	2026-07-05 00:26:08.53046-04
8	SMPL-OPS-SN-WA-0008	5	7	available	\N	SMPL-OPS-	2026-07-05 00:26:08.53046-04
\.


--
-- Data for Name: shipment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipment (id, ship_number, so_id, ship_date, carrier, tracking_number, status, notes, created_by) FROM stdin;
1	SMPL-SH-001	\N	2026-06-07	FedEx	274899689001	delivered	Standard ground — delivered to loading dock	SMPL-SHIP-
2	SMPL-SH-002	\N	2026-06-14	UPS	1Z999AA10123456001	delivered	Residential delivery confirmed	SMPL-SHIP-
3	SMPL-SH-003	\N	2026-06-21	USPS	9400111899223800000001	delivered	Delivered — signature obtained	SMPL-SHIP-
4	SMPL-SH-004	\N	2026-06-28	FedEx	274899689002	shipped	In transit — estimated 2-day delivery	SMPL-SHIP-
5	SMPL-SH-005	\N	2026-06-30	DHL	1234567890001	shipped	International — customs cleared	SMPL-SHIP-
6	SMPL-SH-006	\N	2026-07-03	UPS	1Z999AA10123456002	pending	Label printed — awaiting carrier pickup	SMPL-SHIP-
7	SMPL-SH-007	\N	2026-07-04	FedEx	274899689003	pending	Packing in progress	SMPL-SHIP-
8	SMPL-SH-008	\N	2026-06-17	UPS	1Z999AA10123456003	returned	Customer refused delivery — damaged in transit	SMPL-SHIP-
\.


--
-- Data for Name: shipment_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shipment_item (id, shipment_id, description, product_id, qty, created_by) FROM stdin;
1	1	Road Bike Frame — Carbon 54cm	\N	2	
2	1	700c Front Wheel Assembly	\N	2	
3	1	Drop Handlebar 42cm	\N	4	
4	1	Racing Saddle	\N	2	
5	2	Mountain Bike Frame — Aluminum 17in	\N	3	
6	2	26in Knobby Tire	\N	6	
7	2	26in Inner Tube	\N	6	
8	2	Disc Brake Rotor 180mm	\N	4	
9	3	Aluminum Stem 90mm	\N	8	
10	3	Ergonomic Grip Set	\N	10	
11	3	Seat Post 27.2mm x 350mm	\N	5	
12	4	Road Bike Crankset 170mm	\N	4	
13	4	Chain 11-Speed	\N	4	
14	4	Rear Derailleur 11-Speed	\N	4	
15	4	Front Derailleur Braze-On	\N	4	
16	5	700c Rear Wheel Hub Flange	\N	10	
17	5	Spoke Set 32H Stainless	\N	5	
18	5	700c Rim 32H Double-Wall	\N	5	
19	6	Hybrid Bike Frame 19in	\N	1	
20	6	Flat Handlebar 680mm	\N	2	
21	6	V-Brake Caliper Set	\N	2	
22	6	Hybrid Comfort Saddle Wide	\N	1	
23	7	Kids Bike Frame 20in	\N	5	
24	7	20in Training Wheel Set	\N	5	
25	8	Road Bike Frame — Carbon 56cm	\N	1	
26	8	Carbon Fork 1-1/8in Tapered	\N	1	
27	8	Integrated Headset 44mm	\N	1	
\.


--
-- Data for Name: so_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.so_item (id, so_id, description, product_id, qty, unit_price, created_by) FROM stdin;
1	1	Mountain Bike	2	10	450	
2	2	Road Bike	3	4	520	
3	2	Mountain Bike	2	2	450	
4	3	Road Bike	3	5	520	
\.


--
-- Data for Name: spc_control_limit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spc_control_limit (id, product_id, characteristic, ucl, lcl, target, sigma, subgroup_size, is_active, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: spc_measurement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spc_measurement (id, product_id, characteristic, measured_value, measured_by, measured_at, wo_id, lot_id, in_control, notes, created_by) FROM stdin;
\.


--
-- Data for Name: supplier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier (id, first_name, last_name, company_name, phone_number, address, city, state, zip_code, email, created_by) FROM stdin;
1	Dan	Burk	Acme LLc	3334442424	1234 Somewhere St	Somewhere	NV	34567	dan@burk.com	\N
2	Lynn	Markel	Chemsoft	454556666	213 Anywhere Lane	Anywhere	AK	23678	lynn@markel.com	\N
3	John	Smith	Acme Steel Supplies	555-100-0001	100 Industrial Blvd	Detroit	MI	48201	orders@acmesteel.example.com	SMPL-PURCH-
4	Maria	Garcia	Pacific Rim Components	555-100-0002	250 Harbor Way	Long Beach	CA	90802	sales@pacificrim.example.com	SMPL-PURCH-
5	Robert	Johnson	Midwest Paint & Coatings	555-100-0003	775 Paint Ave	Chicago	IL	60601	info@midwestpaint.example.com	SMPL-PURCH-
6	Linda	Williams	Eastern Fastener Corp	555-100-0004	400 Bolt St	Newark	NJ	07101	orders@efastener.example.com	SMPL-PURCH-
7	David	Lee	Southern Rubber & Tire	555-100-0005	1200 Rubber Rd	Memphis	TN	38101	orders@srubber.example.com	SMPL-PURCH-
8	Patricia	Brown	Northern Tube & Pipe	555-100-0006	88 Pipe Lane	Minneapolis	MN	55401	sales@ntubepipe.example.com	SMPL-PURCH-
9	James	Wilson	Apex Electronics Supply	555-100-0007	2020 Circuit Dr	Austin	TX	78701	supply@apexelec.example.com	SMPL-PURCH-
10	Sandra	Miller	Global Office Solutions	555-100-0008	300 Commerce St	Atlanta	GA	30301	orders@globalofc.example.com	SMPL-PURCH-
\.


--
-- Data for Name: supplier_login; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier_login (id, supplier_id, email, password_hash, created_at) FROM stdin;
\.


--
-- Data for Name: tax; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tax (id, state, percent) FROM stdin;
\.


--
-- Data for Name: tax_calendar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tax_calendar (id, tax_type, description, due_date, period, status, notes) FROM stdin;
1	Federal Income Tax	Quarterly estimated payment Q1	2026-04-15	Q1 2026	Pending	
2	Federal Income Tax	Quarterly estimated payment Q2	2026-06-15	Q2 2026	Pending	
3	Federal Income Tax	Quarterly estimated payment Q3	2026-09-15	Q3 2026	Pending	
4	Federal Income Tax	Quarterly estimated payment Q4	2027-01-15	Q4 2026	Pending	
5	Payroll Tax (941)	Monthly deposit	2026-05-15	May 2026	Pending	
6	State Income Tax	Annual filing	2026-04-15	FY 2025	Pending	
7	Sales Tax	Monthly filing	2026-05-20	May 2026	Pending	
8	Payroll Tax	IRS Form 941 — Q2 Payroll Taxes Due	2026-07-11		Pending	Sample data
9	Federal Income	IRS Estimated Tax Payment Q2	2026-07-11		Pending	Sample data
10	Sales Tax	Ohio Sales Tax Q2 Return	2026-07-11		Pending	Sample data
11	Payroll Tax	IRS Form 941 — Q3 Payroll Taxes Due	2026-10-09		Pending	Sample data
12	Federal Income	IRS Estimated Tax Payment Q3	2026-10-09		Pending	Sample data
13	Federal Income	Corporate Tax Return Extension Deadline	2027-04-12		Pending	Sample data
\.


--
-- Data for Name: tax_filing; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tax_filing (id, tax_type, jurisdiction, period, amount_due, amount_paid, filed_date, due_date, status, reference, notes) FROM stdin;
1	Federal Income	IRS	Q1 2026	28500	28500	2026-05-02	2026-04-27	Paid	SMPL-FIN-IRS-Q1-2026	Sample data
2	Payroll Tax	IRS	Apr 2026	14200	14200	2026-05-13	2026-05-12	Paid	SMPL-FIN-IRS-PR-APR	Sample data
3	Payroll Tax	IRS	May 2026	14600	14600	2026-06-12	2026-06-11	Paid	SMPL-FIN-IRS-PR-MAY	Sample data
4	Payroll Tax	IRS	Jun 2026	14800	0	\N	2026-07-11	Pending	SMPL-FIN-IRS-PR-JUN	Sample data
5	Sales Tax	State of Ohio	Q1 2026	8900	8900	2026-04-29	2026-04-27	Paid	SMPL-FIN-OH-SALES-Q1	Sample data
6	Sales Tax	State of Ohio	Q2 2026	9400	0	\N	2026-07-11	Pending	SMPL-FIN-OH-SALES-Q2	Sample data
7	Property Tax	County Assessor	2026	12300	12300	2025-07-01	2025-06-26	Paid	SMPL-FIN-PROP-2026	Sample data
8	Federal Income	IRS	Q2 2026	31200	0	\N	2026-07-11	Pending	SMPL-FIN-IRS-Q2-2026	Sample data
\.


--
-- Data for Name: tax_payment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tax_payment (id, filing_id, tax_type, jurisdiction, period, amount, payment_date, method, reference, notes) FROM stdin;
\.


--
-- Data for Name: time_clock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.time_clock (id, people_id, clock_in, clock_out, notes, hours_worked, created_by) FROM stdin;
1	109	2026-06-01 07:02:00	2026-06-01 15:35:00	Sample data	8.55	seed
2	109	2026-06-02 07:02:00	2026-06-02 15:35:00	Sample data	8.55	seed
3	109	2026-06-03 07:02:00	2026-06-03 15:35:00	Sample data	8.55	seed
4	109	2026-06-04 07:02:00	2026-06-04 15:35:00	Sample data	8.55	seed
5	109	2026-06-05 07:02:00	2026-06-05 15:35:00	Sample data	8.55	seed
6	109	2026-06-08 07:02:00	2026-06-08 15:35:00	Sample data	8.55	seed
7	109	2026-06-09 07:02:00	2026-06-09 15:35:00	Sample data	8.55	seed
8	109	2026-06-10 07:02:00	2026-06-10 15:35:00	Sample data	8.55	seed
9	109	2026-06-11 07:02:00	2026-06-11 15:35:00	Sample data	8.55	seed
10	109	2026-06-12 07:02:00	2026-06-12 15:35:00	Sample data	8.55	seed
11	109	2026-06-15 07:02:00	2026-06-15 15:35:00	Sample data	8.55	seed
12	109	2026-06-16 07:02:00	2026-06-16 15:35:00	Sample data	8.55	seed
13	109	2026-06-17 07:02:00	2026-06-17 15:35:00	Sample data	8.55	seed
14	109	2026-06-18 07:02:00	2026-06-18 15:35:00	Sample data	8.55	seed
15	109	2026-06-19 07:02:00	2026-06-19 15:35:00	Sample data	8.55	seed
16	109	2026-06-22 07:02:00	2026-06-22 15:35:00	Sample data	8.55	seed
17	109	2026-06-23 07:02:00	2026-06-23 15:35:00	Sample data	8.55	seed
18	109	2026-06-24 07:02:00	2026-06-24 15:35:00	Sample data	8.55	seed
19	109	2026-06-25 07:02:00	2026-06-25 15:35:00	Sample data	8.55	seed
20	109	2026-06-26 07:02:00	2026-06-26 15:35:00	Sample data	8.55	seed
21	110	2026-06-01 07:15:00	2026-06-01 15:48:00	Sample data	8.55	seed
22	110	2026-06-02 07:15:00	2026-06-02 15:48:00	Sample data	8.55	seed
23	110	2026-06-03 07:15:00	2026-06-03 15:48:00	Sample data	8.55	seed
24	110	2026-06-04 07:15:00	2026-06-04 15:48:00	Sample data	8.55	seed
25	110	2026-06-05 07:15:00	2026-06-05 15:48:00	Sample data	8.55	seed
26	110	2026-06-08 07:15:00	2026-06-08 15:48:00	Sample data	8.55	seed
27	110	2026-06-09 07:15:00	2026-06-09 15:48:00	Sample data	8.55	seed
28	110	2026-06-10 07:15:00	2026-06-10 15:48:00	Sample data	8.55	seed
29	110	2026-06-11 07:15:00	2026-06-11 15:48:00	Sample data	8.55	seed
30	110	2026-06-12 07:15:00	2026-06-12 15:48:00	Sample data	8.55	seed
31	110	2026-06-15 07:15:00	2026-06-15 15:48:00	Sample data	8.55	seed
32	110	2026-06-16 07:15:00	2026-06-16 15:48:00	Sample data	8.55	seed
33	110	2026-06-17 07:15:00	2026-06-17 15:48:00	Sample data	8.55	seed
34	110	2026-06-18 07:15:00	2026-06-18 15:48:00	Sample data	8.55	seed
35	110	2026-06-19 07:15:00	2026-06-19 15:48:00	Sample data	8.55	seed
36	110	2026-06-22 07:15:00	2026-06-22 15:48:00	Sample data	8.55	seed
37	110	2026-06-23 07:15:00	2026-06-23 15:48:00	Sample data	8.55	seed
38	110	2026-06-24 07:15:00	2026-06-24 15:48:00	Sample data	8.55	seed
39	110	2026-06-25 07:15:00	2026-06-25 15:48:00	Sample data	8.55	seed
40	110	2026-06-26 07:15:00	2026-06-26 15:48:00	Sample data	8.55	seed
41	111	2026-06-01 07:08:00	2026-06-01 15:42:00	Sample data	8.57	seed
42	111	2026-06-02 07:08:00	2026-06-02 15:42:00	Sample data	8.57	seed
43	111	2026-06-03 07:08:00	2026-06-03 15:42:00	Sample data	8.57	seed
44	111	2026-06-04 07:08:00	2026-06-04 15:42:00	Sample data	8.57	seed
45	111	2026-06-05 07:08:00	2026-06-05 15:42:00	Sample data	8.57	seed
46	111	2026-06-08 07:08:00	2026-06-08 15:42:00	Sample data	8.57	seed
47	111	2026-06-09 07:08:00	2026-06-09 15:42:00	Sample data	8.57	seed
48	111	2026-06-10 07:08:00	2026-06-10 15:42:00	Sample data	8.57	seed
49	111	2026-06-11 07:08:00	2026-06-11 15:42:00	Sample data	8.57	seed
50	111	2026-06-12 07:08:00	2026-06-12 15:42:00	Sample data	8.57	seed
51	111	2026-06-15 07:08:00	2026-06-15 15:42:00	Sample data	8.57	seed
52	111	2026-06-16 07:08:00	2026-06-16 15:42:00	Sample data	8.57	seed
53	111	2026-06-17 07:08:00	2026-06-17 15:42:00	Sample data	8.57	seed
54	111	2026-06-18 07:08:00	2026-06-18 15:42:00	Sample data	8.57	seed
55	111	2026-06-19 07:08:00	2026-06-19 15:42:00	Sample data	8.57	seed
56	111	2026-06-22 07:08:00	2026-06-22 15:42:00	Sample data	8.57	seed
57	111	2026-06-23 07:08:00	2026-06-23 15:42:00	Sample data	8.57	seed
58	111	2026-06-24 07:08:00	2026-06-24 15:42:00	Sample data	8.57	seed
59	111	2026-06-25 07:08:00	2026-06-25 15:42:00	Sample data	8.57	seed
60	111	2026-06-26 07:08:00	2026-06-26 15:42:00	Sample data	8.57	seed
61	112	2026-06-01 07:20:00	2026-06-01 15:55:00	Sample data	8.58	seed
62	112	2026-06-02 07:20:00	2026-06-02 15:55:00	Sample data	8.58	seed
63	112	2026-06-03 07:20:00	2026-06-03 15:55:00	Sample data	8.58	seed
64	112	2026-06-04 07:20:00	2026-06-04 15:55:00	Sample data	8.58	seed
65	112	2026-06-05 07:20:00	2026-06-05 15:55:00	Sample data	8.58	seed
66	112	2026-06-08 07:20:00	2026-06-08 15:55:00	Sample data	8.58	seed
67	112	2026-06-09 07:20:00	2026-06-09 15:55:00	Sample data	8.58	seed
68	112	2026-06-10 07:20:00	2026-06-10 15:55:00	Sample data	8.58	seed
69	112	2026-06-11 07:20:00	2026-06-11 15:55:00	Sample data	8.58	seed
70	112	2026-06-12 07:20:00	2026-06-12 15:55:00	Sample data	8.58	seed
71	112	2026-06-15 07:20:00	2026-06-15 15:55:00	Sample data	8.58	seed
72	112	2026-06-16 07:20:00	2026-06-16 15:55:00	Sample data	8.58	seed
73	112	2026-06-17 07:20:00	2026-06-17 15:55:00	Sample data	8.58	seed
74	112	2026-06-18 07:20:00	2026-06-18 15:55:00	Sample data	8.58	seed
75	112	2026-06-19 07:20:00	2026-06-19 15:55:00	Sample data	8.58	seed
76	112	2026-06-22 07:20:00	2026-06-22 15:55:00	Sample data	8.58	seed
77	112	2026-06-23 07:20:00	2026-06-23 15:55:00	Sample data	8.58	seed
78	112	2026-06-24 07:20:00	2026-06-24 15:55:00	Sample data	8.58	seed
79	112	2026-06-25 07:20:00	2026-06-25 15:55:00	Sample data	8.58	seed
80	112	2026-06-26 07:20:00	2026-06-26 15:55:00	Sample data	8.58	seed
81	113	2026-06-01 07:05:00	2026-06-01 15:38:00	Sample data	8.55	seed
82	113	2026-06-02 07:05:00	2026-06-02 15:38:00	Sample data	8.55	seed
83	113	2026-06-03 07:05:00	2026-06-03 15:38:00	Sample data	8.55	seed
84	113	2026-06-04 07:05:00	2026-06-04 15:38:00	Sample data	8.55	seed
85	113	2026-06-05 07:05:00	2026-06-05 15:38:00	Sample data	8.55	seed
86	113	2026-06-08 07:05:00	2026-06-08 15:38:00	Sample data	8.55	seed
87	113	2026-06-09 07:05:00	2026-06-09 15:38:00	Sample data	8.55	seed
88	113	2026-06-10 07:05:00	2026-06-10 15:38:00	Sample data	8.55	seed
89	113	2026-06-11 07:05:00	2026-06-11 15:38:00	Sample data	8.55	seed
90	113	2026-06-12 07:05:00	2026-06-12 15:38:00	Sample data	8.55	seed
91	113	2026-06-15 07:05:00	2026-06-15 15:38:00	Sample data	8.55	seed
92	113	2026-06-16 07:05:00	2026-06-16 15:38:00	Sample data	8.55	seed
93	113	2026-06-17 07:05:00	2026-06-17 15:38:00	Sample data	8.55	seed
94	113	2026-06-18 07:05:00	2026-06-18 15:38:00	Sample data	8.55	seed
95	113	2026-06-19 07:05:00	2026-06-19 15:38:00	Sample data	8.55	seed
96	113	2026-06-22 07:05:00	2026-06-22 15:38:00	Sample data	8.55	seed
97	113	2026-06-23 07:05:00	2026-06-23 15:38:00	Sample data	8.55	seed
98	113	2026-06-24 07:05:00	2026-06-24 15:38:00	Sample data	8.55	seed
99	113	2026-06-25 07:05:00	2026-06-25 15:38:00	Sample data	8.55	seed
100	113	2026-06-26 07:05:00	2026-06-26 15:38:00	Sample data	8.55	seed
101	115	2026-06-01 07:30:00	2026-06-01 16:02:00	Sample data	8.53	seed
102	115	2026-06-02 07:30:00	2026-06-02 16:02:00	Sample data	8.53	seed
103	115	2026-06-03 07:30:00	2026-06-03 16:02:00	Sample data	8.53	seed
104	115	2026-06-04 07:30:00	2026-06-04 16:02:00	Sample data	8.53	seed
105	115	2026-06-05 07:30:00	2026-06-05 16:02:00	Sample data	8.53	seed
106	115	2026-06-08 07:30:00	2026-06-08 16:02:00	Sample data	8.53	seed
107	115	2026-06-09 07:30:00	2026-06-09 16:02:00	Sample data	8.53	seed
108	115	2026-06-10 07:30:00	2026-06-10 16:02:00	Sample data	8.53	seed
109	115	2026-06-11 07:30:00	2026-06-11 16:02:00	Sample data	8.53	seed
110	115	2026-06-12 07:30:00	2026-06-12 16:02:00	Sample data	8.53	seed
111	115	2026-06-15 07:30:00	2026-06-15 16:02:00	Sample data	8.53	seed
112	115	2026-06-16 07:30:00	2026-06-16 16:02:00	Sample data	8.53	seed
113	115	2026-06-17 07:30:00	2026-06-17 16:02:00	Sample data	8.53	seed
114	115	2026-06-18 07:30:00	2026-06-18 16:02:00	Sample data	8.53	seed
115	115	2026-06-19 07:30:00	2026-06-19 16:02:00	Sample data	8.53	seed
116	115	2026-06-22 07:30:00	2026-06-22 16:02:00	Sample data	8.53	seed
117	115	2026-06-23 07:30:00	2026-06-23 16:02:00	Sample data	8.53	seed
118	115	2026-06-24 07:30:00	2026-06-24 16:02:00	Sample data	8.53	seed
119	115	2026-06-25 07:30:00	2026-06-25 16:02:00	Sample data	8.53	seed
120	115	2026-06-26 07:30:00	2026-06-26 16:02:00	Sample data	8.53	seed
121	116	2026-06-01 07:25:00	2026-06-01 16:00:00	Sample data	8.58	seed
122	116	2026-06-02 07:25:00	2026-06-02 16:00:00	Sample data	8.58	seed
123	116	2026-06-03 07:25:00	2026-06-03 16:00:00	Sample data	8.58	seed
124	116	2026-06-04 07:25:00	2026-06-04 16:00:00	Sample data	8.58	seed
125	116	2026-06-05 07:25:00	2026-06-05 16:00:00	Sample data	8.58	seed
126	116	2026-06-08 07:25:00	2026-06-08 16:00:00	Sample data	8.58	seed
127	116	2026-06-09 07:25:00	2026-06-09 16:00:00	Sample data	8.58	seed
128	116	2026-06-10 07:25:00	2026-06-10 16:00:00	Sample data	8.58	seed
129	116	2026-06-11 07:25:00	2026-06-11 16:00:00	Sample data	8.58	seed
130	116	2026-06-12 07:25:00	2026-06-12 16:00:00	Sample data	8.58	seed
131	116	2026-06-15 07:25:00	2026-06-15 16:00:00	Sample data	8.58	seed
132	116	2026-06-16 07:25:00	2026-06-16 16:00:00	Sample data	8.58	seed
133	116	2026-06-17 07:25:00	2026-06-17 16:00:00	Sample data	8.58	seed
134	116	2026-06-18 07:25:00	2026-06-18 16:00:00	Sample data	8.58	seed
135	116	2026-06-19 07:25:00	2026-06-19 16:00:00	Sample data	8.58	seed
136	116	2026-06-22 07:25:00	2026-06-22 16:00:00	Sample data	8.58	seed
137	116	2026-06-23 07:25:00	2026-06-23 16:00:00	Sample data	8.58	seed
138	116	2026-06-24 07:25:00	2026-06-24 16:00:00	Sample data	8.58	seed
139	116	2026-06-25 07:25:00	2026-06-25 16:00:00	Sample data	8.58	seed
140	116	2026-06-26 07:25:00	2026-06-26 16:00:00	Sample data	8.58	seed
141	123	2026-06-01 07:10:00	2026-06-01 15:45:00	Sample data	8.58	seed
142	123	2026-06-02 07:10:00	2026-06-02 15:45:00	Sample data	8.58	seed
143	123	2026-06-03 07:10:00	2026-06-03 15:45:00	Sample data	8.58	seed
144	123	2026-06-04 07:10:00	2026-06-04 15:45:00	Sample data	8.58	seed
145	123	2026-06-05 07:10:00	2026-06-05 15:45:00	Sample data	8.58	seed
146	123	2026-06-08 07:10:00	2026-06-08 15:45:00	Sample data	8.58	seed
147	123	2026-06-09 07:10:00	2026-06-09 15:45:00	Sample data	8.58	seed
148	123	2026-06-10 07:10:00	2026-06-10 15:45:00	Sample data	8.58	seed
149	123	2026-06-11 07:10:00	2026-06-11 15:45:00	Sample data	8.58	seed
150	123	2026-06-12 07:10:00	2026-06-12 15:45:00	Sample data	8.58	seed
151	123	2026-06-15 07:10:00	2026-06-15 15:45:00	Sample data	8.58	seed
152	123	2026-06-16 07:10:00	2026-06-16 15:45:00	Sample data	8.58	seed
153	123	2026-06-17 07:10:00	2026-06-17 15:45:00	Sample data	8.58	seed
154	123	2026-06-18 07:10:00	2026-06-18 15:45:00	Sample data	8.58	seed
155	123	2026-06-19 07:10:00	2026-06-19 15:45:00	Sample data	8.58	seed
156	123	2026-06-22 07:10:00	2026-06-22 15:45:00	Sample data	8.58	seed
157	123	2026-06-23 07:10:00	2026-06-23 15:45:00	Sample data	8.58	seed
158	123	2026-06-24 07:10:00	2026-06-24 15:45:00	Sample data	8.58	seed
159	123	2026-06-25 07:10:00	2026-06-25 15:45:00	Sample data	8.58	seed
160	123	2026-06-26 07:10:00	2026-06-26 15:45:00	Sample data	8.58	seed
161	124	2026-06-01 07:18:00	2026-06-01 15:50:00	Sample data	8.53	seed
162	124	2026-06-02 07:18:00	2026-06-02 15:50:00	Sample data	8.53	seed
163	124	2026-06-03 07:18:00	2026-06-03 15:50:00	Sample data	8.53	seed
164	124	2026-06-04 07:18:00	2026-06-04 15:50:00	Sample data	8.53	seed
165	124	2026-06-05 07:18:00	2026-06-05 15:50:00	Sample data	8.53	seed
166	124	2026-06-08 07:18:00	2026-06-08 15:50:00	Sample data	8.53	seed
167	124	2026-06-09 07:18:00	2026-06-09 15:50:00	Sample data	8.53	seed
168	124	2026-06-10 07:18:00	2026-06-10 15:50:00	Sample data	8.53	seed
169	124	2026-06-11 07:18:00	2026-06-11 15:50:00	Sample data	8.53	seed
170	124	2026-06-12 07:18:00	2026-06-12 15:50:00	Sample data	8.53	seed
171	124	2026-06-15 07:18:00	2026-06-15 15:50:00	Sample data	8.53	seed
172	124	2026-06-16 07:18:00	2026-06-16 15:50:00	Sample data	8.53	seed
173	124	2026-06-17 07:18:00	2026-06-17 15:50:00	Sample data	8.53	seed
174	124	2026-06-18 07:18:00	2026-06-18 15:50:00	Sample data	8.53	seed
175	124	2026-06-19 07:18:00	2026-06-19 15:50:00	Sample data	8.53	seed
176	124	2026-06-22 07:18:00	2026-06-22 15:50:00	Sample data	8.53	seed
177	124	2026-06-23 07:18:00	2026-06-23 15:50:00	Sample data	8.53	seed
178	124	2026-06-24 07:18:00	2026-06-24 15:50:00	Sample data	8.53	seed
179	124	2026-06-25 07:18:00	2026-06-25 15:50:00	Sample data	8.53	seed
180	124	2026-06-26 07:18:00	2026-06-26 15:50:00	Sample data	8.53	seed
181	129	2026-06-01 07:28:00	2026-06-01 16:05:00	Sample data	8.62	seed
182	129	2026-06-02 07:28:00	2026-06-02 16:05:00	Sample data	8.62	seed
183	129	2026-06-03 07:28:00	2026-06-03 16:05:00	Sample data	8.62	seed
184	129	2026-06-04 07:28:00	2026-06-04 16:05:00	Sample data	8.62	seed
185	129	2026-06-05 07:28:00	2026-06-05 16:05:00	Sample data	8.62	seed
186	129	2026-06-08 07:28:00	2026-06-08 16:05:00	Sample data	8.62	seed
187	129	2026-06-09 07:28:00	2026-06-09 16:05:00	Sample data	8.62	seed
188	129	2026-06-10 07:28:00	2026-06-10 16:05:00	Sample data	8.62	seed
189	129	2026-06-11 07:28:00	2026-06-11 16:05:00	Sample data	8.62	seed
190	129	2026-06-12 07:28:00	2026-06-12 16:05:00	Sample data	8.62	seed
191	129	2026-06-15 07:28:00	2026-06-15 16:05:00	Sample data	8.62	seed
192	129	2026-06-16 07:28:00	2026-06-16 16:05:00	Sample data	8.62	seed
193	129	2026-06-17 07:28:00	2026-06-17 16:05:00	Sample data	8.62	seed
194	129	2026-06-18 07:28:00	2026-06-18 16:05:00	Sample data	8.62	seed
195	129	2026-06-19 07:28:00	2026-06-19 16:05:00	Sample data	8.62	seed
196	129	2026-06-22 07:28:00	2026-06-22 16:05:00	Sample data	8.62	seed
197	129	2026-06-23 07:28:00	2026-06-23 16:05:00	Sample data	8.62	seed
198	129	2026-06-24 07:28:00	2026-06-24 16:05:00	Sample data	8.62	seed
199	129	2026-06-25 07:28:00	2026-06-25 16:05:00	Sample data	8.62	seed
200	129	2026-06-26 07:28:00	2026-06-26 16:05:00	Sample data	8.62	seed
201	109	2026-06-29 07:02:00	2026-06-29 15:35:00	Sample data	8.55	SMPL-PERS-
202	109	2026-06-30 07:02:00	2026-06-30 15:35:00	Sample data	8.55	SMPL-PERS-
203	109	2026-07-01 07:02:00	2026-07-01 15:35:00	Sample data	8.55	SMPL-PERS-
204	109	2026-07-02 07:02:00	2026-07-02 15:35:00	Sample data	8.55	SMPL-PERS-
205	109	2026-07-03 07:02:00	2026-07-03 15:35:00	Sample data	8.55	SMPL-PERS-
206	110	2026-06-29 07:15:00	2026-06-29 15:48:00	Sample data	8.55	SMPL-PERS-
207	110	2026-06-30 07:15:00	2026-06-30 15:48:00	Sample data	8.55	SMPL-PERS-
208	110	2026-07-01 07:15:00	2026-07-01 15:48:00	Sample data	8.55	SMPL-PERS-
209	110	2026-07-02 07:15:00	2026-07-02 15:48:00	Sample data	8.55	SMPL-PERS-
210	110	2026-07-03 07:15:00	2026-07-03 15:48:00	Sample data	8.55	SMPL-PERS-
211	111	2026-06-29 07:08:00	2026-06-29 15:42:00	Sample data	8.57	SMPL-PERS-
212	111	2026-06-30 07:08:00	2026-06-30 15:42:00	Sample data	8.57	SMPL-PERS-
213	111	2026-07-01 07:08:00	2026-07-01 15:42:00	Sample data	8.57	SMPL-PERS-
214	111	2026-07-02 07:08:00	2026-07-02 15:42:00	Sample data	8.57	SMPL-PERS-
215	111	2026-07-03 07:08:00	2026-07-03 15:42:00	Sample data	8.57	SMPL-PERS-
216	112	2026-06-29 07:20:00	2026-06-29 15:55:00	Sample data	8.58	SMPL-PERS-
217	112	2026-06-30 07:20:00	2026-06-30 15:55:00	Sample data	8.58	SMPL-PERS-
218	112	2026-07-01 07:20:00	2026-07-01 15:55:00	Sample data	8.58	SMPL-PERS-
219	112	2026-07-02 07:20:00	2026-07-02 15:55:00	Sample data	8.58	SMPL-PERS-
220	112	2026-07-03 07:20:00	2026-07-03 15:55:00	Sample data	8.58	SMPL-PERS-
221	113	2026-06-29 07:05:00	2026-06-29 15:38:00	Sample data	8.55	SMPL-PERS-
222	113	2026-06-30 07:05:00	2026-06-30 15:38:00	Sample data	8.55	SMPL-PERS-
223	113	2026-07-01 07:05:00	2026-07-01 15:38:00	Sample data	8.55	SMPL-PERS-
224	113	2026-07-02 07:05:00	2026-07-02 15:38:00	Sample data	8.55	SMPL-PERS-
225	113	2026-07-03 07:05:00	2026-07-03 15:38:00	Sample data	8.55	SMPL-PERS-
226	115	2026-06-29 07:30:00	2026-06-29 16:02:00	Sample data	8.53	SMPL-PERS-
227	115	2026-06-30 07:30:00	2026-06-30 16:02:00	Sample data	8.53	SMPL-PERS-
228	115	2026-07-01 07:30:00	2026-07-01 16:02:00	Sample data	8.53	SMPL-PERS-
229	115	2026-07-02 07:30:00	2026-07-02 16:02:00	Sample data	8.53	SMPL-PERS-
230	115	2026-07-03 07:30:00	2026-07-03 16:02:00	Sample data	8.53	SMPL-PERS-
231	116	2026-06-29 07:25:00	2026-06-29 16:00:00	Sample data	8.58	SMPL-PERS-
232	116	2026-06-30 07:25:00	2026-06-30 16:00:00	Sample data	8.58	SMPL-PERS-
233	116	2026-07-01 07:25:00	2026-07-01 16:00:00	Sample data	8.58	SMPL-PERS-
234	116	2026-07-02 07:25:00	2026-07-02 16:00:00	Sample data	8.58	SMPL-PERS-
235	116	2026-07-03 07:25:00	2026-07-03 16:00:00	Sample data	8.58	SMPL-PERS-
236	123	2026-06-29 07:10:00	2026-06-29 15:45:00	Sample data	8.58	SMPL-PERS-
237	123	2026-06-30 07:10:00	2026-06-30 15:45:00	Sample data	8.58	SMPL-PERS-
238	123	2026-07-01 07:10:00	2026-07-01 15:45:00	Sample data	8.58	SMPL-PERS-
239	123	2026-07-02 07:10:00	2026-07-02 15:45:00	Sample data	8.58	SMPL-PERS-
240	123	2026-07-03 07:10:00	2026-07-03 15:45:00	Sample data	8.58	SMPL-PERS-
241	124	2026-06-29 07:18:00	2026-06-29 15:50:00	Sample data	8.53	SMPL-PERS-
242	124	2026-06-30 07:18:00	2026-06-30 15:50:00	Sample data	8.53	SMPL-PERS-
243	124	2026-07-01 07:18:00	2026-07-01 15:50:00	Sample data	8.53	SMPL-PERS-
244	124	2026-07-02 07:18:00	2026-07-02 15:50:00	Sample data	8.53	SMPL-PERS-
245	124	2026-07-03 07:18:00	2026-07-03 15:50:00	Sample data	8.53	SMPL-PERS-
246	129	2026-06-29 07:28:00	2026-06-29 16:05:00	Sample data	8.62	SMPL-PERS-
247	129	2026-06-30 07:28:00	2026-06-30 16:05:00	Sample data	8.62	SMPL-PERS-
248	129	2026-07-01 07:28:00	2026-07-01 16:05:00	Sample data	8.62	SMPL-PERS-
249	129	2026-07-02 07:28:00	2026-07-02 16:05:00	Sample data	8.62	SMPL-PERS-
250	129	2026-07-03 07:28:00	2026-07-03 16:05:00	Sample data	8.62	SMPL-PERS-
\.


--
-- Data for Name: time_clock_devices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.time_clock_devices (id, name, location, device_type, ip_address, port, config_json, enabled, created_by) FROM stdin;
\.


--
-- Data for Name: time_clock_sync_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.time_clock_sync_log (id, device_id, synced_at, status, records_imported, error_msg) FROM stdin;
\.


--
-- Data for Name: time_off_balance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.time_off_balance (id, people_id, year, allotted_days) FROM stdin;
\.


--
-- Data for Name: time_off_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.time_off_request (id, people_id, request_date, start_date, end_date, request_type, status, notes, created_by) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (id, people_id, role_id) FROM stdin;
1	21	49
2	101	49
3	102	51
4	103	52
5	104	51
6	105	52
7	106	52
8	107	52
9	108	51
10	109	52
11	110	52
12	111	52
13	112	52
14	113	52
15	114	52
16	115	51
17	116	51
18	117	52
19	118	51
20	119	52
21	120	52
22	121	52
23	122	52
24	123	52
25	124	52
26	125	52
27	126	52
28	127	52
29	128	54
30	129	52
31	130	52
32	131	52
33	132	52
34	133	51
35	134	51
36	135	51
37	136	52
38	137	52
39	138	51
40	139	52
41	140	52
42	141	51
43	142	52
44	143	52
45	144	51
46	145	52
47	146	52
\.


--
-- Data for Name: wo_cost_actual; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wo_cost_actual (id, wo_id, actual_material_cost, actual_labor_cost, actual_overhead_cost, total_actual_cost, std_cost, material_variance, labor_variance, total_variance, created_by, created_at) FROM stdin;
1	4	474.4	148	34	656.4	620	0	36.399994	36.4	SMPL-OPS-	2026-07-05 00:26:08.537894-04
\.


--
-- Data for Name: wo_material; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wo_material (id, wo_id, product_id, qty_required, qty_issued, notes, lot_id) FROM stdin;
1	1	4	5	0	\N	\N
2	1	5	10	0	\N	\N
3	1	6	5	0	\N	\N
4	1	7	5	0	\N	\N
5	2	4	3	0	\N	\N
6	2	5	6	0	\N	\N
7	2	6	3	0	\N	\N
8	2	7	3	0	\N	\N
9	3	8	40	40	\N	\N
10	3	9	10	5	\N	\N
11	4	10	8	8	\N	\N
12	4	11	256	256	\N	\N
13	4	12	8	8	\N	\N
14	4	13	8	8	\N	\N
\.


--
-- Data for Name: wo_operation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wo_operation (id, wo_id, routing_id, operation_seq, operation_name, workcenter_id, std_hours, actual_hours, scrap_qty, rework_qty, status, started_at, completed_at, completed_by, notes, created_by, scheduled_start, scheduled_end) FROM stdin;
1	1	6	10	Final Assembly	4	1.5	\N	0	0	pending	\N	\N	\N	\N		\N	\N
2	1	7	20	QA Inspection	5	0.3	\N	0	0	pending	\N	\N	\N	\N		\N	\N
3	2	8	10	Final Assembly	4	1.4	\N	0	0	pending	\N	\N	\N	\N		\N	\N
4	2	9	20	QA Inspection	5	0.3	\N	0	0	pending	\N	\N	\N	\N		\N	\N
7	3	3	30	Paint Frame	2	0.75	\N	0	0	pending	\N	\N	\N	\N		\N	\N
5	3	1	10	Cut Tube	1	0.5	0.6	0	0	completed	\N	2026-07-05 00:26:08.516029-04	Sample Seed	\N		\N	\N
6	3	2	20	Weld Frame	1	1	\N	0	0	in_progress	2026-07-05 00:26:08.516029-04	\N	\N	\N		\N	\N
8	4	4	10	Build Wheel	3	0.4	4	0	0	completed	\N	2026-07-05 00:26:08.516029-04	Sample Seed	\N		\N	\N
9	4	5	20	True & Inspect	5	0.2	2	0	0	completed	\N	2026-07-05 00:26:08.516029-04	Sample Seed	\N		\N	\N
\.


--
-- Data for Name: work_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.work_order (id, wo_number, product_id, description, quantity, start_date, due_date, status, notes, created_by) FROM stdin;
1	SMPL-WO-1	2	Assemble mountain bike batch	5	2026-06-18	2026-07-02	draft	Awaiting materials pick	\N
2	SMPL-WO-2	3	Road bike production run	3	2026-06-16	2026-06-23	open	Materials staged, ready to start	\N
3	SMPL-WO-3	4	Bike frame fabrication batch	10	2026-06-13	2026-06-16	in_progress	Steel cut, painting in progress	\N
4	SMPL-WO-4	5	Wheel assembly batch — Q2	8	2026-05-29	2026-05-26	completed	All units passed QA	\N
5	SMPL-WO-5	2	Duplicate mountain bike order	2	2026-06-08	2026-06-12	cancelled	Cancelled — merged into SMPL-WO-1	\N
\.


--
-- Data for Name: workcenter; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workcenter (id, name, dept, capacity_hours_per_day, labor_rate, notes, is_active, overhead_rate, created_by) FROM stdin;
1	Cutting Station	Production	8	22.5	\N	t	8	SMPL-OPS-
2	Paint Booth	Production	6	19	\N	t	12	SMPL-OPS-
3	Wheel Building	Production	8	24	\N	t	6	SMPL-OPS-
4	Final Assembly	Production	8	21	\N	t	9	SMPL-OPS-
5	Quality Inspection	Quality	8	26	\N	t	5	SMPL-OPS-
\.


--
-- Name: ap_invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ap_invoice_id_seq', 8, true);


--
-- Name: ap_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ap_payment_id_seq', 3, true);


--
-- Name: api_login_attempt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_login_attempt_id_seq', 3, true);


--
-- Name: approval_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.approval_rule_id_seq', 5, true);


--
-- Name: approval_step_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.approval_step_id_seq', 1, false);


--
-- Name: ar_invoice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ar_invoice_id_seq', 7, true);


--
-- Name: ar_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ar_payment_id_seq', 3, true);


--
-- Name: audit_finding_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_finding_id_seq', 4, true);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 256, true);


--
-- Name: audit_schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_schedule_id_seq', 8, true);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 24, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, false);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: bank_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bank_account_id_seq', 4, true);


--
-- Name: bank_reconciliation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bank_reconciliation_id_seq', 1, false);


--
-- Name: bank_statement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bank_statement_id_seq', 10, true);


--
-- Name: bank_statement_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bank_statement_item_id_seq', 1, false);


--
-- Name: bank_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bank_transaction_id_seq', 1, false);


--
-- Name: bom_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bom_id_seq', 14, true);


--
-- Name: budget_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_id_seq', 5, true);


--
-- Name: budget_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.budget_line_id_seq', 18, true);


--
-- Name: calls2_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.calls2_id_seq', 25, true);


--
-- Name: closed_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.closed_periods_id_seq', 1, false);


--
-- Name: collection_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.collection_activity_id_seq', 5, true);


--
-- Name: compliance_checklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.compliance_checklist_id_seq', 1, false);


--
-- Name: compliance_checklist_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.compliance_checklist_item_id_seq', 1, false);


--
-- Name: compliance_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.compliance_template_id_seq', 2, true);


--
-- Name: compliance_template_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.compliance_template_item_id_seq', 13, true);


--
-- Name: corrective_action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.corrective_action_id_seq', 1, false);


--
-- Name: cost_center_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cost_center_id_seq', 1, false);


--
-- Name: cost_roll_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cost_roll_id_seq', 22, true);


--
-- Name: credit_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.credit_account_id_seq', 10, true);


--
-- Name: credit_application_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.credit_application_id_seq', 8, true);


--
-- Name: credit_limit_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.credit_limit_history_id_seq', 4, true);


--
-- Name: cs_improvement_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cs_improvement_plan_id_seq', 5, true);


--
-- Name: cs_kb_article_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cs_kb_article_id_seq', 9, true);


--
-- Name: cs_return_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cs_return_id_seq', 14, true);


--
-- Name: cs_survey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cs_survey_id_seq', 4, true);


--
-- Name: cs_survey_response_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cs_survey_response_id_seq', 14, true);


--
-- Name: cs_training_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cs_training_id_seq', 1, false);


--
-- Name: customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customer_id_seq', 11, true);


--
-- Name: dept_dept_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dept_dept_id_seq', 14, false);


--
-- Name: dept_sub_dept_sub_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dept_sub_dept_sub_id_seq', 33, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 6, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 18, true);


--
-- Name: employee_deduction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_deduction_id_seq', 56, true);


--
-- Name: employee_pay_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_pay_id_seq', 12, true);


--
-- Name: eng_design_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.eng_design_review_id_seq', 6, true);


--
-- Name: eng_project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.eng_project_id_seq', 6, true);


--
-- Name: eng_standard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.eng_standard_id_seq', 16, true);


--
-- Name: eng_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.eng_task_id_seq', 11, true);


--
-- Name: gl_account_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gl_account_id_seq', 45, false);


--
-- Name: gl_account_map_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gl_account_map_id_seq', 7, true);


--
-- Name: gl_journal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gl_journal_id_seq', 13, true);


--
-- Name: gl_journal_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gl_journal_line_id_seq', 27, true);


--
-- Name: inventory_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_transaction_id_seq', 1, false);


--
-- Name: it_asset_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.it_asset_history_id_seq', 1, false);


--
-- Name: it_asset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.it_asset_id_seq', 15, true);


--
-- Name: it_bandwidth_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.it_bandwidth_log_id_seq', 1, false);


--
-- Name: it_license_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.it_license_id_seq', 9, true);


--
-- Name: it_network_device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.it_network_device_id_seq', 10, true);


--
-- Name: it_network_incident_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.it_network_incident_id_seq', 1, false);


--
-- Name: it_repair_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.it_repair_id_seq', 4, true);


--
-- Name: it_software_install_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.it_software_install_id_seq', 14, true);


--
-- Name: it_task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.it_task_id_seq', 10, true);


--
-- Name: it_ticket_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.it_ticket_id_seq', 12, true);


--
-- Name: legal_compliance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.legal_compliance_id_seq', 12, true);


--
-- Name: legal_contract_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.legal_contract_id_seq', 12, true);


--
-- Name: legal_employment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.legal_employment_id_seq', 1, false);


--
-- Name: legal_governance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.legal_governance_id_seq', 1, false);


--
-- Name: legal_ip_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.legal_ip_id_seq', 1, false);


--
-- Name: legal_litigation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.legal_litigation_id_seq', 5, true);


--
-- Name: location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.location_id_seq', 3, true);


--
-- Name: lot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lot_id_seq', 7, true);


--
-- Name: maint_downtime_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.maint_downtime_id_seq', 12, true);


--
-- Name: maint_equipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.maint_equipment_id_seq', 10, true);


--
-- Name: maint_inspection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.maint_inspection_id_seq', 12, true);


--
-- Name: maint_mechanic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.maint_mechanic_id_seq', 6, true);


--
-- Name: maint_part_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.maint_part_id_seq', 10, true);


--
-- Name: maint_schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.maint_schedule_id_seq', 20, true);


--
-- Name: maint_work_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.maint_work_order_id_seq', 20, true);


--
-- Name: marketing_ad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketing_ad_id_seq', 6, true);


--
-- Name: marketing_analytics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketing_analytics_id_seq', 1, false);


--
-- Name: marketing_budget_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketing_budget_id_seq', 1, false);


--
-- Name: marketing_campaign_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketing_campaign_id_seq', 8, true);


--
-- Name: marketing_content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketing_content_id_seq', 9, true);


--
-- Name: marketing_lead_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketing_lead_id_seq', 10, true);


--
-- Name: marketing_research_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.marketing_research_id_seq', 6, true);


--
-- Name: mrp_planned_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mrp_planned_order_id_seq', 1, false);


--
-- Name: mrp_run_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mrp_run_id_seq', 1, false);


--
-- Name: notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notification_id_seq', 1, false);


--
-- Name: passwd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.passwd_id_seq', 77, true);


--
-- Name: payroll_deduction_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payroll_deduction_type_id_seq', 10, true);


--
-- Name: payroll_entry_deduction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payroll_entry_deduction_id_seq', 168, true);


--
-- Name: payroll_entry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payroll_entry_id_seq', 72, true);


--
-- Name: payroll_run_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payroll_run_id_seq', 6, true);


--
-- Name: people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.people_id_seq', 153, true);


--
-- Name: pers_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pers_review_id_seq', 1, false);


--
-- Name: pers_training_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pers_training_id_seq', 1, false);


--
-- Name: po_approval_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.po_approval_id_seq', 1, false);


--
-- Name: po_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.po_item_id_seq', 10, true);


--
-- Name: position_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.position_id_seq', 50, true);


--
-- Name: product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_id_seq', 13, true);


--
-- Name: purchase_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.purchase_order_id_seq', 6, true);


--
-- Name: purchase_requisition_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.purchase_requisition_id_seq', 7, true);


--
-- Name: qa_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_audit_id_seq', 14, true);


--
-- Name: qa_capa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_capa_id_seq', 12, true);


--
-- Name: qa_defect_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_defect_id_seq', 3, true);


--
-- Name: qa_inspection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_inspection_id_seq', 6, true);


--
-- Name: qa_ncr_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_ncr_id_seq', 16, true);


--
-- Name: qa_spec_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_spec_id_seq', 1, false);


--
-- Name: qa_supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.qa_supplier_id_seq', 16, true);


--
-- Name: receiving_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.receiving_id_seq', 8, true);


--
-- Name: receiving_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.receiving_item_id_seq', 27, true);


--
-- Name: requisition_approval_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.requisition_approval_id_seq', 6, true);


--
-- Name: requisition_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.requisition_item_id_seq', 15, true);


--
-- Name: rfq_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rfq_id_seq', 1, false);


--
-- Name: rfq_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rfq_item_id_seq', 1, false);


--
-- Name: rfq_quote_line_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rfq_quote_line_id_seq', 1, false);


--
-- Name: rfq_vendor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rfq_vendor_id_seq', 1, false);


--
-- Name: risk_assessment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.risk_assessment_id_seq', 1, false);


--
-- Name: risk_audit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.risk_audit_id_seq', 1, false);


--
-- Name: risk_continuity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.risk_continuity_id_seq', 1, false);


--
-- Name: risk_insurance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.risk_insurance_id_seq', 1, false);


--
-- Name: risk_kri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.risk_kri_id_seq', 1, false);


--
-- Name: risk_register_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.risk_register_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 74, true);


--
-- Name: routing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.routing_id_seq', 9, true);


--
-- Name: sales_coaching_note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_coaching_note_id_seq', 1, false);


--
-- Name: sales_commission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_commission_id_seq', 16, true);


--
-- Name: sales_commission_plan_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_commission_plan_id_seq', 4, true);


--
-- Name: sales_contract_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_contract_id_seq', 12, true);


--
-- Name: sales_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_customer_id_seq', 1, false);


--
-- Name: sales_forecast_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_forecast_id_seq', 14, true);


--
-- Name: sales_lead_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_lead_id_seq', 20, true);


--
-- Name: sales_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_order_id_seq', 3, true);


--
-- Name: sales_perf_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_perf_review_id_seq', 1, false);


--
-- Name: sales_quote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_quote_id_seq', 16, true);


--
-- Name: sales_target_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_target_id_seq', 16, true);


--
-- Name: sales_territory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_territory_id_seq', 16, true);


--
-- Name: serial_number_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.serial_number_id_seq', 8, true);


--
-- Name: shipment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shipment_id_seq', 8, true);


--
-- Name: shipment_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shipment_item_id_seq', 27, true);


--
-- Name: so_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.so_item_id_seq', 4, true);


--
-- Name: spc_control_limit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.spc_control_limit_id_seq', 1, false);


--
-- Name: spc_measurement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.spc_measurement_id_seq', 1, false);


--
-- Name: supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.supplier_id_seq', 11, true);


--
-- Name: supplier_login_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.supplier_login_id_seq', 1, true);


--
-- Name: tax_calendar_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tax_calendar_id_seq', 13, true);


--
-- Name: tax_filing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tax_filing_id_seq', 8, true);


--
-- Name: tax_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tax_payment_id_seq', 1, false);


--
-- Name: time_clock_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.time_clock_devices_id_seq', 1, false);


--
-- Name: time_clock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.time_clock_id_seq', 250, true);


--
-- Name: time_clock_sync_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.time_clock_sync_log_id_seq', 1, false);


--
-- Name: time_off_balance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.time_off_balance_id_seq', 1, false);


--
-- Name: time_off_request_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.time_off_request_id_seq', 1, false);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 54, true);


--
-- Name: wo_cost_actual_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wo_cost_actual_id_seq', 1, true);


--
-- Name: wo_material_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wo_material_id_seq', 14, true);


--
-- Name: wo_operation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.wo_operation_id_seq', 9, true);


--
-- Name: work_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.work_order_id_seq', 5, true);


--
-- Name: workcenter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.workcenter_id_seq', 5, true);


--
-- Name: ap_invoice ap_invoice_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ap_invoice
    ADD CONSTRAINT ap_invoice_invoice_number_key UNIQUE (invoice_number);


--
-- Name: ap_invoice ap_invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ap_invoice
    ADD CONSTRAINT ap_invoice_pkey PRIMARY KEY (id);


--
-- Name: ap_payment ap_payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ap_payment
    ADD CONSTRAINT ap_payment_pkey PRIMARY KEY (id);


--
-- Name: api_login_attempt api_login_attempt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_login_attempt
    ADD CONSTRAINT api_login_attempt_pkey PRIMARY KEY (id);


--
-- Name: api_token api_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_token
    ADD CONSTRAINT api_token_pkey PRIMARY KEY (token);


--
-- Name: api_totp_secret api_totp_secret_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_totp_secret
    ADD CONSTRAINT api_totp_secret_pkey PRIMARY KEY (people_id);


--
-- Name: approval_rule approval_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_rule
    ADD CONSTRAINT approval_rule_pkey PRIMARY KEY (id);


--
-- Name: approval_step approval_step_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_step
    ADD CONSTRAINT approval_step_pkey PRIMARY KEY (id);


--
-- Name: ar_invoice ar_invoice_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_invoice
    ADD CONSTRAINT ar_invoice_invoice_number_key UNIQUE (invoice_number);


--
-- Name: ar_invoice ar_invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_invoice
    ADD CONSTRAINT ar_invoice_pkey PRIMARY KEY (id);


--
-- Name: ar_payment ar_payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_payment
    ADD CONSTRAINT ar_payment_pkey PRIMARY KEY (id);


--
-- Name: audit_finding audit_finding_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_finding
    ADD CONSTRAINT audit_finding_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: audit_schedule audit_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_schedule
    ADD CONSTRAINT audit_schedule_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: bank_account bank_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_account
    ADD CONSTRAINT bank_account_pkey PRIMARY KEY (id);


--
-- Name: bank_reconciliation bank_reconciliation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_reconciliation
    ADD CONSTRAINT bank_reconciliation_pkey PRIMARY KEY (id);


--
-- Name: bank_statement_item bank_statement_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_statement_item
    ADD CONSTRAINT bank_statement_item_pkey PRIMARY KEY (id);


--
-- Name: bank_statement bank_statement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_statement
    ADD CONSTRAINT bank_statement_pkey PRIMARY KEY (id);


--
-- Name: bank_transaction bank_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_transaction
    ADD CONSTRAINT bank_transaction_pkey PRIMARY KEY (id);


--
-- Name: bom bom_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bom
    ADD CONSTRAINT bom_pkey PRIMARY KEY (id);


--
-- Name: budget_line budget_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_line
    ADD CONSTRAINT budget_line_pkey PRIMARY KEY (id);


--
-- Name: budget budget_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget
    ADD CONSTRAINT budget_pkey PRIMARY KEY (id);


--
-- Name: calls2 calls2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calls2
    ADD CONSTRAINT calls2_pkey PRIMARY KEY (id);


--
-- Name: closed_periods closed_periods_period_year_period_month_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.closed_periods
    ADD CONSTRAINT closed_periods_period_year_period_month_key UNIQUE (period_year, period_month);


--
-- Name: closed_periods closed_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.closed_periods
    ADD CONSTRAINT closed_periods_pkey PRIMARY KEY (id);


--
-- Name: collection_activity collection_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collection_activity
    ADD CONSTRAINT collection_activity_pkey PRIMARY KEY (id);


--
-- Name: compliance_checklist_item compliance_checklist_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_checklist_item
    ADD CONSTRAINT compliance_checklist_item_pkey PRIMARY KEY (id);


--
-- Name: compliance_checklist compliance_checklist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_checklist
    ADD CONSTRAINT compliance_checklist_pkey PRIMARY KEY (id);


--
-- Name: compliance_template_item compliance_template_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_template_item
    ADD CONSTRAINT compliance_template_item_pkey PRIMARY KEY (id);


--
-- Name: compliance_template compliance_template_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_template
    ADD CONSTRAINT compliance_template_pkey PRIMARY KEY (id);


--
-- Name: corrective_action corrective_action_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.corrective_action
    ADD CONSTRAINT corrective_action_pkey PRIMARY KEY (id);


--
-- Name: cost_center cost_center_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cost_center
    ADD CONSTRAINT cost_center_code_key UNIQUE (code);


--
-- Name: cost_center cost_center_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cost_center
    ADD CONSTRAINT cost_center_pkey PRIMARY KEY (id);


--
-- Name: cost_roll cost_roll_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cost_roll
    ADD CONSTRAINT cost_roll_pkey PRIMARY KEY (id);


--
-- Name: credit_account credit_account_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_account
    ADD CONSTRAINT credit_account_customer_id_key UNIQUE (customer_id);


--
-- Name: credit_account credit_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_account
    ADD CONSTRAINT credit_account_pkey PRIMARY KEY (id);


--
-- Name: credit_application credit_application_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_application
    ADD CONSTRAINT credit_application_pkey PRIMARY KEY (id);


--
-- Name: credit_limit_history credit_limit_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_limit_history
    ADD CONSTRAINT credit_limit_history_pkey PRIMARY KEY (id);


--
-- Name: cs_improvement_plan cs_improvement_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cs_improvement_plan
    ADD CONSTRAINT cs_improvement_plan_pkey PRIMARY KEY (id);


--
-- Name: cs_kb_article cs_kb_article_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cs_kb_article
    ADD CONSTRAINT cs_kb_article_pkey PRIMARY KEY (id);


--
-- Name: cs_return cs_return_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cs_return
    ADD CONSTRAINT cs_return_pkey PRIMARY KEY (id);


--
-- Name: cs_survey cs_survey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cs_survey
    ADD CONSTRAINT cs_survey_pkey PRIMARY KEY (id);


--
-- Name: cs_survey_response cs_survey_response_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cs_survey_response
    ADD CONSTRAINT cs_survey_response_pkey PRIMARY KEY (id);


--
-- Name: cs_training cs_training_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cs_training
    ADD CONSTRAINT cs_training_pkey PRIMARY KEY (id);


--
-- Name: customer customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT customer_pkey PRIMARY KEY (id);


--
-- Name: dept dept_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dept
    ADD CONSTRAINT dept_pkey PRIMARY KEY (dept_id);


--
-- Name: dept_sub dept_sub_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dept_sub
    ADD CONSTRAINT dept_sub_pkey PRIMARY KEY (dept_sub_id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: employee_deduction employee_deduction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_deduction
    ADD CONSTRAINT employee_deduction_pkey PRIMARY KEY (id);


--
-- Name: employee_pay employee_pay_people_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_pay
    ADD CONSTRAINT employee_pay_people_id_key UNIQUE (people_id);


--
-- Name: employee_pay employee_pay_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_pay
    ADD CONSTRAINT employee_pay_pkey PRIMARY KEY (id);


--
-- Name: eng_design_review eng_design_review_ecr_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eng_design_review
    ADD CONSTRAINT eng_design_review_ecr_number_key UNIQUE (ecr_number);


--
-- Name: eng_design_review eng_design_review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eng_design_review
    ADD CONSTRAINT eng_design_review_pkey PRIMARY KEY (id);


--
-- Name: eng_project eng_project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eng_project
    ADD CONSTRAINT eng_project_pkey PRIMARY KEY (id);


--
-- Name: eng_project eng_project_project_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eng_project
    ADD CONSTRAINT eng_project_project_number_key UNIQUE (project_number);


--
-- Name: eng_standard eng_standard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eng_standard
    ADD CONSTRAINT eng_standard_pkey PRIMARY KEY (id);


--
-- Name: eng_task eng_task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eng_task
    ADD CONSTRAINT eng_task_pkey PRIMARY KEY (id);


--
-- Name: gl_account gl_account_account_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_account
    ADD CONSTRAINT gl_account_account_number_key UNIQUE (account_number);


--
-- Name: gl_account_map gl_account_map_category_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_account_map
    ADD CONSTRAINT gl_account_map_category_key UNIQUE (category);


--
-- Name: gl_account_map gl_account_map_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_account_map
    ADD CONSTRAINT gl_account_map_pkey PRIMARY KEY (id);


--
-- Name: gl_account gl_account_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_account
    ADD CONSTRAINT gl_account_pkey PRIMARY KEY (id);


--
-- Name: gl_journal_line gl_journal_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_journal_line
    ADD CONSTRAINT gl_journal_line_pkey PRIMARY KEY (id);


--
-- Name: gl_journal gl_journal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_journal
    ADD CONSTRAINT gl_journal_pkey PRIMARY KEY (id);


--
-- Name: inventory_transaction inventory_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transaction
    ADD CONSTRAINT inventory_transaction_pkey PRIMARY KEY (id);


--
-- Name: it_asset it_asset_asset_tag_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_asset
    ADD CONSTRAINT it_asset_asset_tag_key UNIQUE (asset_tag);


--
-- Name: it_asset_history it_asset_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_asset_history
    ADD CONSTRAINT it_asset_history_pkey PRIMARY KEY (id);


--
-- Name: it_asset it_asset_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_asset
    ADD CONSTRAINT it_asset_pkey PRIMARY KEY (id);


--
-- Name: it_bandwidth_log it_bandwidth_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_bandwidth_log
    ADD CONSTRAINT it_bandwidth_log_pkey PRIMARY KEY (id);


--
-- Name: it_license it_license_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_license
    ADD CONSTRAINT it_license_pkey PRIMARY KEY (id);


--
-- Name: it_network_device it_network_device_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_network_device
    ADD CONSTRAINT it_network_device_pkey PRIMARY KEY (id);


--
-- Name: it_network_incident it_network_incident_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_network_incident
    ADD CONSTRAINT it_network_incident_pkey PRIMARY KEY (id);


--
-- Name: it_repair it_repair_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_repair
    ADD CONSTRAINT it_repair_pkey PRIMARY KEY (id);


--
-- Name: it_software_install it_software_install_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_software_install
    ADD CONSTRAINT it_software_install_pkey PRIMARY KEY (id);


--
-- Name: it_task it_task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_task
    ADD CONSTRAINT it_task_pkey PRIMARY KEY (id);


--
-- Name: it_task it_task_task_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_task
    ADD CONSTRAINT it_task_task_number_key UNIQUE (task_number);


--
-- Name: it_ticket it_ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_ticket
    ADD CONSTRAINT it_ticket_pkey PRIMARY KEY (id);


--
-- Name: it_ticket it_ticket_ticket_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.it_ticket
    ADD CONSTRAINT it_ticket_ticket_number_key UNIQUE (ticket_number);


--
-- Name: legal_compliance legal_compliance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_compliance
    ADD CONSTRAINT legal_compliance_pkey PRIMARY KEY (id);


--
-- Name: legal_contract legal_contract_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_contract
    ADD CONSTRAINT legal_contract_pkey PRIMARY KEY (id);


--
-- Name: legal_employment legal_employment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_employment
    ADD CONSTRAINT legal_employment_pkey PRIMARY KEY (id);


--
-- Name: legal_governance legal_governance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_governance
    ADD CONSTRAINT legal_governance_pkey PRIMARY KEY (id);


--
-- Name: legal_ip legal_ip_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_ip
    ADD CONSTRAINT legal_ip_pkey PRIMARY KEY (id);


--
-- Name: legal_litigation legal_litigation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.legal_litigation
    ADD CONSTRAINT legal_litigation_pkey PRIMARY KEY (id);


--
-- Name: location location_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location
    ADD CONSTRAINT location_name_key UNIQUE (name);


--
-- Name: location location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location
    ADD CONSTRAINT location_pkey PRIMARY KEY (id);


--
-- Name: lot lot_lot_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lot
    ADD CONSTRAINT lot_lot_number_key UNIQUE (lot_number);


--
-- Name: lot lot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lot
    ADD CONSTRAINT lot_pkey PRIMARY KEY (id);


--
-- Name: maint_downtime maint_downtime_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_downtime
    ADD CONSTRAINT maint_downtime_pkey PRIMARY KEY (id);


--
-- Name: maint_equipment maint_equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_equipment
    ADD CONSTRAINT maint_equipment_pkey PRIMARY KEY (id);


--
-- Name: maint_inspection maint_inspection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_inspection
    ADD CONSTRAINT maint_inspection_pkey PRIMARY KEY (id);


--
-- Name: maint_mechanic maint_mechanic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_mechanic
    ADD CONSTRAINT maint_mechanic_pkey PRIMARY KEY (id);


--
-- Name: maint_part maint_part_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_part
    ADD CONSTRAINT maint_part_pkey PRIMARY KEY (id);


--
-- Name: maint_schedule maint_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_schedule
    ADD CONSTRAINT maint_schedule_pkey PRIMARY KEY (id);


--
-- Name: maint_work_order maint_work_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maint_work_order
    ADD CONSTRAINT maint_work_order_pkey PRIMARY KEY (id);


--
-- Name: marketing_ad marketing_ad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_ad
    ADD CONSTRAINT marketing_ad_pkey PRIMARY KEY (id);


--
-- Name: marketing_analytics marketing_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_analytics
    ADD CONSTRAINT marketing_analytics_pkey PRIMARY KEY (id);


--
-- Name: marketing_budget marketing_budget_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_budget
    ADD CONSTRAINT marketing_budget_pkey PRIMARY KEY (id);


--
-- Name: marketing_campaign marketing_campaign_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_campaign
    ADD CONSTRAINT marketing_campaign_pkey PRIMARY KEY (id);


--
-- Name: marketing_content marketing_content_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_content
    ADD CONSTRAINT marketing_content_pkey PRIMARY KEY (id);


--
-- Name: marketing_lead marketing_lead_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_lead
    ADD CONSTRAINT marketing_lead_pkey PRIMARY KEY (id);


--
-- Name: marketing_research marketing_research_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.marketing_research
    ADD CONSTRAINT marketing_research_pkey PRIMARY KEY (id);


--
-- Name: mrp_planned_order mrp_planned_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrp_planned_order
    ADD CONSTRAINT mrp_planned_order_pkey PRIMARY KEY (id);


--
-- Name: mrp_run mrp_run_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrp_run
    ADD CONSTRAINT mrp_run_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: passwd passwd_people_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passwd
    ADD CONSTRAINT passwd_people_id_key UNIQUE (people_id);


--
-- Name: passwd passwd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passwd
    ADD CONSTRAINT passwd_pkey PRIMARY KEY (id);


--
-- Name: payroll_deduction_type payroll_deduction_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_deduction_type
    ADD CONSTRAINT payroll_deduction_type_pkey PRIMARY KEY (id);


--
-- Name: payroll_entry_deduction payroll_entry_deduction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_entry_deduction
    ADD CONSTRAINT payroll_entry_deduction_pkey PRIMARY KEY (id);


--
-- Name: payroll_entry payroll_entry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_entry
    ADD CONSTRAINT payroll_entry_pkey PRIMARY KEY (id);


--
-- Name: payroll_run payroll_run_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_run
    ADD CONSTRAINT payroll_run_pkey PRIMARY KEY (id);


--
-- Name: people people_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- Name: pers_review pers_review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pers_review
    ADD CONSTRAINT pers_review_pkey PRIMARY KEY (id);


--
-- Name: pers_training pers_training_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pers_training
    ADD CONSTRAINT pers_training_pkey PRIMARY KEY (id);


--
-- Name: po_approval po_approval_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.po_approval
    ADD CONSTRAINT po_approval_pkey PRIMARY KEY (id);


--
-- Name: po_item po_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.po_item
    ADD CONSTRAINT po_item_pkey PRIMARY KEY (id);


--
-- Name: position position_people_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."position"
    ADD CONSTRAINT position_people_id_key UNIQUE (people_id);


--
-- Name: position position_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."position"
    ADD CONSTRAINT position_pkey PRIMARY KEY (id);


--
-- Name: product product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_pkey PRIMARY KEY (id);


--
-- Name: purchase_order purchase_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order
    ADD CONSTRAINT purchase_order_pkey PRIMARY KEY (id);


--
-- Name: purchase_order purchase_order_po_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order
    ADD CONSTRAINT purchase_order_po_number_key UNIQUE (po_number);


--
-- Name: purchase_requisition purchase_requisition_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_requisition
    ADD CONSTRAINT purchase_requisition_pkey PRIMARY KEY (id);


--
-- Name: purchase_requisition purchase_requisition_req_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_requisition
    ADD CONSTRAINT purchase_requisition_req_number_key UNIQUE (req_number);


--
-- Name: qa_audit qa_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_audit
    ADD CONSTRAINT qa_audit_pkey PRIMARY KEY (id);


--
-- Name: qa_capa qa_capa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_capa
    ADD CONSTRAINT qa_capa_pkey PRIMARY KEY (id);


--
-- Name: qa_defect qa_defect_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_defect
    ADD CONSTRAINT qa_defect_pkey PRIMARY KEY (id);


--
-- Name: qa_inspection qa_inspection_insp_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_inspection
    ADD CONSTRAINT qa_inspection_insp_number_key UNIQUE (insp_number);


--
-- Name: qa_inspection qa_inspection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_inspection
    ADD CONSTRAINT qa_inspection_pkey PRIMARY KEY (id);


--
-- Name: qa_ncr qa_ncr_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_ncr
    ADD CONSTRAINT qa_ncr_pkey PRIMARY KEY (id);


--
-- Name: qa_spec qa_spec_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_spec
    ADD CONSTRAINT qa_spec_pkey PRIMARY KEY (id);


--
-- Name: qa_supplier qa_supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_supplier
    ADD CONSTRAINT qa_supplier_pkey PRIMARY KEY (id);


--
-- Name: receiving_item receiving_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receiving_item
    ADD CONSTRAINT receiving_item_pkey PRIMARY KEY (id);


--
-- Name: receiving receiving_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receiving
    ADD CONSTRAINT receiving_pkey PRIMARY KEY (id);


--
-- Name: receiving receiving_rcv_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receiving
    ADD CONSTRAINT receiving_rcv_number_key UNIQUE (rcv_number);


--
-- Name: requisition_approval requisition_approval_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requisition_approval
    ADD CONSTRAINT requisition_approval_pkey PRIMARY KEY (id);


--
-- Name: requisition_item requisition_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requisition_item
    ADD CONSTRAINT requisition_item_pkey PRIMARY KEY (id);


--
-- Name: rfq_item rfq_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_item
    ADD CONSTRAINT rfq_item_pkey PRIMARY KEY (id);


--
-- Name: rfq rfq_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq
    ADD CONSTRAINT rfq_pkey PRIMARY KEY (id);


--
-- Name: rfq_quote_line rfq_quote_line_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_quote_line
    ADD CONSTRAINT rfq_quote_line_pkey PRIMARY KEY (id);


--
-- Name: rfq_quote_line rfq_quote_line_rfq_item_id_vendor_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_quote_line
    ADD CONSTRAINT rfq_quote_line_rfq_item_id_vendor_id_key UNIQUE (rfq_item_id, vendor_id);


--
-- Name: rfq rfq_rfq_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq
    ADD CONSTRAINT rfq_rfq_number_key UNIQUE (rfq_number);


--
-- Name: rfq_vendor rfq_vendor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_vendor
    ADD CONSTRAINT rfq_vendor_pkey PRIMARY KEY (id);


--
-- Name: rfq_vendor rfq_vendor_rfq_id_supplier_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_vendor
    ADD CONSTRAINT rfq_vendor_rfq_id_supplier_id_key UNIQUE (rfq_id, supplier_id);


--
-- Name: risk_assessment risk_assessment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.risk_assessment
    ADD CONSTRAINT risk_assessment_pkey PRIMARY KEY (id);


--
-- Name: risk_audit risk_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.risk_audit
    ADD CONSTRAINT risk_audit_pkey PRIMARY KEY (id);


--
-- Name: risk_continuity risk_continuity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.risk_continuity
    ADD CONSTRAINT risk_continuity_pkey PRIMARY KEY (id);


--
-- Name: risk_insurance risk_insurance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.risk_insurance
    ADD CONSTRAINT risk_insurance_pkey PRIMARY KEY (id);


--
-- Name: risk_kri risk_kri_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.risk_kri
    ADD CONSTRAINT risk_kri_pkey PRIMARY KEY (id);


--
-- Name: risk_register risk_register_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.risk_register
    ADD CONSTRAINT risk_register_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: roles roles_role_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_role_name_key UNIQUE (role_name);


--
-- Name: routing routing_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routing
    ADD CONSTRAINT routing_pkey PRIMARY KEY (id);


--
-- Name: routing routing_product_id_operation_seq_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routing
    ADD CONSTRAINT routing_product_id_operation_seq_key UNIQUE (product_id, operation_seq);


--
-- Name: sales_coaching_note sales_coaching_note_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_coaching_note
    ADD CONSTRAINT sales_coaching_note_pkey PRIMARY KEY (id);


--
-- Name: sales_commission sales_commission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_commission
    ADD CONSTRAINT sales_commission_pkey PRIMARY KEY (id);


--
-- Name: sales_commission_plan sales_commission_plan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_commission_plan
    ADD CONSTRAINT sales_commission_plan_pkey PRIMARY KEY (id);


--
-- Name: sales_contract sales_contract_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_contract
    ADD CONSTRAINT sales_contract_pkey PRIMARY KEY (id);


--
-- Name: sales_customer sales_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_customer
    ADD CONSTRAINT sales_customer_pkey PRIMARY KEY (id);


--
-- Name: sales_forecast sales_forecast_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_forecast
    ADD CONSTRAINT sales_forecast_pkey PRIMARY KEY (id);


--
-- Name: sales_lead sales_lead_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_lead
    ADD CONSTRAINT sales_lead_pkey PRIMARY KEY (id);


--
-- Name: sales_order sales_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order
    ADD CONSTRAINT sales_order_pkey PRIMARY KEY (id);


--
-- Name: sales_order sales_order_so_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order
    ADD CONSTRAINT sales_order_so_number_key UNIQUE (so_number);


--
-- Name: sales_perf_review sales_perf_review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_perf_review
    ADD CONSTRAINT sales_perf_review_pkey PRIMARY KEY (id);


--
-- Name: sales_quote sales_quote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_quote
    ADD CONSTRAINT sales_quote_pkey PRIMARY KEY (id);


--
-- Name: sales_target sales_target_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_target
    ADD CONSTRAINT sales_target_pkey PRIMARY KEY (id);


--
-- Name: sales_territory sales_territory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_territory
    ADD CONSTRAINT sales_territory_pkey PRIMARY KEY (id);


--
-- Name: serial_number serial_number_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serial_number
    ADD CONSTRAINT serial_number_pkey PRIMARY KEY (id);


--
-- Name: serial_number serial_number_serial_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serial_number
    ADD CONSTRAINT serial_number_serial_number_key UNIQUE (serial_number);


--
-- Name: shipment_item shipment_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipment_item
    ADD CONSTRAINT shipment_item_pkey PRIMARY KEY (id);


--
-- Name: shipment shipment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT shipment_pkey PRIMARY KEY (id);


--
-- Name: shipment shipment_ship_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipment
    ADD CONSTRAINT shipment_ship_number_key UNIQUE (ship_number);


--
-- Name: so_item so_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.so_item
    ADD CONSTRAINT so_item_pkey PRIMARY KEY (id);


--
-- Name: spc_control_limit spc_control_limit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spc_control_limit
    ADD CONSTRAINT spc_control_limit_pkey PRIMARY KEY (id);


--
-- Name: spc_control_limit spc_control_limit_product_id_characteristic_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spc_control_limit
    ADD CONSTRAINT spc_control_limit_product_id_characteristic_key UNIQUE (product_id, characteristic);


--
-- Name: spc_measurement spc_measurement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spc_measurement
    ADD CONSTRAINT spc_measurement_pkey PRIMARY KEY (id);


--
-- Name: supplier_login supplier_login_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_login
    ADD CONSTRAINT supplier_login_email_key UNIQUE (email);


--
-- Name: supplier_login supplier_login_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_login
    ADD CONSTRAINT supplier_login_pkey PRIMARY KEY (id);


--
-- Name: supplier_login supplier_login_supplier_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_login
    ADD CONSTRAINT supplier_login_supplier_id_key UNIQUE (supplier_id);


--
-- Name: supplier supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier
    ADD CONSTRAINT supplier_pkey PRIMARY KEY (id);


--
-- Name: tax_calendar tax_calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_calendar
    ADD CONSTRAINT tax_calendar_pkey PRIMARY KEY (id);


--
-- Name: tax_filing tax_filing_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_filing
    ADD CONSTRAINT tax_filing_pkey PRIMARY KEY (id);


--
-- Name: tax_payment tax_payment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tax_payment
    ADD CONSTRAINT tax_payment_pkey PRIMARY KEY (id);


--
-- Name: time_clock_devices time_clock_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_clock_devices
    ADD CONSTRAINT time_clock_devices_pkey PRIMARY KEY (id);


--
-- Name: time_clock time_clock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_clock
    ADD CONSTRAINT time_clock_pkey PRIMARY KEY (id);


--
-- Name: time_clock_sync_log time_clock_sync_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_clock_sync_log
    ADD CONSTRAINT time_clock_sync_log_pkey PRIMARY KEY (id);


--
-- Name: time_off_balance time_off_balance_people_id_year_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_off_balance
    ADD CONSTRAINT time_off_balance_people_id_year_key UNIQUE (people_id, year);


--
-- Name: time_off_balance time_off_balance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_off_balance
    ADD CONSTRAINT time_off_balance_pkey PRIMARY KEY (id);


--
-- Name: time_off_request time_off_request_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_off_request
    ADD CONSTRAINT time_off_request_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_people_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_people_id_key UNIQUE (people_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: wo_cost_actual wo_cost_actual_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wo_cost_actual
    ADD CONSTRAINT wo_cost_actual_pkey PRIMARY KEY (id);


--
-- Name: wo_cost_actual wo_cost_actual_wo_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wo_cost_actual
    ADD CONSTRAINT wo_cost_actual_wo_id_key UNIQUE (wo_id);


--
-- Name: wo_material wo_material_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wo_material
    ADD CONSTRAINT wo_material_pkey PRIMARY KEY (id);


--
-- Name: wo_operation wo_operation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wo_operation
    ADD CONSTRAINT wo_operation_pkey PRIMARY KEY (id);


--
-- Name: work_order work_order_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.work_order
    ADD CONSTRAINT work_order_pkey PRIMARY KEY (id);


--
-- Name: work_order work_order_wo_number_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.work_order
    ADD CONSTRAINT work_order_wo_number_key UNIQUE (wo_number);


--
-- Name: workcenter workcenter_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workcenter
    ADD CONSTRAINT workcenter_name_key UNIQUE (name);


--
-- Name: workcenter workcenter_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workcenter
    ADD CONSTRAINT workcenter_pkey PRIMARY KEY (id);


--
-- Name: api_login_attempt_ident; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_login_attempt_ident ON public.api_login_attempt USING btree (identifier, attempted_at DESC);


--
-- Name: approval_step_entity; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX approval_step_entity ON public.approval_step USING btree (entity_type, entity_id);


--
-- Name: approval_step_role_pending; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX approval_step_role_pending ON public.approval_step USING btree (approver_role, status);


--
-- Name: audit_log_changed_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_log_changed_at ON public.audit_log USING btree (changed_at DESC);


--
-- Name: audit_log_changed_by; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_log_changed_by ON public.audit_log USING btree (changed_by);


--
-- Name: audit_log_table_record; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX audit_log_table_record ON public.audit_log USING btree (table_name, record_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: bank_txn_cleared; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bank_txn_cleared ON public.bank_transaction USING btree (statement_id, cleared);


--
-- Name: bank_txn_statement; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX bank_txn_statement ON public.bank_transaction USING btree (statement_id);


--
-- Name: compliance_checklist_item_checklist; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX compliance_checklist_item_checklist ON public.compliance_checklist_item USING btree (checklist_id);


--
-- Name: compliance_template_item_template; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX compliance_template_item_template ON public.compliance_template_item USING btree (template_id);


--
-- Name: cost_roll_product; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX cost_roll_product ON public.cost_roll USING btree (product_id, effective_date DESC);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: lot_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX lot_product_id ON public.lot USING btree (product_id);


--
-- Name: notification_people_unread; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX notification_people_unread ON public.notification USING btree (people_id, read_at);


--
-- Name: sn_product_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sn_product_id ON public.serial_number USING btree (product_id);


--
-- Name: spc_meas_out_of_control; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX spc_meas_out_of_control ON public.spc_measurement USING btree (in_control, measured_at DESC);


--
-- Name: spc_meas_product_char; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX spc_meas_product_char ON public.spc_measurement USING btree (product_id, characteristic, measured_at DESC);


--
-- Name: wo_operation_wo_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX wo_operation_wo_id ON public.wo_operation USING btree (wo_id);


--
-- Name: wo_operation_workcenter_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX wo_operation_workcenter_status ON public.wo_operation USING btree (workcenter_id, status);


--
-- Name: api_totp_secret _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.api_totp_secret FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: approval_rule _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.approval_rule FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: approval_step _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.approval_step FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: bank_transaction _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.bank_transaction FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: budget_line _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.budget_line FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: cost_center _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.cost_center FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: cost_roll _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.cost_roll FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: gl_account_map _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.gl_account_map FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: inventory_transaction _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.inventory_transaction FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: lot _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.lot FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: maint_work_order _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.maint_work_order FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: payroll_entry _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.payroll_entry FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: payroll_run _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.payroll_run FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: people _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.people FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: po_item _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.po_item FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: product _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.product FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: purchase_order _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.purchase_order FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: purchase_requisition _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.purchase_requisition FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: requisition_approval _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.requisition_approval FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: requisition_item _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.requisition_item FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: routing _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.routing FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: sales_order _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.sales_order FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: serial_number _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.serial_number FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: so_item _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.so_item FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: spc_control_limit _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.spc_control_limit FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: spc_measurement _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.spc_measurement FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: time_off_request _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.time_off_request FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: user_roles _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.user_roles FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: wo_cost_actual _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.wo_cost_actual FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: wo_material _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.wo_material FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: wo_operation _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.wo_operation FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: work_order _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.work_order FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: workcenter _audit; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER _audit AFTER INSERT OR DELETE OR UPDATE ON public.workcenter FOR EACH ROW EXECUTE FUNCTION public._audit_trigger();


--
-- Name: ap_payment ap_payment_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ap_payment
    ADD CONSTRAINT ap_payment_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.ap_invoice(id);


--
-- Name: approval_step approval_step_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_step
    ADD CONSTRAINT approval_step_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.approval_rule(id);


--
-- Name: ar_invoice ar_invoice_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_invoice
    ADD CONSTRAINT ar_invoice_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- Name: ar_payment ar_payment_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ar_payment
    ADD CONSTRAINT ar_payment_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.ar_invoice(id);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: bank_account bank_account_gl_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_account
    ADD CONSTRAINT bank_account_gl_account_id_fkey FOREIGN KEY (gl_account_id) REFERENCES public.gl_account(id);


--
-- Name: bank_reconciliation bank_reconciliation_journal_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_reconciliation
    ADD CONSTRAINT bank_reconciliation_journal_line_id_fkey FOREIGN KEY (journal_line_id) REFERENCES public.gl_journal_line(id);


--
-- Name: bank_reconciliation bank_reconciliation_statement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_reconciliation
    ADD CONSTRAINT bank_reconciliation_statement_id_fkey FOREIGN KEY (statement_id) REFERENCES public.bank_statement(id) ON DELETE CASCADE;


--
-- Name: bank_reconciliation bank_reconciliation_statement_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_reconciliation
    ADD CONSTRAINT bank_reconciliation_statement_item_id_fkey FOREIGN KEY (statement_item_id) REFERENCES public.bank_statement_item(id);


--
-- Name: bank_statement bank_statement_bank_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_statement
    ADD CONSTRAINT bank_statement_bank_account_id_fkey FOREIGN KEY (bank_account_id) REFERENCES public.bank_account(id) ON DELETE CASCADE;


--
-- Name: bank_statement_item bank_statement_item_statement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_statement_item
    ADD CONSTRAINT bank_statement_item_statement_id_fkey FOREIGN KEY (statement_id) REFERENCES public.bank_statement(id) ON DELETE CASCADE;


--
-- Name: bank_transaction bank_transaction_bank_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_transaction
    ADD CONSTRAINT bank_transaction_bank_account_id_fkey FOREIGN KEY (bank_account_id) REFERENCES public.bank_account(id);


--
-- Name: bank_transaction bank_transaction_matched_gl_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_transaction
    ADD CONSTRAINT bank_transaction_matched_gl_line_id_fkey FOREIGN KEY (matched_gl_line_id) REFERENCES public.gl_journal_line(id);


--
-- Name: bank_transaction bank_transaction_statement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bank_transaction
    ADD CONSTRAINT bank_transaction_statement_id_fkey FOREIGN KEY (statement_id) REFERENCES public.bank_statement(id);


--
-- Name: budget_line budget_line_budget_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.budget_line
    ADD CONSTRAINT budget_line_budget_id_fkey FOREIGN KEY (budget_id) REFERENCES public.budget(id);


--
-- Name: calls2 calls2_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.calls2
    ADD CONSTRAINT calls2_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- Name: collection_activity collection_activity_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.collection_activity
    ADD CONSTRAINT collection_activity_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- Name: compliance_checklist_item compliance_checklist_item_checklist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_checklist_item
    ADD CONSTRAINT compliance_checklist_item_checklist_id_fkey FOREIGN KEY (checklist_id) REFERENCES public.compliance_checklist(id);


--
-- Name: compliance_checklist_item compliance_checklist_item_template_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_checklist_item
    ADD CONSTRAINT compliance_checklist_item_template_item_id_fkey FOREIGN KEY (template_item_id) REFERENCES public.compliance_template_item(id);


--
-- Name: compliance_checklist compliance_checklist_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_checklist
    ADD CONSTRAINT compliance_checklist_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.compliance_template(id);


--
-- Name: compliance_template_item compliance_template_item_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.compliance_template_item
    ADD CONSTRAINT compliance_template_item_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.compliance_template(id);


--
-- Name: cost_roll cost_roll_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cost_roll
    ADD CONSTRAINT cost_roll_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- Name: credit_account credit_account_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_account
    ADD CONSTRAINT credit_account_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- Name: credit_application credit_application_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_application
    ADD CONSTRAINT credit_application_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- Name: credit_limit_history credit_limit_history_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credit_limit_history
    ADD CONSTRAINT credit_limit_history_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: employee_deduction employee_deduction_deduction_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_deduction
    ADD CONSTRAINT employee_deduction_deduction_type_id_fkey FOREIGN KEY (deduction_type_id) REFERENCES public.payroll_deduction_type(id);


--
-- Name: employee_deduction employee_deduction_people_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_deduction
    ADD CONSTRAINT employee_deduction_people_id_fkey FOREIGN KEY (people_id) REFERENCES public.people(id);


--
-- Name: employee_pay employee_pay_people_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee_pay
    ADD CONSTRAINT employee_pay_people_id_fkey FOREIGN KEY (people_id) REFERENCES public.people(id);


--
-- Name: eng_design_review eng_design_review_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eng_design_review
    ADD CONSTRAINT eng_design_review_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.eng_project(id);


--
-- Name: eng_task eng_task_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eng_task
    ADD CONSTRAINT eng_task_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.eng_project(id);


--
-- Name: gl_journal_line gl_journal_line_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_journal_line
    ADD CONSTRAINT gl_journal_line_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.gl_account(id);


--
-- Name: gl_journal_line gl_journal_line_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gl_journal_line
    ADD CONSTRAINT gl_journal_line_journal_id_fkey FOREIGN KEY (journal_id) REFERENCES public.gl_journal(id) ON DELETE CASCADE;


--
-- Name: inventory_transaction inventory_transaction_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_transaction
    ADD CONSTRAINT inventory_transaction_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- Name: lot lot_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lot
    ADD CONSTRAINT lot_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- Name: mrp_planned_order mrp_planned_order_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mrp_planned_order
    ADD CONSTRAINT mrp_planned_order_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.mrp_run(id);


--
-- Name: passwd passwd_people_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passwd
    ADD CONSTRAINT passwd_people_id_fkey FOREIGN KEY (people_id) REFERENCES public.people(id);


--
-- Name: payroll_entry_deduction payroll_entry_deduction_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_entry_deduction
    ADD CONSTRAINT payroll_entry_deduction_entry_id_fkey FOREIGN KEY (entry_id) REFERENCES public.payroll_entry(id) ON DELETE CASCADE;


--
-- Name: payroll_entry payroll_entry_people_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_entry
    ADD CONSTRAINT payroll_entry_people_id_fkey FOREIGN KEY (people_id) REFERENCES public.people(id);


--
-- Name: payroll_entry payroll_entry_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payroll_entry
    ADD CONSTRAINT payroll_entry_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.payroll_run(id);


--
-- Name: people people_dept_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT people_dept_id_fkey FOREIGN KEY (dept_id) REFERENCES public.dept(dept_id);


--
-- Name: people people_dept_sub_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT people_dept_sub_id_fkey FOREIGN KEY (dept_sub_id) REFERENCES public.dept_sub(dept_sub_id);


--
-- Name: pers_review pers_review_people_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pers_review
    ADD CONSTRAINT pers_review_people_id_fkey FOREIGN KEY (people_id) REFERENCES public.people(id);


--
-- Name: pers_training pers_training_people_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pers_training
    ADD CONSTRAINT pers_training_people_id_fkey FOREIGN KEY (people_id) REFERENCES public.people(id);


--
-- Name: po_approval po_approval_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.po_approval
    ADD CONSTRAINT po_approval_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.purchase_order(id);


--
-- Name: po_item po_item_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.po_item
    ADD CONSTRAINT po_item_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.purchase_order(id);


--
-- Name: position position_people_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."position"
    ADD CONSTRAINT position_people_id_fkey FOREIGN KEY (people_id) REFERENCES public.people(id);


--
-- Name: product product_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product
    ADD CONSTRAINT product_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.supplier(id);


--
-- Name: purchase_order purchase_order_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order
    ADD CONSTRAINT purchase_order_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.supplier(id);


--
-- Name: qa_defect qa_defect_insp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.qa_defect
    ADD CONSTRAINT qa_defect_insp_id_fkey FOREIGN KEY (insp_id) REFERENCES public.qa_inspection(id);


--
-- Name: receiving_item receiving_item_receiving_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.receiving_item
    ADD CONSTRAINT receiving_item_receiving_id_fkey FOREIGN KEY (receiving_id) REFERENCES public.receiving(id);


--
-- Name: requisition_approval requisition_approval_req_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requisition_approval
    ADD CONSTRAINT requisition_approval_req_id_fkey FOREIGN KEY (req_id) REFERENCES public.purchase_requisition(id);


--
-- Name: requisition_item requisition_item_req_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.requisition_item
    ADD CONSTRAINT requisition_item_req_id_fkey FOREIGN KEY (req_id) REFERENCES public.purchase_requisition(id);


--
-- Name: rfq_item rfq_item_awarded_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_item
    ADD CONSTRAINT rfq_item_awarded_vendor_id_fkey FOREIGN KEY (awarded_vendor_id) REFERENCES public.supplier(id);


--
-- Name: rfq_item rfq_item_po_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_item
    ADD CONSTRAINT rfq_item_po_id_fkey FOREIGN KEY (po_id) REFERENCES public.purchase_order(id);


--
-- Name: rfq_item rfq_item_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_item
    ADD CONSTRAINT rfq_item_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- Name: rfq_item rfq_item_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_item
    ADD CONSTRAINT rfq_item_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfq(id);


--
-- Name: rfq_quote_line rfq_quote_line_rfq_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_quote_line
    ADD CONSTRAINT rfq_quote_line_rfq_item_id_fkey FOREIGN KEY (rfq_item_id) REFERENCES public.rfq_item(id);


--
-- Name: rfq_quote_line rfq_quote_line_vendor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_quote_line
    ADD CONSTRAINT rfq_quote_line_vendor_id_fkey FOREIGN KEY (vendor_id) REFERENCES public.supplier(id);


--
-- Name: rfq_vendor rfq_vendor_rfq_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_vendor
    ADD CONSTRAINT rfq_vendor_rfq_id_fkey FOREIGN KEY (rfq_id) REFERENCES public.rfq(id);


--
-- Name: rfq_vendor rfq_vendor_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rfq_vendor
    ADD CONSTRAINT rfq_vendor_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.supplier(id);


--
-- Name: routing routing_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routing
    ADD CONSTRAINT routing_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- Name: routing routing_workcenter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routing
    ADD CONSTRAINT routing_workcenter_id_fkey FOREIGN KEY (workcenter_id) REFERENCES public.workcenter(id);


--
-- Name: sales_order sales_order_customer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_order
    ADD CONSTRAINT sales_order_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- Name: serial_number serial_number_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serial_number
    ADD CONSTRAINT serial_number_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lot(id);


--
-- Name: serial_number serial_number_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.serial_number
    ADD CONSTRAINT serial_number_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- Name: shipment_item shipment_item_shipment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shipment_item
    ADD CONSTRAINT shipment_item_shipment_id_fkey FOREIGN KEY (shipment_id) REFERENCES public.shipment(id);


--
-- Name: so_item so_item_so_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.so_item
    ADD CONSTRAINT so_item_so_id_fkey FOREIGN KEY (so_id) REFERENCES public.sales_order(id);


--
-- Name: spc_control_limit spc_control_limit_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spc_control_limit
    ADD CONSTRAINT spc_control_limit_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- Name: spc_measurement spc_measurement_lot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spc_measurement
    ADD CONSTRAINT spc_measurement_lot_id_fkey FOREIGN KEY (lot_id) REFERENCES public.lot(id);


--
-- Name: spc_measurement spc_measurement_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spc_measurement
    ADD CONSTRAINT spc_measurement_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.product(id);


--
-- Name: spc_measurement spc_measurement_wo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.spc_measurement
    ADD CONSTRAINT spc_measurement_wo_id_fkey FOREIGN KEY (wo_id) REFERENCES public.work_order(id);


--
-- Name: time_clock time_clock_people_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_clock
    ADD CONSTRAINT time_clock_people_id_fkey FOREIGN KEY (people_id) REFERENCES public.people(id);


--
-- Name: time_clock_sync_log time_clock_sync_log_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_clock_sync_log
    ADD CONSTRAINT time_clock_sync_log_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.time_clock_devices(id);


--
-- Name: time_off_balance time_off_balance_people_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.time_off_balance
    ADD CONSTRAINT time_off_balance_people_id_fkey FOREIGN KEY (people_id) REFERENCES public.people(id);


--
-- Name: user_roles user_roles_people_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_people_id_fkey FOREIGN KEY (people_id) REFERENCES public.people(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: wo_cost_actual wo_cost_actual_wo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wo_cost_actual
    ADD CONSTRAINT wo_cost_actual_wo_id_fkey FOREIGN KEY (wo_id) REFERENCES public.work_order(id);


--
-- Name: wo_material wo_material_wo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wo_material
    ADD CONSTRAINT wo_material_wo_id_fkey FOREIGN KEY (wo_id) REFERENCES public.work_order(id);


--
-- Name: wo_operation wo_operation_routing_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wo_operation
    ADD CONSTRAINT wo_operation_routing_id_fkey FOREIGN KEY (routing_id) REFERENCES public.routing(id);


--
-- Name: wo_operation wo_operation_wo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wo_operation
    ADD CONSTRAINT wo_operation_wo_id_fkey FOREIGN KEY (wo_id) REFERENCES public.work_order(id);


--
-- Name: wo_operation wo_operation_workcenter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wo_operation
    ADD CONSTRAINT wo_operation_workcenter_id_fkey FOREIGN KEY (workcenter_id) REFERENCES public.workcenter(id);


--
-- PostgreSQL database dump complete
--

\unrestrict MKtlbYJfUNliUju3rAJSunlwSM1LfwfjfdbkFc2acXB5y1Ugzq7ZMHF7FNGskpW

